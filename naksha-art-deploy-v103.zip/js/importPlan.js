/* Read a drawing and turn it into wall segments in feet.
 * DXF is the most accurate path. DWG is not parsed — ask the user to save as DXF.
 * After import, the app shows a numbered review list for voice corrections. */

const FT_PER_M = 1 / 0.3048;
const MIN_LEN = 0.4; // feet

export function fileKind(name, type = "") {
  const n = (name || "").toLowerCase();
  const t = (type || "").toLowerCase();
  if (n.endsWith(".dwg") || t.includes("dwg")) return "dwg";
  if (n.endsWith(".dxf") || t.includes("dxf")) return "dxf";
  if (n.endsWith(".pdf") || t.includes("pdf")) return "pdf";
  if (/\.(obj)$/.test(n)) return "obj";
  if (/\.(glb|gltf)$/.test(n) || t.includes("gltf") || t.includes("glb")) return "glb";
  if (/\.(png|jpe?g|webp|gif|bmp|heic|tif{1,2})$/.test(n) || t.startsWith("image/")) return "image";
  return "unknown";
}

export async function importDrawing(file) {
  const kind = fileKind(file.name, file.type);
  if (kind === "dwg") return { kind, error: "dwg", walls: [], notes: [] };
  if (kind === "dxf") {
    const text = await file.text();
    return finalize(parseDxf(text), "dxf");
  }
  if (kind === "pdf") {
    const buf = await file.arrayBuffer();
    return finalize(await parsePdf(buf), "pdf");
  }
  if (kind === "obj") {
    const text = await file.text();
    return finalize(parseObj(text), "obj");
  }
  if (kind === "glb") {
    const buf = await file.arrayBuffer();
    return finalize(await parseGlb(buf, file.name), "glb");
  }
  if (kind === "image") {
    const url = URL.createObjectURL(file);
    try {
      return finalize(await parseImage(url), "image");
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  return { kind, error: "unknown", walls: [], notes: [] };
}

function finalize(raw, kind) {
  let segs = (raw.segs || []).filter((s) => Math.hypot(s.x2 - s.x1, s.y2 - s.y1) >= MIN_LEN * 0.15);
  segs = mergeColinear(segs, 0.15, 4);
  const scaleInfo = applyDimensions(segs, raw.dims || []);
  segs = mergeColinear(segs, 0.12, 3);
  segs = segs.filter((s) => Math.hypot(s.x2 - s.x1, s.y2 - s.y1) >= MIN_LEN);
  // flip Y if needed so plan is Y-down like the editor; DXF is often Y-up
  if (kind === "dxf" || kind === "pdf" || kind === "obj" || kind === "glb") {
    let minY = Infinity, maxY = -Infinity;
    for (const s of segs) { minY = Math.min(minY, s.y1, s.y2); maxY = Math.max(maxY, s.y1, s.y2); }
    if (isFinite(minY)) {
      for (const s of segs) { s.y1 = maxY - (s.y1 - minY); s.y2 = maxY - (s.y2 - minY); }
    }
  }
  // shift to a small origin margin
  let minX = Infinity, minY = Infinity;
  for (const s of segs) {
    minX = Math.min(minX, s.x1, s.x2);
    minY = Math.min(minY, s.y1, s.y2);
  }
  if (isFinite(minX)) {
    const ox = minX - 4, oy = minY - 4;
    for (const s of segs) { s.x1 -= ox; s.y1 -= oy; s.x2 -= ox; s.y2 -= oy; }
  }
  return {
    kind,
    walls: segs.map((s) => ({ x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2 })),
    notes: scaleInfo.notes || [],
    scaled: scaleInfo.scaled || false,
    guessed: !!raw.guessed
  };
}

/* ---------- DXF ---------- */
function parseDxf(text) {
  const pairs = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; ) {
    const code = parseInt((lines[i] || "").trim(), 10);
    if (Number.isNaN(code)) { i++; continue; }
    pairs.push([code, lines[i + 1] ?? ""]);
    i += 2;
  }
  let insunits = 0; // no $INSUNITS = unitless: sniff from the coordinates (was 1 = inches, which shrank feet drawings 12x)
  const segs = [];
  const dims = [];
  let inEntities = false, inHeader = false;
  let ev = null;
  const flush = () => {
    if (!ev) return;
    if (ev.type === "LINE" && numOk(ev.x1) && numOk(ev.x2)) {
      segs.push({ x1: ev.x1, y1: ev.y1 || 0, x2: ev.x2, y2: ev.y2 || 0 });
    } else if (ev.type === "LWPOLYLINE" && ev.pts?.length >= 2) {
      const pts = ev.pts;
      const n = ev.closed ? pts.length : pts.length - 1;
      for (let i = 0; i < n; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        segs.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y });
      }
    } else if ((ev.type === "TEXT" || ev.type === "MTEXT") && ev.text) {
      const meas = parseDimText(ev.text);
      if (meas && numOk(ev.x) && numOk(ev.y)) dims.push({ x: ev.x, y: ev.y, ft: meas });
    } else if (ev.type === "DIMENSION") {
      let meas = ev.meas;
      if (ev.text && ev.text !== "<>") {
        const p = parseDimText(ev.text);
        if (p) meas = p;
      }
      if (numOk(ev.x13) && numOk(ev.x14)) {
        const drawn = Math.hypot((ev.x14 - ev.x13), (ev.y14 - ev.y13));
        if (meas && drawn > 1e-6) dims.push({ drawn, ft: typeof meas === "number" ? meas : parseDimText(String(meas)), x: (ev.x13 + ev.x14) / 2, y: (ev.y13 + ev.y14) / 2 });
      } else if (meas && numOk(ev.x) && numOk(ev.y)) {
        dims.push({ x: ev.x, y: ev.y, ft: typeof meas === "number" ? meas : parseDimText(String(meas)) });
      }
    } else if (ev.type === "VERTEX" && ev.poly) {
      ev.poly.pts.push({ x: ev.x || 0, y: ev.y || 0 });
    } else if (ev.type === "SEQEND" && ev.poly && ev.poly.pts.length >= 2) {
      const pts = ev.poly.pts;
      const n = ev.poly.closed ? pts.length : pts.length - 1;
      for (let i = 0; i < n; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        segs.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y });
      }
    }
    ev = ev && ev.poly && ev.type === "VERTEX" ? ev : null;
    if (ev && ev.type === "SEQEND") ev = null;
  };
  let poly = null;
  for (let i = 0; i < pairs.length; i++) {
    const [c, v] = pairs[i];
    if (c === 0 && v.trim() === "SECTION") {
      const name = look(pairs, i, 2);
      inEntities = name === "ENTITIES";
      inHeader = name === "HEADER";
      continue;
    }
    if (c === 0 && v.trim() === "ENDSEC") { inEntities = false; inHeader = false; continue; }
    if (inHeader && c === 9 && v.trim() === "$INSUNITS") {
      const u = lookNum(pairs, i, 70);
      if (u != null) insunits = u;
    }
    if (!inEntities && ev === null) continue;
    if (c === 0) {
      const typ = v.trim();
      if (typ === "POLYLINE") {
        flush();
        poly = { pts: [], closed: false };
        ev = { type: typ, poly };
        continue;
      }
      if (typ === "VERTEX" && poly) {
        ev = { type: typ, poly, x: 0, y: 0 };
        continue;
      }
      if (typ === "SEQEND") {
        ev = { type: typ, poly };
        flush();
        poly = null;
        ev = null;
        continue;
      }
      flush();
      ev = { type: typ, pts: [] };
      poly = typ === "POLYLINE" ? ev : poly;
      continue;
    }
    if (!ev) continue;
    if (ev.type === "LWPOLYLINE") {
      if (c === 70) ev.closed = !!(parseInt(v, 10) & 1);
      if (c === 10) ev.pts.push({ x: parseFloat(v), y: 0 });
      if (c === 20 && ev.pts.length) ev.pts[ev.pts.length - 1].y = parseFloat(v);
    } else {
      if (c === 10) ev.x1 = ev.x = parseFloat(v);
      if (c === 20) ev.y1 = ev.y = parseFloat(v);
      if (c === 11) ev.x2 = parseFloat(v);
      if (c === 21) ev.y2 = parseFloat(v);
      if (c === 13) ev.x13 = parseFloat(v);
      if (c === 23) ev.y13 = parseFloat(v);
      if (c === 14) ev.x14 = parseFloat(v);
      if (c === 24) ev.y14 = parseFloat(v);
      if (c === 42) ev.meas = parseFloat(v);
      if (c === 1 || c === 3) ev.text = (ev.text || "") + v;
      if (c === 70 && ev.type === "POLYLINE") ev.closed = !!(parseInt(v, 10) & 1);
    }
  }
  flush();
  const unitScale = insunitsScale(insunits, segs); // to feet
  for (const s of segs) { s.x1 *= unitScale; s.y1 *= unitScale; s.x2 *= unitScale; s.y2 *= unitScale; }
  for (const d of dims) {
    if (d.drawn != null) d.drawn *= unitScale;
    if (d.x != null) { d.x *= unitScale; d.y *= unitScale; }
  }
  return { segs, dims };
}

function look(pairs, i, code) {
  for (let j = i + 1; j < Math.min(pairs.length, i + 8); j++) if (pairs[j][0] === code) return String(pairs[j][1]).trim();
  return "";
}
function lookNum(pairs, i, code) {
  const s = look(pairs, i, code);
  const n = parseInt(s, 10);
  return Number.isNaN(n) ? null : n;
}
function numOk(n) { return typeof n === "number" && isFinite(n); }

function insunitsScale(u, segs) {
  // 0 unitless 1 in 2 ft 4 mm 5 cm 6 m 8 us survey feet
  const map = { 1: 1 / 12, 2: 1, 4: 0.00328084, 5: 0.0328084, 6: FT_PER_M, 8: 1 };
  if (map[u]) return map[u];
  // sniff: if everything is huge, maybe mm
  let max = 0;
  for (const s of segs) max = Math.max(max, Math.abs(s.x1), Math.abs(s.y1), Math.abs(s.x2), Math.abs(s.y2));
  if (max > 5000) return 0.00328084;
  if (max > 400) return 1 / 12; // inches of a 30–100 ft building
  return 1;
}

/* ---------- dimension text → feet ---------- */
export function parseDimText(raw) {
  if (raw == null) return null;
  let s = String(raw).replace(/<>/g, "").replace(/%%[dc]/gi, "°").trim();
  if (!s) return null;
  // 12'-6", 12'6", 12 ft 6 in, 12.5, 10m, 3500mm, 15'-0"
  let m = s.match(/(\d+)\s*['’]\s*-?\s*(\d+(?:\.\d+)?)\s*["”]?/);
  if (m) return parseInt(m[1], 10) + parseFloat(m[2]) / 12;
  m = s.match(/(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|'|’)\s*(\d+(?:\.\d+)?)\s*(?:in|inch|"|”)?/i);
  if (m) return parseFloat(m[1]) + parseFloat(m[2] || 0) / 12;
  m = s.match(/(\d+(?:\.\d+)?)\s*(mm|millimet)/i);
  if (m) return parseFloat(m[1]) / 304.8;
  m = s.match(/(\d+(?:\.\d+)?)\s*(cm)/i);
  if (m) return parseFloat(m[1]) / 30.48;
  m = s.match(/(\d+(?:\.\d+)?)\s*(m|meter|metre)(?!\w)/i);
  if (m) return parseFloat(m[1]) * FT_PER_M;
  m = s.match(/(\d+(?:\.\d+)?)\s*(?:ft|feet|foot|'|’)/i);
  if (m) return parseFloat(m[1]);
  m = s.match(/(\d+(?:\.\d+)?)\s*(?:in|inch|")/i);
  if (m) return parseFloat(m[1]) / 12;
  m = s.match(/^(\d+(?:\.\d+)?)$/);
  if (m) {
    const n = parseFloat(m[1]);
    if (n > 80 && n < 20000) return n / 304.8; // likely mm
    if (n > 0 && n < 80) return n; // likely feet
  }
  return null;
}

function applyDimensions(segs, dims) {
  const notes = [];
  const usable = (dims || []).filter((d) => d.ft > 0.2);
  const ratios = [];
  for (const d of usable) {
    if (d.drawn > 1e-6 && d.ft) { ratios.push(d.ft / d.drawn); continue; }
    if (d.x == null) continue;
    // nearest segment
    let best = null, bd = Infinity;
    for (const s of segs) {
      const mx = (s.x1 + s.x2) / 2, my = (s.y1 + s.y2) / 2;
      const dist = Math.hypot(mx - d.x, my - d.y);
      const len = Math.hypot(s.x2 - s.x1, s.y2 - s.y1);
      if (dist < bd && dist < Math.max(3, len * 0.6)) { bd = dist; best = { s, len }; }
    }
    if (best && best.len > 1e-6) ratios.push(d.ft / best.len);
  }
  if (!ratios.length) return { scaled: false, notes };
  ratios.sort((a, b) => a - b);
  const med = ratios[Math.floor(ratios.length / 2)];
  if (!(med > 1e-6) || Math.abs(med - 1) < 0.04) return { scaled: false, notes };
  for (const s of segs) { s.x1 *= med; s.y1 *= med; s.x2 *= med; s.y2 *= med; }
  notes.push("scale");
  return { scaled: true, notes };
}

function mergeColinear(segs, joinDist, angDeg) {
  const out = segs.map((s) => ({ ...s }));
  const angTol = (angDeg * Math.PI) / 180;
  let changed = true, guard = 0;
  const dir = (s) => Math.atan2(s.y2 - s.y1, s.x2 - s.x1);
  const close = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by) <= joinDist;
  while (changed && guard++ < 40) {
    changed = false;
    outer: for (let i = 0; i < out.length; i++) {
      for (let j = i + 1; j < out.length; j++) {
        const a = out[i], b = out[j];
        let da = dir(a), db = dir(b);
        let d = Math.abs(da - db) % Math.PI;
        if (d > Math.PI / 2) d = Math.PI - d;
        if (d > angTol) continue;
        const ends = [
          [a.x2, a.y2, b.x1, b.y1, "a2b1"],
          [a.x2, a.y2, b.x2, b.y2, "a2b2"],
          [a.x1, a.y1, b.x1, b.y1, "a1b1"],
          [a.x1, a.y1, b.x2, b.y2, "a1b2"]
        ];
        for (const e of ends) {
          if (!close(e[0], e[1], e[2], e[3])) continue;
          const pts = [[a.x1, a.y1], [a.x2, a.y2], [b.x1, b.y1], [b.x2, b.y2]];
          // farthest pair as new segment
          let best = [pts[0], pts[1]], bd = 0;
          for (let p = 0; p < 4; p++) for (let q = p + 1; q < 4; q++) {
            const L = Math.hypot(pts[p][0] - pts[q][0], pts[p][1] - pts[q][1]);
            if (L > bd) { bd = L; best = [pts[p], pts[q]]; }
          }
          out[i] = { x1: best[0][0], y1: best[0][1], x2: best[1][0], y2: best[1][1] };
          out.splice(j, 1);
          changed = true;
          break outer;
        }
      }
    }
  }
  return out;
}

/* ---------- PDF (vector content streams) ---------- */
async function parsePdf(buf) {
  const u8 = new Uint8Array(buf);
  const segs = [], dims = [];
  // Find "stream\n" ... "endstream" in raw bytes so FlateDecode stays binary.
  const streamMark = [115,116,114,101,97,109]; // stream
  const endMark = [101,110,100,115,116,114,101,97,109]; // endstream
  const starts = [];
  for (let i = 0; i < u8.length - 15; i++) {
    if (u8[i] !== 115) continue;
    let ok = true;
    for (let k = 0; k < 6; k++) if (u8[i+k] !== streamMark[k]) { ok = false; break; }
    if (!ok) continue;
    const prev = u8[i-1];
    if (i > 0 && prev !== 10 && prev !== 13 && prev !== 32) continue;
    starts.push(i);
  }
  for (const i of starts) {
    let s = i + 6;
    if (u8[s] === 13) s++;
    if (u8[s] === 10) s++;
    let e = -1;
    for (let j = s; j < u8.length - 9; j++) {
      if (u8[j] !== 101) continue;
      let ok = true;
      for (let k = 0; k < 9; k++) if (u8[j+k] !== endMark[k]) { ok = false; break; }
      if (ok) { e = j; break; }
    }
    if (e < 0) continue;
    let body = u8.slice(s, e);
    const headStart = Math.max(0, i - 400);
    const head = latin(u8.slice(headStart, i));
    if (/\/FlateDecode/.test(head)) {
      try { body = await inflate(body); }
      catch {
        try { body = await inflate(body, true); } catch { continue; }
      }
    }
    extractPdfOps(latin(body), segs, dims);
  }
  if (!segs.length) extractPdfOps(latin(u8), segs, dims);
  // PDF units are points (1/72 in). Convert to feet: /72/12
  const sc = 1 / 72 / 12;
  for (const s of segs) { s.x1 *= sc; s.y1 *= sc; s.x2 *= sc; s.y2 *= sc; }
  for (const d of dims) { if (d.x != null) { d.x *= sc; d.y *= sc; } }
  return { segs, dims };
}

function latin(u8) {
  let s = "";
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) s += String.fromCharCode(...u8.subarray(i, i + chunk));
  return s;
}
function bytesOf(u8, fullMatch, streamText) {
  // locate raw stream bytes in original buffer via a short unique prefix
  const idx = fullMatch.indexOf(streamText);
  // fallback: treat streamText as latin
  const arr = new Uint8Array(streamText.length);
  for (let i = 0; i < streamText.length; i++) arr[i] = streamText.charCodeAt(i) & 255;
  return arr;
}
async function inflate(u8, raw = false) {
  if (typeof DecompressionStream !== "function") throw new Error("no inflate");
  const ds = new DecompressionStream(raw ? "deflate-raw" : "deflate");
  const ab = await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer();
  return new Uint8Array(ab);
}

function extractPdfOps(content, segs, dims) {
  const tokens = content.match(/(\\[()\\]|[^()\s]+|\([^\\)]*(?:\\.[^\\)]*)*\))/g) || [];
  // simpler scan with regex for path ops
  const pathRe = /([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+m(?:\s|$)/g;
  let cx = 0, cy = 0, sx = 0, sy = 0, started = false;
  const cmd = /([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+(m|l)\b|([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+re\b|(h)\b|(S|s|n|f|F|B|b)\b|\((?:\\.|[^\\)])*\)\s*Tj/g;
  const re2 = /([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+(m|l)\b|([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+re\b|\bh\b|\((?:\\.|[^\\)])*\)\s*Tj/g;
  let m;
  const src = content;
  const opRe = /([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+(m|l)|([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+re|\bh\b|\((?:\\.|[^\\)])*\)\s*Tj/g;
  while ((m = opRe.exec(src))) {
    if (m[3] === "m") { cx = sx = parseFloat(m[1]); cy = sy = parseFloat(m[2]); started = true; }
    else if (m[3] === "l") {
      const x = parseFloat(m[1]), y = parseFloat(m[2]);
      if (started) segs.push({ x1: cx, y1: cy, x2: x, y2: y });
      cx = x; cy = y; started = true;
    } else if (m[7] != null) {
      const x = parseFloat(m[4]), y = parseFloat(m[5]), w = parseFloat(m[6]), h = parseFloat(m[7]);
      segs.push({ x1: x, y1: y, x2: x + w, y2: y });
      segs.push({ x1: x + w, y1: y, x2: x + w, y2: y + h });
      segs.push({ x1: x + w, y1: y + h, x2: x, y2: y + h });
      segs.push({ x1: x, y1: y + h, x2: x, y2: y });
    } else if (m[0] === "h" || m[0].trim() === "h") {
      if (started) segs.push({ x1: cx, y1: cy, x2: sx, y2: sy });
      cx = sx; cy = sy;
    } else if (/\s*Tj$/.test(m[0])) {
      const raw = m[0].replace(/^./, "").replace(/\)\s*Tj$/, "").replace(/\\([()\\])/g, "$1");
      const ft = parseDimText(raw);
      if (ft) dims.push({ x: cx, y: cy, ft });
    }
  }
}

/* ---------- image / sketch (Hough + optional OCR) ---------- */
async function parseImage(url) {
  const img = await loadImg(url);
  const maxSide = 1000;
  const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
  const w = Math.max(2, Math.round(img.width * scale));
  const h = Math.max(2, Math.round(img.height * scale));
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  const data = ctx.getImageData(0, 0, w, h);
  const edges = detectEdges(data);
  const segsPx = cleanImageSegs(houghSegments(edges, w, h), Math.max(w, h));
  // OCR (best-effort, may be offline-unavailable)
  // never let a slow / blocked OCR download hang the import
  const dims = await Promise.race([ocrDims(c), new Promise((res) => setTimeout(() => res([]), 20000))]);
  // pixels → rough feet later via dimensions; default assume 1 px ~ unknown, use dims
  let segs = segsPx.map((s) => ({ x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2 }));
  if (!dims.length && segs.length) {
    // no readable dimensions (offline OCR / sketch): pixels are not feet — fit the drawing to
    // ~40 ft on its longest side so it lands on the grid; lengths can then be fixed by voice (W1 ko 12 feet karo)
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const s of segs) {
      minX = Math.min(minX, s.x1, s.x2); minY = Math.min(minY, s.y1, s.y2);
      maxX = Math.max(maxX, s.x1, s.x2); maxY = Math.max(maxY, s.y1, s.y2);
    }
    const k = 40 / Math.max(1, maxX - minX, maxY - minY);
    segs = segs.map((s) => ({ x1: s.x1 * k, y1: s.y1 * k, x2: s.x2 * k, y2: s.y2 * k }));
    return { segs, dims, guessed: true };
  }
  return { segs, dims };
}

function loadImg(url) {
  return new Promise((res, rej) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = rej;
    im.src = url;
  });
}

function detectEdges(img) {
  const { data, width: w, height: h } = img;
  const g = new Float32Array(w * h);
  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    g[p] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
  }
  // simple blur
  const b = Float32Array.from(g); // borders keep their own value (a 0 border looked like a frame edge)
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    let s = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) s += g[(y + dy) * w + (x + dx)];
    b[y * w + x] = s / 9;
  }
  const mag = new Float32Array(w * h);
  let max = 0;
  for (let y = 2; y < h - 2; y++) for (let x = 2; x < w - 2; x++) {
    const gx = b[y * w + x + 1] - b[y * w + x - 1];
    const gy = b[(y + 1) * w + x] - b[(y - 1) * w + x];
    const m = Math.hypot(gx, gy);
    mag[y * w + x] = m;
    if (m > max) max = m;
  }
  const thr = max * 0.18;
  const edge = new Uint8Array(w * h);
  for (let i = 0; i < mag.length; i++) if (mag[i] >= thr) edge[i] = 1;
  return { edge, w, h };
}

// Hough gives many near-duplicate lines for one drawn wall (both edges of a thick stroke,
// neighbouring angles, short oblique chords). Keep mostly axis-aligned lines, then fuse
// parallel overlapping lines that lie within a stroke width into one centre line.
function cleanImageSegs(segs, maxSide) {
  const norm = (s) => {
    let a = Math.atan2(s.y2 - s.y1, s.x2 - s.x1);
    if (a < 0) a += Math.PI;
    if (a >= Math.PI - 1e-9) a -= Math.PI;
    return a;
  };
  const len = (s) => Math.hypot(s.x2 - s.x1, s.y2 - s.y1);
  const axisDev = (a) => Math.min(a, Math.abs(a - Math.PI / 2), Math.PI - a);
  let list = segs.filter((s) => {
    const L = len(s), dev = axisDev(norm(s)) * 180 / Math.PI;
    return dev <= 4 ? L >= maxSide * 0.04 : L >= maxSide * 0.2;
  }).map((s) => {
    // straighten near-axis lines
    const a = norm(s);
    if (axisDev(a) * 180 / Math.PI <= 4) {
      if (Math.abs(a - Math.PI / 2) < Math.PI / 4) { const x = (s.x1 + s.x2) / 2; return { x1: x, y1: s.y1, x2: x, y2: s.y2 }; }
      const y = (s.y1 + s.y2) / 2; return { x1: s.x1, y1: y, x2: s.x2, y2: y };
    }
    return { ...s };
  }).map((s) => {
    // orient each segment along its normalised angle so projections below are consistent
    const a = norm(s);
    return (s.x2 - s.x1) * Math.cos(a) + (s.y2 - s.y1) * Math.sin(a) < 0 ? { x1: s.x2, y1: s.y2, x2: s.x1, y2: s.y1 } : s;
  });
  // drop oblique chords that just run inside an axis-aligned stroke
  const axisSegs = list.filter((s) => axisDev(norm(s)) * 180 / Math.PI <= 4);
  const nearAxis = (x, y) => axisSegs.some((o) => {
    const vert = Math.abs(o.x1 - o.x2) < 1e-6;
    const band = Math.max(8, maxSide * 0.025);
    return vert ? Math.abs(x - o.x1) <= band && y >= Math.min(o.y1, o.y2) - band && y <= Math.max(o.y1, o.y2) + band
                : Math.abs(y - o.y1) <= band && x >= Math.min(o.x1, o.x2) - band && x <= Math.max(o.x1, o.x2) + band;
  });
  list = list.filter((s) => axisDev(norm(s)) * 180 / Math.PI <= 4 || !(nearAxis(s.x1, s.y1) && nearAxis(s.x2, s.y2) && nearAxis((s.x1 + s.x2) / 2, (s.y1 + s.y2) / 2)));
  list.sort((a, b) => len(b) - len(a));
  const tol = Math.max(6, maxSide * 0.02);
  const out = [];
  for (const s of list) {
    const a = norm(s), ux = Math.cos(a), uy = Math.sin(a);
    let merged = false;
    for (const o of out) {
      let d = Math.abs(norm(o) - a); if (d > Math.PI / 2) d = Math.PI - d;
      if (d > 0.07) continue;
      const oa = norm(o), ox = Math.cos(oa), oy = Math.sin(oa);
      // perpendicular distance of s's midpoint from o's line
      const mx = (s.x1 + s.x2) / 2, my = (s.y1 + s.y2) / 2;
      const perp = Math.abs((mx - o.x1) * -oy + (my - o.y1) * ox);
      if (perp > tol) continue;
      const t = (x, y) => (x - o.x1) * ox + (y - o.y1) * oy;
      const oL = len(o), t1 = t(s.x1, s.y1), t2 = t(s.x2, s.y2);
      const lo = Math.min(t1, t2), hi = Math.max(t1, t2);
      if (hi < -tol || lo > oL + tol) continue; // no overlap
      const nlo = Math.min(0, lo), nhi = Math.max(oL, hi);
      const sx = o.x1, sy = o.y1;
      // shift towards the average offset (centre of the stroke), weighted by length
      const w1 = oL, w2 = len(s);
      const sign = Math.sign((mx - o.x1) * -oy + (my - o.y1) * ox);
      const shift = (sign * perp * w2) / (w1 + w2);
      const nx = -oy * shift, ny = ox * shift;
      o.x1 = sx + ox * nlo + nx; o.y1 = sy + oy * nlo + ny;
      o.x2 = sx + ox * nhi + nx; o.y2 = sy + oy * nhi + ny;
      merged = true; break;
    }
    if (!merged) out.push({ ...s });
    void ux; void uy;
  }
  return out;
}

function houghSegments({ edge, w, h }) {
  const maxR = Math.ceil(Math.hypot(w, h));
  const aStep = Math.PI / 36; // 5°
  const nA = 36;
  const acc = new Uint16Array(nA * (maxR * 2 + 1));
  const off = maxR;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    if (!edge[y * w + x]) continue;
    for (let ai = 0; ai < nA; ai++) {
      const a = ai * aStep;
      const r = Math.round(x * Math.cos(a) + y * Math.sin(a)) + off;
      acc[ai * (maxR * 2 + 1) + r]++;
    }
  }
  const thresh = Math.max(25, Math.min(w, h) * 0.12);
  const lines = [];
  for (let ai = 0; ai < nA; ai++) {
    for (let r = 0; r < maxR * 2 + 1; r++) {
      const v = acc[ai * (maxR * 2 + 1) + r];
      if (v < thresh) continue;
      // local max
      let ok = true;
      for (let da = -1; da <= 1 && ok; da++) for (let dr = -2; dr <= 2; dr++) {
        const a2 = ai + da, r2 = r + dr;
        if (a2 < 0 || a2 >= nA || r2 < 0 || r2 >= maxR * 2 + 1) continue;
        if (acc[a2 * (maxR * 2 + 1) + r2] > v) ok = false;
      }
      if (ok) lines.push({ a: ai * aStep, r: r - off, v });
    }
  }
  const segs = [];
  for (const L of lines) {
    const ca = Math.cos(L.a), sa = Math.sin(L.a);
    let run = [], best = [];
    const step = 2;
    // walk bounding box
    for (let t = -maxR; t <= maxR; t += step) {
      const x = Math.round(ca * L.r - sa * t);
      const y = Math.round(sa * L.r + ca * t);
      if (x < 0 || y < 0 || x >= w || y >= h) { if (run.length > best.length) best = run; run = []; continue; }
      // nearby edge
      let hit = false;
      for (let dy = -2; dy <= 2 && !hit; dy++) for (let dx = -2; dx <= 2; dx++) {
        const xx = x + dx, yy = y + dy;
        if (xx >= 0 && yy >= 0 && xx < w && yy < h && edge[yy * w + xx]) hit = true;
      }
      if (hit) run.push({ x, y });
      else { if (run.length > best.length) best = run; run = []; }
    }
    if (run.length > best.length) best = run;
    if (best.length >= 8) {
      const a = best[0], b = best[best.length - 1];
      segs.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y });
    }
  }
  return segs;
}

async function ocrDims(canvas) {
  const dims = [];
  try {
    await loadScript("https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js");
    const T = window.Tesseract;
    if (!T) return dims;
    const rec = await T.recognize(canvas, "eng", { logger: () => {} });
    for (const word of rec?.data?.words || []) {
      const ft = parseDimText(word.text);
      if (!ft) continue;
      const box = word.bbox || {};
      dims.push({ x: ((box.x0 || 0) + (box.x1 || 0)) / 2, y: ((box.y0 || 0) + (box.y1 || 0)) / 2, ft });
    }
  } catch { /* offline or blocked — dimensions may still be entered by voice */ }
  return dims;
}

function loadScript(src) {
  return new Promise((res, rej) => {
    if ([...document.scripts].some((s) => s.src === src)) return res();
    const el = document.createElement("script");
    el.src = src;
    el.async = true;
    el.onload = () => res();
    el.onerror = rej;
    document.head.appendChild(el);
  });
}

/* ---------- OBJ / GLB slice at 1 m ---------- */
function parseObj(text) {
  const verts = [];
  const edges = [];
  const addE = (a, b) => edges.push([a, b]);
  for (const line of text.split(/\r?\n/)) {
    const p = line.trim().split(/\s+/);
    if (p[0] === "v" && p.length >= 4) verts.push([parseFloat(p[1]), parseFloat(p[2]), parseFloat(p[3])]);
    if (p[0] === "l") {
      const ids = p.slice(1).map((x) => parseInt(x, 10) - 1);
      for (let i = 0; i < ids.length - 1; i++) addE(ids[i], ids[i + 1]);
    }
    if (p[0] === "f") {
      const ids = p.slice(1).map((x) => parseInt(x.split("/")[0], 10) - 1);
      for (let i = 0; i < ids.length; i++) addE(ids[i], ids[(i + 1) % ids.length]);
    }
  }
  return { segs: sliceMesh(verts, edges) };
}

async function parseGlb(buf, name) {
  const u8 = new Uint8Array(buf);
  if (name && name.toLowerCase().endsWith(".gltf")) {
    const json = JSON.parse(new TextDecoder().decode(u8));
    return { segs: await meshFromGltf(json, null) };
  }
  const mag = new TextDecoder().decode(u8.slice(0, 4));
  if (mag !== "glTF") throw new Error("not glb");
  const dv = new DataView(buf);
  let off = 12;
  let json = null, bin = null;
  while (off + 8 <= u8.length) {
    const len = dv.getUint32(off, true);
    const typ = new TextDecoder().decode(u8.slice(off + 4, off + 8));
    const chunk = u8.slice(off + 8, off + 8 + len);
    if (typ.startsWith("JSON")) json = JSON.parse(new TextDecoder().decode(chunk));
    if (typ.startsWith("BIN")) bin = chunk;
    off += 8 + len;
  }
  return { segs: await meshFromGltf(json, bin) };
}

async function meshFromGltf(json, bin) {
  if (!json) return [];
  const verts = [];
  const edges = [];
  const acc = (json.accessors || [])[0];
  // walk all mesh primitives with POSITION
  for (const mesh of json.meshes || []) {
    for (const prim of mesh.primitives || []) {
      const posAcc = json.accessors[prim.attributes?.POSITION];
      if (!posAcc) continue;
      const pos = readAccessor(json, posAcc, bin);
      const base = verts.length / 1;
      const start = verts.length;
      for (const p of pos) verts.push(p);
      if (prim.indices != null) {
        const idx = readAccessor(json, json.accessors[prim.indices], bin, true);
        if (prim.mode === 1) { // LINES
          for (let i = 0; i + 1 < idx.length; i += 2) edges.push([start + idx[i], start + idx[i + 1]]);
        } else {
          for (let i = 0; i + 2 < idx.length; i += 3) {
            edges.push([start + idx[i], start + idx[i + 1]]);
            edges.push([start + idx[i + 1], start + idx[i + 2]]);
            edges.push([start + idx[i + 2], start + idx[i]]);
          }
        }
      } else {
        for (let i = 0; i + 2 < pos.length; i += 3) {
          edges.push([start + i, start + i + 1]);
          edges.push([start + i + 1, start + i + 2]);
          edges.push([start + i + 2, start + i]);
        }
      }
    }
  }
  return sliceMesh(verts, edges);
}

function readAccessor(json, acc, bin, asIndex) {
  if (!acc || !bin) return [];
  const view = json.bufferViews[acc.bufferView];
  const off = (view.byteOffset || 0) + (acc.byteOffset || 0);
  const n = acc.count;
  const type = acc.componentType;
  const dv = new DataView(bin.buffer, bin.byteOffset + off);
  const out = [];
  const comps = acc.type === "VEC3" ? 3 : acc.type === "VEC2" ? 2 : 1;
  const size = type === 5126 ? 4 : type === 5123 ? 2 : type === 5125 ? 4 : type === 5121 ? 1 : 2;
  for (let i = 0; i < n; i++) {
    const o = i * comps * size;
    if (asIndex || comps === 1) {
      if (type === 5125) out.push(dv.getUint32(o, true));
      else if (type === 5123) out.push(dv.getUint16(o, true));
      else out.push(dv.getUint8(o));
    } else {
      out.push([dv.getFloat32(o, true), dv.getFloat32(o + 4, true), dv.getFloat32(o + 8, true)]);
    }
  }
  return out;
}

function sliceMesh(verts, edges) {
  if (!verts.length) return [];
  let min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const v of verts) {
    if (!v) continue;
    for (let i = 0; i < 3; i++) { min[i] = Math.min(min[i], v[i]); max[i] = Math.max(max[i], v[i]); }
  }
  const size = [max[0] - min[0], max[1] - min[1], max[2] - min[2]];
  const up = size[2] >= size[1] ? 2 : 1;
  const maxDim = Math.max(...size);
  let toFt = 1;
  if (maxDim > 250) toFt = 0.00328084;
  else if (maxDim < 80) toFt = FT_PER_M;
  const meter = toFt === FT_PER_M ? 1 : toFt === 0.00328084 ? 1000 : FT_PER_M;
  const slice = (up === 2 ? min[2] : min[1]) + 1 * meter;
  const horiz = (p) => [p[0], p[up === 2 ? 1 : 2]];
  const segs = [];
  // Group triangle edges (abc, bca, cab stored sequentially in threes from faces)
  // Also slice any loose edge that lies on / crosses the plane as a pair via adjacent crossings collected globally.
  const ptsOn = [];
  const crosses = [];
  for (const [ia, ib] of edges) {
    const a = verts[ia], b = verts[ib];
    if (!a || !b) continue;
    const ay = a[up], by = b[up];
    const da = ay - slice, db = by - slice;
    if (Math.abs(da) < meter * 0.02 && Math.abs(db) < meter * 0.02) {
      const pa = horiz(a), pb = horiz(b);
      segs.push({ x1: pa[0] * toFt, y1: pa[1] * toFt, x2: pb[0] * toFt, y2: pb[1] * toFt });
      continue;
    }
    if (da * db > 0) continue;
    const t = da / (da - db || 1e-9);
    const p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
    crosses.push({ ia, ib, p: horiz(p) });
  }
  // Pair crossing points that share a vertex (triangle edges)
  for (let i = 0; i < crosses.length; i++) {
    for (let j = i + 1; j < crosses.length; j++) {
      const A = crosses[i], B = crosses[j];
      if (A.ia === B.ia || A.ia === B.ib || A.ib === B.ia || A.ib === B.ib) {
        segs.push({
          x1: A.p[0] * toFt, y1: A.p[1] * toFt,
          x2: B.p[0] * toFt, y2: B.p[1] * toFt
        });
      }
    }
  }
  return segs;
}
export { detectEdges as _detectEdges, houghSegments as _houghSegments, cleanImageSegs as _cleanImageSegs };
