import { View3D } from "./view3d.js";
import {
  detectRooms, pointInPoly, polyCentroid, classifyRoomName, vastuForRoom,
  parseColorName, leftIsInside, zoneAt
} from "./extra.js";
import {
  FURNITURE, MEP, TEMPLATES, boqFor, toDxf,
  parseFloorLevel, defaultFloorName, shortFloorName
} from "./more.js";
import {
  initI18n, t, setCurrent, listLocales, currentLocale,
  applyDocumentLocale, speechLang
} from "./i18n/index.js";
import { matchVoiceAction, runAction, normCmd } from "./commands.js";
import { polyContains, rectPoly, itemPolys, polysOverlap, findWallSpot, stairCalc, stairBox, stairGeometry, drawFixture2d } from "./smart.js";
import { importDrawing, fileKind } from "./importPlan.js";

const DEMO_HASH = "ac6b8c1d804466625f4e01fc75c6abc47fb55cdceff5218571404a445e04ecbe";
const PX = 24; // pixels per foot at zoom=1
const SNAP_END_PX = 16;
const MIN_WALL = 0.4;



const SIZE = {
  small: { extent: 40, snap: 0.5 },
  medium: { extent: 80, snap: 0.5 },
  large: { extent: 160, snap: 1 }
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  user: null,
  lang: localStorage.getItem("naksha_lang") || "hi",
  project: null,
  tool: "select",
  walls: [],
  doors: [],
  windows: [],
  stairs: [],
  columns: [],
  rooms: [],
  furniture: [],
  mep: [],
  floors: [],
  floorIndex: 0,
  settings: null,
  selection: null,
  view: { zoom: 1, panX: 40, panY: 80 },
  mode: "2d",
  vastuOn: false,
  northDeg: 0,
  angleSnap: 45,
  showCornerAngles: true,
  showWallAngles: true,
  plot: { w: 30, d: 50, front: 5, back: 3, left: 3, right: 3 },
  roofOn: false,
  sunHour: 10,
  sunOn: false,
  speakOn: false,
  furnKind: "bed",
  mepKind: "light",
  undo: [],
  redo: [],
  drawing: null,
  measureStart: null,
  measureRel: false,
  pointers: new Map()
};

let view3d = null;
let dirty = false;

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}


function applyI18n() {
  applyDocumentLocale(currentLocale());
  $$("[data-i]").forEach((el) => {
    el.textContent = t(el.getAttribute("data-i"));
  });
  $$("[data-i-ph]").forEach((el) => {
    el.setAttribute("placeholder", t(el.getAttribute("data-i-ph")));
  });
  const loc = currentLocale();
  const lab = t("language") + (loc ? " \u00b7 " + loc.name : "");
  ["lang-btn", "lang-btn-2", "m-lang"].forEach((id) => {
    const b = document.getElementById(id);
    if (b) b.textContent = lab;
  });
  const mv = $("#m-vastu");
  if (mv) mv.textContent = state.vastuOn ? t("vastuOff") : t("vastuOn");
}

function setLang(lang) {
  const pack = setCurrent(lang);
  state.lang = pack && pack.code ? pack.code : lang;
  localStorage.setItem("naksha_lang", state.lang);
  applyI18n();
  if (state.project) draw2d();
}

function openLangPicker() {
  const rows = listLocales().map((l) => {
    const rtl = l.dir === "rtl" ? " \u00b7 RTL" : "";
    return "<button type=\"button\" class=\"lang-opt " + (l.code === state.lang ? "on" : "") +
      "\" data-code=\"" + escapeHtml(l.code) + "\" dir=\"" + (l.dir || "ltr") + "\">" +
      "<b>" + escapeHtml(l.name) + "</b><span>" + escapeHtml(l.englishName) +
      " \u00b7 " + escapeHtml(l.code) + rtl + "</span></button>";
  }).join("");
  $("#sheet").innerHTML = "<h3>" + t("chooseLang") + "</h3><div class=\"lang-list\">" +
    rows + "</div><p class=\"hint\">" + t("langAdded") + "</p>";
  openSheet();
  $$(".lang-opt").forEach((b) => b.addEventListener("click", () => {
    setLang(b.dataset.code);
    closeSheet();
  }));
}

function setVastu(on) {
  state.vastuOn = !!on;
  applyI18n();
  draw2d();
  persist();
  toast(t(state.vastuOn ? "vastuOn" : "vastuOff"));
}

function speak(text) {
  if (!state.speakOn || !window.speechSynthesis) return;
  try {
    const u = new SpeechSynthesisUtterance(String(text));
    u.lang = speechLang();
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  } catch {}
}

const TOOL_NAMES = { outer: "tOuter", partition: "tPart", select: "tSelect", measure: "tMeasure", door: "tDoor", window: "tWindow", column: "tColumn", stair: "tStair", furniture: "tFurn", mep: "tMep" };
function commandApi() {
  return {
    t, toast, persist, switchMode,
    setTool: (k) => { setTool(k); if (cmdQuiet) toast(t("toolOn") + ": " + (TOOL_NAMES[k] ? t(TOOL_NAMES[k]) : k)); }, undo, redo, setVastu,
    openNorthSheet, showBoq, exportDxf, vastuReportPdf, backupJson,
    exportPng, exportPdf, addFloor, setSnap, toggleWalk, toggleSun,
    openLangPicker, openImport,
    openRestore: () => $("#restore-file") && $("#restore-file").click(),
    toggleCorners: () => { state.showCornerAngles = !state.showCornerAngles; persist(); draw2d(); toast(t("corners") + (state.showCornerAngles ? " on" : " off")); },
    toggleWallAng: () => { state.showWallAngles = !state.showWallAngles; persist(); draw2d(); toast(t("wallAng") + (state.showWallAngles ? " on" : " off")); },
    toggleRoof: () => { state.roofOn = !state.roofOn; persist(); if (state.mode === "3d") refresh3d(); else switchMode("3d"); toast(t("roof") + (state.roofOn ? " on" : " off")); }
  };
}

function openImport() {
  const el = $("#import-file");
  if (el) el.click();
}

async function onImportFile(file) {
  if (!file) return;
  const kind = fileKind(file.name, file.type);
  if (kind === "dwg") {
    $("#sheet").innerHTML = "<h3>" + t("importDraw") + "</h3><p>" + t("dwgNeed") + "</p>";
    openSheet();
    return;
  }
  toast(t("importWorking"), 2500);
  try {
    const res = await importDrawing(file);
    if (res.error === "dwg") {
      $("#sheet").innerHTML = "<h3>" + t("importDraw") + "</h3><p>" + t("dwgNeed") + "</p>";
      openSheet();
      return;
    }
    if (!res.walls || !res.walls.length) { toast(t("importNone"), 2800); return; }
    applyImported(res);
  } catch (err) {
    console.warn(err);
    toast(t("importNone"), 2800);
  }
}

function applyImported(res) {
  pushUndo();
  state.walls.splice(0, state.walls.length);
  state.doors.splice(0, state.doors.length);
  state.windows.splice(0, state.windows.length);
  const p = wallProps("outer");
  res.walls.forEach((s) => {
    const w = {
      id: nextId("W", state.walls),
      type: "outer",
      x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2,
      thickness: p.thickness, color: p.color, colorIn: p.color, colorOut: p.color,
      height: state.settings.floorHeight
    };
    state.walls.push(w);
  });
  refreshRooms();
  persist();
  closeSheet();
  requestAnimationFrame(() => { fitView(); draw2d(); });
  openImportReview(res);
}

function openImportReview(res) {
  const u = unitLabel();
  const rows = state.walls.map((w) => {
    const len = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
    return "<tr><td>" + w.id + "</td><td>" + fmtLen(len) + "</td><td>" +
      Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2)) + "&deg;</td></tr>";
  }).join("");
  const scaleNote = res && res.scaled ? "<p class=\"hint\">" + t("importScale") + "</p>"
    : (res && res.guessed ? "<p class=\"hint\">" + t("importGuess") + "</p>" : "");
  $("#sheet").innerHTML = "<h3>" + t("importReview") + " (" + state.walls.length + ")</h3>" +
    scaleNote + "<p class=\"hint\">" + t("importNote") + "</p>" +
    "<table class=\"import-list\"><thead><tr><th>ID</th><th>" + t("length") +
    "</th><th>" + t("angle") + "</th></tr></thead><tbody>" + rows + "</tbody></table>" +
    "<div class=\"row\" style=\"margin-top:10px\">" +
    "<button class=\"btn small\" id=\"imp-ok\">" + t("importAccept") + "</button>" +
    "<button class=\"btn danger small\" id=\"imp-cancel\">" + t("importCancel") + "</button></div>";
  openSheet();
  $("#imp-ok").onclick = () => { closeSheet(); toast(t("importOk")); };
  $("#imp-cancel").onclick = () => { undo(); closeSheet(); };
}


function showScreen(id) {
  $$(".screen").forEach((s) => s.classList.toggle("hidden", s.id !== id));
}

function toast(msg, ms = 1800) {
  const el = $("#toast");
  if (!el) return;
  toast._n = (toast._n || 0) + 1;
  el.textContent = msg;
  el.classList.remove("act");
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), ms);
  speak(msg);
}

// toast with one action button (Undo / Backup); stays a bit longer and is tappable
function toastAction(msg, label, fn, ms = 6000) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = msg + " ";
  const b = document.createElement("button");
  b.type = "button"; b.className = "toast-act"; b.textContent = label;
  b.addEventListener("click", () => { el.classList.remove("show", "act"); try { fn(); } catch (e) { console.warn(e); } });
  el.appendChild(b);
  el.classList.add("show", "act");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show", "act"), ms);
  speak(msg);
}

function storeKey() {
  return "naksha_projects_" + state.user;
}
function loadProjects() {
  try {
    return JSON.parse(localStorage.getItem(storeKey()) || "[]");
  } catch {
    return [];
  }
}
let storageWarned = 0;
function saveProjects(list) {
  try {
    localStorage.setItem(storeKey(), JSON.stringify(list));
    return true;
  } catch (e) {
    // quota full / storage blocked: never lose edits silently
    console.warn("save failed", e);
    if (Date.now() - storageWarned > 8000) {
      storageWarned = Date.now();
      // after the current command's own toast, so the warning is what stays on screen
      setTimeout(() => toastAction(t("storageFull"), t("backupNow"), () => { if (state.project && !$("#screen-editor")?.classList.contains("hidden")) backupJson(); else backupAll(); }, 9000), 30);
    }
    return false;
  }
}

function emptyFloor(name = "Ground", level = 0) {
  return {
    id: "F" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
    name,
    level,
    walls: [],
    doors: [],
    windows: [],
    stairs: [],
    columns: [],
    rooms: [],
    furniture: [],
    mep: []
  };
}
function normalizeFloor(f, fallbackName = "Ground", fallbackLevel = 0) {
  const level = f.level != null ? f.level : fallbackLevel;
  return {
    id: f.id || emptyFloor().id,
    name: f.name || fallbackName || defaultFloorName(level),
    level,
    walls: f.walls || [],
    doors: f.doors || [],
    windows: f.windows || [],
    stairs: f.stairs || [],
    columns: f.columns || [],
    rooms: f.rooms || [],
    furniture: f.furniture || [],
    mep: f.mep || []
  };
}
function attachFloor(i) {
  const f = state.floors[i];
  if (!f) return;
  state.floorIndex = i;
  state.walls = f.walls;
  state.doors = f.doors;
  state.windows = f.windows;
  state.stairs = f.stairs;
  state.columns = f.columns;
  state.rooms = f.rooms;
  state.furniture = f.furniture;
  state.mep = f.mep;
  renderFloorBar();
}
function loadData(d) {
  if (d && d.floors && d.floors.length) {
    state.floors = d.floors.map((f, i) => {
      const level = f.level != null ? f.level : i;
      return normalizeFloor(f, f.name || defaultFloorName(level), level);
    });
    sortFloorsKeep(d.floorIndex);
    attachFloor(Math.max(0, Math.min(state.floorIndex, state.floors.length - 1)));
  } else {
    const f = normalizeFloor({ name: "Ground", level: 0, ...(d || {}) }, "Ground", 0);
    f.level = 0;
    state.floors = [f];
    attachFloor(0);
  }
  if (d && d.northDeg != null) state.northDeg = d.northDeg;
  if (d && d.vastuOn != null) state.vastuOn = d.vastuOn;
  if (d && d.plot) state.plot = { ...state.plot, ...d.plot };
  if (d && d.angleSnap != null) state.angleSnap = d.angleSnap;
  if (d && d.showCornerAngles != null) state.showCornerAngles = d.showCornerAngles;
  if (d && d.showWallAngles != null) state.showWallAngles = d.showWallAngles;
  if (d && d.roofOn != null) state.roofOn = d.roofOn;
  if (d && d.sunHour != null) state.sunHour = d.sunHour;
}
function snapshot() {
  return {
    floors: structuredClone(state.floors),
    floorIndex: state.floorIndex,
    northDeg: state.northDeg,
    vastuOn: state.vastuOn,
    plot: structuredClone(state.plot),
    angleSnap: state.angleSnap,
    showCornerAngles: state.showCornerAngles,
    showWallAngles: state.showWallAngles,
    roofOn: state.roofOn,
    sunHour: state.sunHour
  };
}
function restore(s) {
  loadData(s);
  state.selection = null;
  closeSheet();
  refreshRooms();
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function refreshRooms() {
  state.rooms.splice(0, state.rooms.length, ...detectRooms(state.walls, state.rooms.slice()));
}
function planCentre() {
  if (state.walls.length) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const w of state.walls) {
      minX = Math.min(minX, w.x1, w.x2);
      minY = Math.min(minY, w.y1, w.y2);
      maxX = Math.max(maxX, w.x1, w.x2);
      maxY = Math.max(maxY, w.y1, w.y2);
    }
    return { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };
  }
  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  return { x: ext / 2, y: ext / 2 };
}
function fmtArea(sqft) {
  if (state.settings?.units === "m") return (sqft * 0.092903).toFixed(2) + " m²";
  return Math.round(sqft) + " sq.ft";
}
function floorName(i) {
  const f = state.floors[i];
  if (!f) return "";
  return f.name || defaultFloorName(f.level ?? i);
}
function sortFloorsKeep(preferIndex) {
  const cur = preferIndex != null && state.floors[preferIndex]
    ? state.floors[preferIndex]
    : state.floors[state.floorIndex];
  state.floors.sort((a, b) => (a.level ?? 0) - (b.level ?? 0));
  const i = cur ? state.floors.indexOf(cur) : 0;
  state.floorIndex = i >= 0 ? i : 0;
}
function nextFreeLevel(basement) {
  const levels = state.floors.map((f) => f.level ?? 0);
  if (basement) {
    let lv = Math.min(0, ...levels) - 1;
    while (levels.includes(lv)) lv--;
    return lv;
  }
  let lv = Math.max(0, ...levels) + 1;
  while (levels.includes(lv)) lv++;
  return lv;
}
function renderFloorBar() {
  const bar = $("#floor-bar");
  if (!bar) return;
  const chips = state.floors.map((f, i) => {
    const lab = shortFloorName(f.level ?? 0);
    return `<button type="button" data-fi="${i}" class="${i === state.floorIndex ? "on" : ""}" title="${escapeHtml(f.name || defaultFloorName(f.level ?? 0))}">${escapeHtml(lab)}</button>`;
  }).join("");
  bar.innerHTML = chips +
    `<button type="button" id="fb-add" title="${t("addFloor")}">+</button>` +
    `<button type="button" id="fb-base" title="${t("addBasement")}">+B</button>` +
    `<button type="button" id="fb-copy" title="${t("copyFloor")}">${escapeHtml(t("copyFloor"))}</button>`;
  bar.querySelectorAll("[data-fi]").forEach((b) =>
    b.addEventListener("click", () => switchFloor(parseInt(b.dataset.fi, 10)))
  );
  const a = $("#fb-add"); if (a) a.onclick = () => addFloor(false);
  const bb = $("#fb-base"); if (bb) bb.onclick = () => addFloor(false, { basement: true });
  const c = $("#fb-copy"); if (c) c.onclick = () => addFloor(true);
  const on = bar.querySelector("button.on");
  if (on) on.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" });
}
function switchFloor(i) {
  if (i === state.floorIndex || !state.floors[i]) return;
  persist();
  attachFloor(i);
  state.selection = null;
  closeSheet();
  refreshRooms();
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function switchFloorByLevel(level) {
  const i = state.floors.findIndex((f) => f.level === level);
  if (i < 0) return false;
  switchFloor(i);
  return true;
}
function addFloor(copy, opts = {}) {
  pushUndo();
  let level = opts.level;
  if (level == null) level = nextFreeLevel(!!opts.basement);
  else {
    while (state.floors.some((f) => f.level === level)) {
      level += opts.basement || level < 0 ? -1 : 1;
    }
  }
  const name = defaultFloorName(level);
  const src = copy ? structuredClone(state.floors[state.floorIndex]) : null;
  const freshId = emptyFloor().id;
  const f = src
    ? normalizeFloor({ ...src, id: freshId, name, level }, name, level)
    : emptyFloor(name, level);
  f.id = freshId;
  f.name = name;
  f.level = level;
  state.floors.push(f);
  sortFloorsKeep(state.floors.indexOf(f));
  attachFloor(state.floors.indexOf(f));
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  toast(f.name);
}

function pushUndo() {
  state.undo.push(snapshot());
  if (state.undo.length > 60) state.undo.shift();
  state.redo = [];
  dirty = true;
}

function undo() {
  if (!state.undo.length) return;
  state.redo.push(snapshot());
  restore(state.undo.pop());
  persist();
}
function redo() {
  if (!state.redo.length) return;
  state.undo.push(snapshot());
  restore(state.redo.pop());
  persist();
}

function persist() {
  if (!state.user || !state.project) return;
  const rec = {
    ...state.project,
    settings: state.settings,
    data: snapshot(),
    updated: Date.now()
  };
  state.project = rec;
  const all = loadProjects();
  const i = all.findIndex((p) => p.id === rec.id);
  if (i >= 0) all[i] = rec;
  else all.unshift(rec);
  if (saveProjects(all)) dirty = false;
}

function nextId(prefix, list) {
  const nums = list.map((o) => parseInt(String(o.id).replace(/^[A-Z]/i, ""), 10)).filter((n) => !isNaN(n));
  return prefix + ((nums.length ? Math.max(...nums) : 0) + 1);
}

function wallLen(w) {
  return Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
}

function inchOrMmToFt(val, units) {
  if (units === "m") return (val / 1000) * 3.28084; // mm to ft
  return val / 12; // inches to ft
}

function ftToDisplay(ft, units) {
  if (units === "m") return +(ft * 0.3048).toFixed(2);
  return +ft.toFixed(2);
}
function displayToFt(n, units) {
  if (units === "m") return n / 0.3048;
  return n;
}
function unitLabel() {
  return state.settings?.units === "m" ? "m" : "ft";
}

/* ---------- auth ---------- */
async function tryLogin() {
  const u = $("#login-user").value.trim();
  const p = $("#login-pass").value;
  const h = await sha256Hex(u + ":" + p);
  if (h !== DEMO_HASH) {
    $("#login-err").textContent = t("loginBad");
    return;
  }
  state.user = u;
  localStorage.setItem("naksha_session", u);
  $("#login-err").textContent = "";
  openHome();
}

function openHome() {
  showScreen("screen-home");
  $("#hello-user").textContent = t("hello") + ", " + state.user;
  renderProjectList();
  backupReminder();
}

function renderProjectList() {
  const list = loadProjects().sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const box = $("#project-list");
  if (!list.length) {
    box.innerHTML = `<p class="hint">${t("noProjects")}</p>`;
    return;
  }
  box.innerHTML = list
    .map(
      (p) => `<div class="pcard" data-id="${p.id}">
      <div><h3>${escapeHtml(p.name || "Project")}</h3>
      <span>${new Date(p.updated || p.created).toLocaleString()}</span></div>
      <button class="btn ghost small open-p">${t("open")}</button>
      <button class="btn ghost small del-p">${t("del")}</button>
    </div>`
    )
    .join("");
  box.querySelectorAll(".open-p").forEach((b) =>
    b.addEventListener("click", () => openProject(b.closest(".pcard").dataset.id))
  );
  box.querySelectorAll(".del-p").forEach((b) =>
    b.addEventListener("click", () => {
      // two-step delete: first tap arms the button, second tap deletes; then Undo in a toast
      if (!b.classList.contains("armed")) {
        b.classList.add("armed");
        b.textContent = t("delSure");
        setTimeout(() => { if (b.isConnected) { b.classList.remove("armed"); b.textContent = t("del"); } }, 3500);
        return;
      }
      const id = b.closest(".pcard").dataset.id;
      const all = loadProjects();
      const idx = all.findIndex((p) => p.id === id);
      if (idx < 0) return;
      const [gone] = all.splice(idx, 1);
      saveProjects(all);
      renderProjectList();
      toastAction(t("deleted") + ": " + (gone.name || "Project"), t("undo"), () => {
        const cur = loadProjects();
        if (!cur.some((p) => p.id === gone.id)) { cur.splice(Math.min(idx, cur.length), 0, gone); saveProjects(cur); }
        renderProjectList();
      }, 8000);
    })
  );
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function defaultSettings() {
  return {
    size: "medium",
    scale: 100,
    units: "ft",
    floorHeight: 10,
    plinth: 2,
    lintel: 7,
    outerT: 9 / 12,
    partT: 4 / 12,
    outerC: "#2c3d4f",
    partC: "#c4783a",
    watermark: "Bunty's"
  };
}

function readForm() {
  const units = $("#f-units .on").dataset.v;
  const size = $("#f-size .on").dataset.v;
  let scale = $("#f-scale").value;
  if (scale === "custom") scale = parseFloat($("#f-scale-custom").value) || 100;
  else scale = parseFloat(scale);
  return {
    name: $("#f-name").value.trim() || "Mera ghar",
    settings: {
      size,
      scale,
      units,
      floorHeight: displayToFt(parseFloat($("#f-floor").value) || (units === "m" ? 3.05 : 10), units),
      plinth: displayToFt(parseFloat($("#f-plinth").value) || (units === "m" ? 0.6 : 2), units),
      lintel: displayToFt(parseFloat($("#f-lintel").value) || (units === "m" ? 2.13 : 7), units),
      outerT: inchOrMmToFt(parseFloat($("#f-outer-t").value) || (units === "m" ? 230 : 9), units),
      partT: inchOrMmToFt(parseFloat($("#f-part-t").value) || (units === "m" ? 100 : 4), units),
      outerC: $("#f-outer-c").value,
      partC: $("#f-part-c").value,
      watermark: $("#f-mark").value || "Bunty's"
    },
    plot: {
      w: displayToFt(parseFloat($("#f-plotw")?.value) || (units === "m" ? 9.14 : 30), units),
      d: displayToFt(parseFloat($("#f-plotd")?.value) || (units === "m" ? 15.24 : 50), units),
      front: displayToFt(parseFloat($("#f-sbf")?.value) || (units === "m" ? 1.52 : 5), units),
      back: displayToFt(parseFloat($("#f-sbb")?.value) || (units === "m" ? 0.91 : 3), units),
      left: displayToFt(parseFloat($("#f-sbl")?.value) || (units === "m" ? 0.91 : 3), units),
      right: displayToFt(parseFloat($("#f-sbr")?.value) || (units === "m" ? 0.91 : 3), units)
    }
  };
}

function fillFormDefaults() {
  $("#f-name").value = "Mera ghar";
  $$("#f-size button").forEach((b) => b.classList.toggle("on", b.dataset.v === "medium"));
  $("#f-scale").value = "100";
  $("#f-scale-custom").classList.add("hidden");
  $$("#f-units button").forEach((b) => b.classList.toggle("on", b.dataset.v === "ft"));
  $("#f-floor").value = 10;
  $("#f-plinth").value = 2;
  $("#f-lintel").value = 7;
  $("#f-mark").value = "Bunty's";
  $("#f-outer-t").value = 9;
  $("#f-part-t").value = 4;
  $("#f-outer-u").textContent = "inch";
  $("#f-part-u").textContent = "inch";
  $("#f-outer-c").value = "#2c3d4f";
  $("#f-part-c").value = "#c4783a";
}

function onUnitsChange() {
  const units = $("#f-units .on").dataset.v;
  if (units === "m") {
    $("#f-floor").value = 3.05;
    $("#f-plinth").value = 0.6;
    $("#f-lintel").value = 2.13;
    $("#f-outer-t").value = 230;
    $("#f-part-t").value = 100;
    $("#f-outer-u").textContent = "mm";
    $("#f-part-u").textContent = "mm";
  } else {
    $("#f-floor").value = 10;
    $("#f-plinth").value = 2;
    $("#f-lintel").value = 7;
    $("#f-outer-t").value = 9;
    $("#f-part-t").value = 4;
    $("#f-outer-u").textContent = "inch";
    $("#f-part-u").textContent = "inch";
  }
}

function newProjectFromForm() {
  const { name, settings, plot } = readForm();
  const rec = {
    id: "p" + Date.now().toString(36),
    name,
    settings,
    created: Date.now(),
    updated: Date.now(),
    data: { floors: [emptyFloor("Ground", 0)], floorIndex: 0, northDeg: 0, vastuOn: false, plot }
  };
  const all = loadProjects();
  all.unshift(rec);
  saveProjects(all);
  enterEditor(rec);
}

function openProject(id) {
  const rec = loadProjects().find((p) => p.id === id);
  if (rec) enterEditor(rec);
}

function enterEditor(rec) {
  state.project = rec;
  state.settings = { ...defaultSettings(), ...(rec.settings || {}) };
  const d = rec.data || {};
  state.northDeg = d.northDeg || 0;
  state.vastuOn = !!d.vastuOn;
  state.angleSnap = 45;
  state.showCornerAngles = true;
  state.showWallAngles = true;
  state.roofOn = false;
  state.sunOn = false;
  state.sunHour = 10;
  state.plot = { w: 30, d: 50, front: 5, back: 3, left: 3, right: 3 };
  loadData(d);
  state.selection = null;
  state.undo = [];
  state.redo = [];
  state.tool = "select";
  state.mode = "2d";
  state.drawing = null;
  state.measureStart = null;
  setTool("select");
  $$("#snap-bar [data-snap]").forEach((b) => b.classList.toggle("on", Number(b.dataset.snap) === state.angleSnap));
  $("#ed-title").textContent = rec.name;
  $("#ed-2d3d").textContent = "3D";
  showScreen("screen-editor");
  closeSheet();
  applyI18n();
  const ext = SIZE[state.settings.size] || SIZE.medium;
  state.view.zoom = 1;
  state.view.panX = 40;
  state.view.panY = 80;
  refreshRooms();
  renderFloorBar();
  requestAnimationFrame(() => {
    fitView();
    draw2d();
    show2d();
  });
  // keep reference
  void ext;
}

function leaveEditor() {
  persist();
  if (view3d) view3d.hide();
  show2d();
  openHome();
}

/* ---------- 2D view math ---------- */
function toWorld(sx, sy) {
  const v = state.view;
  return { x: (sx - v.panX) / (v.zoom * PX), y: (sy - v.panY) / (v.zoom * PX) };
}
function toScreen(x, y) {
  const v = state.view;
  return { x: x * v.zoom * PX + v.panX, y: y * v.zoom * PX + v.panY };
}

function snapSetting() {
  return (SIZE[state.settings?.size] || SIZE.medium).snap;
}

function snapPt(x, y, withEnds = true) {
  const snap = snapSetting();
  let sx = Math.round(x / snap) * snap;
  let sy = Math.round(y / snap) * snap;
  if (withEnds) {
    const r = SNAP_END_PX / (state.view.zoom * PX);
    let best = r;
    for (const w of state.walls) {
      for (const p of [
        { x: w.x1, y: w.y1 },
        { x: w.x2, y: w.y2 }
      ]) {
        const d = Math.hypot(p.x - sx, p.y - sy);
        if (d <= best) {
          best = d;
          sx = p.x;
          sy = p.y;
        }
      }
    }
  }
  return { x: sx, y: sy };
}

function normDeg(d) {
  d = Number(d) % 360;
  if (d < 0) d += 360;
  return d;
}
function worldAngle(x1, y1, x2, y2) {
  // 0 = east / +X, CCW, Y-up (canvas Y is down)
  return normDeg(Math.atan2(-(y2 - y1), (x2 - x1)) * 180 / Math.PI);
}
function pointAtAngle(x, y, deg, len) {
  const a = (deg * Math.PI) / 180;
  return { x: x + Math.cos(a) * len, y: y - Math.sin(a) * len };
}
function snapWorldAngle(deg) {
  const step = Number(state.angleSnap) || 0;
  if (!step) return deg;
  return Math.round(deg / step) * step;
}
function snapAngle(x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  if (len < 1e-6) return { x: x1, y: y1 };
  const deg = snapWorldAngle(worldAngle(x1, y1, x2, y2));
  return pointAtAngle(x1, y1, deg, len);
}
function setWallAngle(id, deg, rec = true) {
  const w = state.walls.find((x) => x.id.toUpperCase() === String(id).toUpperCase());
  if (!w) return false;
  const len = wallLen(w);
  if (!(len > 0)) return false;
  if (rec) pushUndo();
  const p = pointAtAngle(w.x1, w.y1, normDeg(deg), len);
  w.x2 = p.x;
  w.y2 = p.y;
  refreshRooms();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}
function lastWallAngleAt(x, y) {
  let best = null, bd = 0.2;
  for (const w of state.walls) {
    const d1 = Math.hypot(w.x2 - x, w.y2 - y);
    const d0 = Math.hypot(w.x1 - x, w.y1 - y);
    if (d1 < bd) { bd = d1; best = worldAngle(w.x1, w.y1, w.x2, w.y2); }
    else if (d0 < bd) { bd = d0; best = worldAngle(w.x2, w.y2, w.x1, w.y1); }
  }
  return best;
}

function distToSeg(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  if (l2 < 1e-9) return { d: Math.hypot(px - x1, py - y1), t: 0 };
  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  const qx = x1 + t * dx, qy = y1 + t * dy;
  return { d: Math.hypot(px - qx, py - qy), t };
}

function hitWall(x, y) {
  const pad = 10 / (state.view.zoom * PX);
  let best = null, bd = Infinity;
  for (const w of state.walls) {
    const hit = distToSeg(x, y, w.x1, w.y1, w.x2, w.y2);
    const th = (w.thickness || 0.5) / 2 + pad;
    if (hit.d <= th && hit.d < bd) {
      bd = hit.d;
      best = { wall: w, t: hit.t };
    }
  }
  return best;
}

function hitStair(x, y) {
  for (const s of state.stairs) {
    if (polyContains(stairPoly(s), x, y)) return s;
  }
  return null;
}
function hitColumn(x, y) {
  for (const c of state.columns || []) {
    const r = Math.max(c.w || 0.75, c.d || 1) / 2 + 0.4;
    if (Math.hypot(x - c.x, y - c.y) < r) return c;
  }
  return null;
}
function hitRoom(x, y) {
  const list = state.rooms || [];
  for (let i = list.length - 1; i >= 0; i--) {
    if (pointInPoly(x, y, list[i].poly)) return list[i];
  }
  return null;
}

function fitView() {
  const c = $("#c2d");
  const w = c.clientWidth || innerWidth;
  const h = c.clientHeight || innerHeight;
  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  // measure the real overlays (top bar, floor chips, snap bar / command bar, tools) so the plan
  // isn't hidden under them on small phones, landscape or with the snap bar on its own row
  let topChrome = 90, botChrome = 140;
  const cr = c.getBoundingClientRect();
  if (cr.height > 0) {
    let tb = 0, bt = cr.height;
    for (const sel of ["#editor-top", "#floor-bar", "#snap-bar"]) {
      const el = $(sel); if (!el || !el.offsetParent) continue;
      const r = el.getBoundingClientRect(); if (r.height) tb = Math.max(tb, r.bottom - cr.top);
    }
    for (const sel of ["#cmd-bar", "#editor-bot"]) {
      const el = $(sel); if (!el || !el.offsetParent) continue;
      const r = el.getBoundingClientRect(); if (r.height) bt = Math.min(bt, r.top - cr.top);
    }
    if (tb > 0) topChrome = tb + 10;
    if (bt < cr.height) botChrome = cr.height - bt + 10;
  }
  const margin = 20;
  const usableH = Math.max(200, h - topChrome - botChrome);
  // fit the drawn plan (so labels are readable on a phone); an empty project fits the whole grid
  let bx = 0, by = 0, bw = ext, bh = ext;
  if (state.walls.length) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const wl of state.walls) {
      minX = Math.min(minX, wl.x1, wl.x2); minY = Math.min(minY, wl.y1, wl.y2);
      maxX = Math.max(maxX, wl.x1, wl.x2); maxY = Math.max(maxY, wl.y1, wl.y2);
    }
    const pad = 4;
    bx = minX - pad; by = minY - pad;
    bw = Math.max(12, maxX - minX + pad * 2); bh = Math.max(12, maxY - minY + pad * 2);
  }
  const zoom = Math.min((w - margin * 2) / (bw * PX), usableH / (bh * PX));
  state.view.zoom = Math.max(0.15, Math.min(zoom, 1.6));
  const z = state.view.zoom * PX;
  state.view.panX = (w - bw * z) / 2 - bx * z;
  state.view.panY = topChrome + Math.max(0, (usableH - bh * z) / 2) - by * z;
}

/* ---------- draw 2D ---------- */
function draw2d(target, opts = {}) {
  const canvas = target || $("#c2d");
  if (!canvas) return;
  labelQueue = null;
  const ctx = canvas.getContext("2d");
  ctx.direction = "ltr"; // RTL page: dimension text like 15' must not be bidi-reordered to '15
  const dpr = Math.min(devicePixelRatio || 1, 2);
  const cssW = canvas.clientWidth || innerWidth;
  const cssH = canvas.clientHeight || innerHeight;
  if (canvas.width !== Math.floor(cssW * dpr) || canvas.height !== Math.floor(cssH * dpr)) {
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);
  ctx.fillStyle = "#f3eee4";
  ctx.fillRect(0, 0, cssW, cssH);

  const v = state.view;
  ctx.save();
  ctx.translate(v.panX, v.panY);
  ctx.scale(v.zoom * PX, v.zoom * PX);

  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  const snap = snapSetting();
  // grid
  ctx.lineWidth = 1 / (v.zoom * PX);
  for (let g = 0; g <= ext + 0.01; g += snap) {
    const major = Math.abs(g % (snap * 10 < 5 ? 5 : 10)) < 1e-6 || g === 0;
    ctx.strokeStyle = major ? "#d4cbb6" : "#e8e1d3";
    ctx.beginPath();
    ctx.moveTo(g, 0);
    ctx.lineTo(g, ext);
    ctx.moveTo(0, g);
    ctx.lineTo(ext, g);
    ctx.stroke();
  }
  ctx.strokeStyle = "#c4b89e";
  ctx.lineWidth = 2 / (v.zoom * PX);
  ctx.strokeRect(0, 0, ext, ext);

  drawPlot(ctx);

  if (state.vastuOn) drawVastu(ctx, ext);

  // rooms (under walls)
  const pc = planCentre();
  for (const r of state.rooms || []) {
    const vck = state.vastuOn ? vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang) : null;
    const sel = state.selection && state.selection.type === "room" && state.selection.id === r.id;
    ctx.beginPath();
    r.poly.forEach((pt, i) => i ? ctx.lineTo(pt.x, pt.y) : ctx.moveTo(pt.x, pt.y));
    ctx.closePath();
    ctx.fillStyle = vck ? vck.color + "55" : (r.floorColor || "#d9d1c3") + "99";
    ctx.fill();
    if (sel) { ctx.strokeStyle = "#e8a54b"; ctx.lineWidth = 0.12; ctx.stroke(); }
  }

  // walls
  for (const w of state.walls) {
    const sel = state.selection && state.selection.type === "wall" && state.selection.id === w.id;
    ctx.strokeStyle = w.colorOut || w.color || "#2c3d4f";
    ctx.lineWidth = w.thickness || 0.75;
    ctx.lineCap = "butt";
    ctx.lineJoin = "miter";
    ctx.beginPath();
    ctx.moveTo(w.x1, w.y1);
    ctx.lineTo(w.x2, w.y2);
    ctx.stroke();
    if (sel) {
      ctx.strokeStyle = "#e8a54b";
      ctx.lineWidth = (w.thickness || 0.75) + 0.2;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.moveTo(w.x1, w.y1);
      ctx.lineTo(w.x2, w.y2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  // doors
  for (const d of state.doors) {
    const w = state.walls.find((x) => x.id === d.wallId);
    if (!w) continue;
    drawDoor(ctx, w, d, state.selection && state.selection.type === "door" && state.selection.id === d.id);
  }

  // windows
  for (const k of state.windows || []) {
    const w = state.walls.find((x) => x.id === k.wallId);
    if (!w) continue;
    drawWindow(ctx, w, k, state.selection && state.selection.type === "window" && state.selection.id === k.id);
  }

  // columns
  for (const c of state.columns || []) drawColumn2d(ctx, c, state.selection && state.selection.type === "column" && state.selection.id === c.id);

  // furniture + MEP
  for (const f of state.furniture || []) drawFurniture2d(ctx, f, state.selection && state.selection.type === "furniture" && state.selection.id === f.id);
  for (const m of state.mep || []) drawMep2d(ctx, m, state.selection && state.selection.type === "mep" && state.selection.id === m.id);

  // stairs
  for (const s of state.stairs) drawStair2d(ctx, s, state.selection && state.selection.type === "stair" && state.selection.id === s.id);

  // labels + dimensions (hide or stagger when zoomed out)
  const inv = 1 / (v.zoom * PX);
  const pxu = v.zoom * PX;
  ctx.save();
  // labels are queued with a priority and drawn without overlapping each other:
  // wall ids (needed for voice) > door/window ids > room names > dimensions > areas > corner angles
  labelQueue = [];
  labelPri = 1;
  for (const r of state.rooms || []) {
    const minDim = Math.sqrt(Math.abs(r.area) || 1) * pxu;
    if (minDim < 28) continue;
    const vck = state.vastuOn ? vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang) : null;
    const nm = (r.name ? r.name + "  " : "") + r.id;
    const ar = fmtArea(r.area);
    const extra = vck ? "  " + vck.zone : "";
    labelPri = 2;
    label(ctx, nm, r.cx, r.cy - 0.45, inv, vck ? vck.color : "#3a3228", true);
    labelPri = 4;
    if (minDim >= 48) label(ctx, ar + extra, r.cx, r.cy + 0.55, inv, "#5a5044");
  }
  for (const w of state.walls) {
    const mx = (w.x1 + w.x2) / 2, my = (w.y1 + w.y2) / 2;
    const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
    const len = Math.hypot(dx, dy) || 1;
    const screenLen = len * pxu;
    if (screenLen < 22) continue;
    const nx = -dy / len, ny = dx / len;
    const off = (w.thickness || 0.75) / 2 + 0.7;
    // place id near 1/3, dimension near 2/3 when both shown
    if (screenLen >= 110) {
      const ix = w.x1 + dx * 0.32, iy = w.y1 + dy * 0.32;
      const dxp = w.x1 + dx * 0.68, dyp = w.y1 + dy * 0.68;
      labelPri = 0;
      label(ctx, w.id, ix + nx * off, iy + ny * off, inv, "#1a1408");
      const dim = fmtLen(len) + (state.showWallAngles ? "  " + Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2)) + "°" : "");
      labelPri = 3;
      label(ctx, dim, dxp - nx * (off + 0.2), dyp - ny * (off + 0.2), inv, "#5a5044", true);
    } else {
      labelPri = 0;
      label(ctx, w.id, mx + nx * off, my + ny * off, inv, "#1a1408");
    }
  }
  labelPri = 1;
  if (pxu >= 10) {
    for (const d of state.doors) {
      const w = state.walls.find((x) => x.id === d.wallId);
      if (!w) continue;
      const p = pointOnWall(w, d.t ?? 0.5);
      label(ctx, d.id, p.x, p.y - 0.85, inv, "#1d3b5c");
    }
    for (const k of state.windows || []) {
      const w = state.walls.find((x) => x.id === k.wallId);
      if (!w) continue;
      const p = pointOnWall(w, k.t ?? 0.5);
      label(ctx, k.id, p.x, p.y + 0.85, inv, "#2a5a4a");
    }
    for (const c of state.columns || []) label(ctx, c.id, c.x, c.y - 1.0, inv, "#3a2a18");
    for (const s of state.stairs) label(ctx, s.id, s.x, s.y - 1.2, inv, "#3a2a18");
    for (const f of state.furniture || []) label(ctx, f.id, f.x, f.y - (f.d || 2) / 2 - 0.4, inv, "#3a2a18");
    for (const m of state.mep || []) label(ctx, m.id, m.x, m.y - 0.7, inv, "#2a3a4a");
  }
  labelPri = 5;
  if (state.showCornerAngles) drawCornerAngles(ctx, inv);
  flushLabels(ctx);
  ctx.restore();

  // live drawing
  if (state.drawing) {
    const d = state.drawing;
    ctx.strokeStyle = d.color || "#2c3d4f";
    ctx.lineWidth = d.thickness || 0.75;
    ctx.setLineDash([0.4, 0.3]);
    ctx.beginPath();
    ctx.moveTo(d.x1, d.y1);
    ctx.lineTo(d.x2, d.y2);
    ctx.stroke();
    ctx.setLineDash([]);
    const len = Math.hypot(d.x2 - d.x1, d.y2 - d.y1);
    const ang = worldAngle(d.x1, d.y1, d.x2, d.y2);
    label(ctx, fmtLen(len) + "  " + Math.round(ang) + "°", (d.x1 + d.x2) / 2, (d.y1 + d.y2) / 2 - 0.6, inv, "#1a1408", true);
  }
  if (state.measureStart) {
    ctx.fillStyle = "#e8a54b";
    ctx.beginPath();
    ctx.arc(state.measureStart.x, state.measureStart.y, 0.25, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // north arrow (screen space)
  drawNorthArrow(ctx, cssW, cssH);

  if (opts.watermark) {
    ctx.fillStyle = "rgba(30,24,16,0.35)";
    ctx.font = "600 18px system-ui, sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(opts.watermark, cssW - 16, cssH - 18);
  }
}

let labelQueue = null;
let labelPri = 0;
let labelK = 1; // >1 while rendering a PDF so labels stay readable on paper
function flushLabels(ctx) {
  const q = labelQueue || [];
  labelQueue = null;
  q.sort((a, b) => a.pri - b.pri || a.i - b.i);
  const boxes = [];
  ctx.save();
  for (const it of q) {
    ctx.setTransform(it.T);
    ctx.font = (it.bold ? "650 " : "600 ") + "12px system-ui, sans-serif";
    const m = ctx.measureText(it.text).width;
    const p = it.T.transformPoint(new DOMPoint(it.x, it.y));
    const k = Math.abs(it.T.a * it.inv) || 1; // device px per label px
    const hw = (m / 2 + 2) * k * labelK, hh = 7 * k * labelK;
    const box = [p.x - hw, p.y - hh, p.x + hw, p.y + hh];
    if (boxes.some((o) => box[0] < o[2] && box[2] > o[0] && box[1] < o[3] && box[3] > o[1])) continue;
    boxes.push(box);
    drawLabel(ctx, it.text, it.x, it.y, it.inv, it.color, it.bold);
  }
  ctx.restore();
}
function label(ctx, text, x, y, inv, color, bold) {
  if (labelQueue) {
    labelQueue.push({ T: ctx.getTransform(), text: String(text), x, y, inv, color, bold, pri: labelPri, i: labelQueue.length });
    return;
  }
  drawLabel(ctx, text, x, y, inv, color, bold);
}
function drawLabel(ctx, text, x, y, inv, color, bold) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(inv * labelK, inv * labelK);
  ctx.fillStyle = color;
  ctx.font = (bold ? "650 " : "600 ") + "12px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.strokeStyle = "rgba(243,238,228,0.85)";
  ctx.lineWidth = 3;
  ctx.strokeText(text, 0, 0);
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

function fmtLen(ft) {
  const u = state.settings?.units || "ft";
  if (u === "m") return (ft * 0.3048).toFixed(2) + " m";
  const whole = Math.floor(ft + 1e-6);
  const inch = Math.round((ft - whole) * 12);
  if (inch === 0) return whole + "'";
  if (inch === 12) return whole + 1 + "'";
  return `${whole}' ${inch}"`;
}

function pointOnWall(w, t) {
  return { x: w.x1 + (w.x2 - w.x1) * t, y: w.y1 + (w.y2 - w.y1) * t };
}

function drawDoor(ctx, w, d, sel) {
  const len = wallLen(w);
  const t0 = (d.t ?? 0.5) - (d.width || 3) / 2 / len;
  const t1 = (d.t ?? 0.5) + (d.width || 3) / 2 / len;
  const a = pointOnWall(w, t0);
  const b = pointOnWall(w, t1);
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const L = Math.hypot(dx, dy) || 1;
  const nx = -dy / L, ny = dx / L;
  const swing = d.width || 3;
  ctx.save();
  // cut mark
  ctx.strokeStyle = "#f3eee4";
  ctx.lineWidth = (w.thickness || 0.75) + 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  // swing arc
  ctx.strokeStyle = sel ? "#e8a54b" : "#1d3b5c";
  ctx.lineWidth = 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(a.x + nx * swing, a.y + ny * swing);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(a.x, a.y, swing, Math.atan2(ny, nx), Math.atan2(b.y - a.y, b.x - a.x), false);
  ctx.stroke();
  ctx.restore();
}

function drawWindow(ctx, w, k, sel) {
  const len = wallLen(w);
  const t0 = (k.t ?? 0.5) - (k.width || 4) / 2 / len;
  const t1 = (k.t ?? 0.5) + (k.width || 4) / 2 / len;
  const a = pointOnWall(w, t0), b = pointOnWall(w, t1);
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const L = Math.hypot(dx, dy) || 1;
  const nx = -dy / L, ny = dx / L;
  const o = 0.28;
  ctx.save();
  ctx.strokeStyle = sel ? "#e8a54b" : "#2a5a4a";
  ctx.lineWidth = 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x + nx * o, a.y + ny * o);
  ctx.lineTo(b.x + nx * o, b.y + ny * o);
  ctx.lineTo(b.x - nx * o, b.y - ny * o);
  ctx.lineTo(a.x - nx * o, a.y - ny * o);
  ctx.closePath();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo((a.x + b.x) / 2 + nx * o, (a.y + b.y) / 2 + ny * o);
  ctx.lineTo((a.x + b.x) / 2 - nx * o, (a.y + b.y) / 2 - ny * o);
  ctx.stroke();
  ctx.restore();
}
function drawColumn2d(ctx, c, sel) {
  const ww = c.w || 0.75, dd = c.d || 1;
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.rotate(((c.rot || 0) * Math.PI) / 180);
  ctx.fillStyle = sel ? "rgba(232,165,75,0.55)" : "#5c5348";
  ctx.strokeStyle = sel ? "#e8a54b" : "#2a241c";
  ctx.lineWidth = 0.07;
  ctx.fillRect(-ww / 2, -dd / 2, ww, dd);
  ctx.strokeRect(-ww / 2, -dd / 2, ww, dd);
  ctx.restore();
}
function drawStair2d(ctx, s, sel) {
  const g = stairGeometry(s);
  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.rotate(((g.type === "spiral" ? 0 : s.rot || 0) * Math.PI) / 180);
  ctx.strokeStyle = sel ? "#e8a54b" : "#5a4632";
  ctx.lineWidth = sel ? 0.1 : 0.06;
  if (g.type === "spiral") {
    const R = g.rad, n = Math.max(6, Math.min(g.R, 16));
    ctx.fillStyle = "rgba(196, 168, 120, 0.35)";
    ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, 0.35, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < n; i++) {
      const a = (i * Math.PI * 2) / n;
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * 0.35, Math.sin(a) * 0.35); ctx.lineTo(Math.cos(a) * R, Math.sin(a) * R); ctx.stroke();
    }
  } else {
    ctx.fillStyle = s.base === "ground" ? "rgba(170, 160, 150, 0.45)" : "rgba(196, 168, 120, 0.35)";
    for (const r of g.treads) { ctx.beginPath(); ctx.rect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0); ctx.fill(); ctx.stroke(); }
    ctx.fillStyle = "rgba(160, 135, 95, 0.4)";
    for (const r of g.land) { ctx.beginPath(); ctx.rect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0); ctx.fill(); ctx.stroke(); }
    // walking line + arrow (UP)
    const pts = [];
    const all = [...g.treads, ...g.land].sort((a, b) => a.top - b.top);
    for (const r of all) pts.push([(r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2]);
    if (pts.length > 1) {
      ctx.strokeStyle = sel ? "#e8a54b" : "rgba(90,70,50,0.8)";
      ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (const p of pts.slice(1)) ctx.lineTo(p[0], p[1]); ctx.stroke();
      const [x2, y2] = pts[pts.length - 1], [x1, y1] = pts[pts.length - 2];
      const a = Math.atan2(y2 - y1, x2 - x1);
      ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(x2 - Math.cos(a - 0.5) * 0.6, y2 - Math.sin(a - 0.5) * 0.6); ctx.moveTo(x2, y2); ctx.lineTo(x2 - Math.cos(a + 0.5) * 0.6, y2 - Math.sin(a + 0.5) * 0.6); ctx.stroke();
    }
  }
  ctx.restore();
}

const VASTU_ZONES = [
  "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"
];

function planCenter(ext) {
  if (state.walls.length) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const w of state.walls) {
      minX = Math.min(minX, w.x1, w.x2);
      minY = Math.min(minY, w.y1, w.y2);
      maxX = Math.max(maxX, w.x1, w.x2);
      maxY = Math.max(maxY, w.y1, w.y2);
    }
    return { x: (minX + maxX) / 2, y: (minY + maxY) / 2, r: Math.max(maxX - minX, maxY - minY) / 2 + 4 };
  }
  return { x: ext / 2, y: ext / 2, r: ext * 0.42 };
}

function drawVastu(ctx, ext) {
  const c = planCenter(ext);
  const north = (state.northDeg * Math.PI) / 180;
  const inv = 1 / (state.view.zoom * PX);
  const rpx = c.r * state.view.zoom * PX;
  // 16 sectors. V1 starts at North, clockwise. In canvas, north (0) is -Y.
  for (let i = 0; i < 16; i++) {
    const a0 = -Math.PI / 2 + north + (i - 0.5) * (Math.PI / 8);
    const a1 = a0 + Math.PI / 8;
    ctx.beginPath();
    ctx.moveTo(c.x, c.y);
    ctx.arc(c.x, c.y, c.r, a0, a1);
    ctx.closePath();
    ctx.fillStyle = i % 2 === 0 ? "rgba(232,165,75,0.10)" : "rgba(44,61,79,0.08)";
    ctx.fill();
    ctx.strokeStyle = "rgba(90,80,68,0.45)";
    ctx.lineWidth = 0.04;
    ctx.stroke();
    const mid = (a0 + a1) / 2;
    if (rpx >= 90) {
      const lx = c.x + Math.cos(mid) * c.r * 0.62;
      const ly = c.y + Math.sin(mid) * c.r * 0.62;
      const aStart = normDeg(i * 22.5 - 11.25);
      const aEnd = normDeg((i + 1) * 22.5 - 11.25);
      const rng = `${Math.round(aStart)}–${Math.round(aEnd)}°`;
      const txt = rpx >= 150 ? `V${i + 1} ${VASTU_ZONES[i]}  ${rng}` : (rpx >= 120 ? `V${i + 1} ${rng}` : `V${i + 1}`);
      label(ctx, txt, lx, ly, inv, "#4a3e2a", true);
    }
  }
  // 360° compass ring, 0 at north, clockwise, rotates with northDeg
  const r0 = c.r;
  const r1 = c.r * 1.08;
  const r2 = c.r * 1.16;
  ctx.beginPath();
  ctx.arc(c.x, c.y, r1, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(90,70,40,0.7)";
  ctx.lineWidth = 0.06;
  ctx.stroke();
  for (let deg = 0; deg < 360; deg += 5) {
    const a = -Math.PI / 2 + north + (deg * Math.PI) / 180;
    const major = deg % 10 === 0;
    const inner = major ? r0 * 1.02 : r0 * 1.045;
    const outer = major ? r2 : r1;
    ctx.beginPath();
    ctx.moveTo(c.x + Math.cos(a) * inner, c.y + Math.sin(a) * inner);
    ctx.lineTo(c.x + Math.cos(a) * outer, c.y + Math.sin(a) * outer);
    ctx.strokeStyle = major ? "rgba(60,45,25,0.85)" : "rgba(90,70,40,0.55)";
    ctx.lineWidth = major ? 0.05 : 0.03;
    ctx.stroke();
    if (major && rpx >= 100) {
      const lx = c.x + Math.cos(a) * r2 * 1.08;
      const ly = c.y + Math.sin(a) * r2 * 1.08;
      const num = deg === 0 ? "0 / 360" : String(deg);
      label(ctx, num, lx, ly, inv, "#3a2e1c", true);
    }
  }
  const dirs = [[0, "N", "#c0392b"], [90, "E", "#1a1408"], [180, "S", "#1a1408"], [270, "W", "#1a1408"]];
  for (const [deg, nm, col] of dirs) {
    const a = -Math.PI / 2 + north + (deg * Math.PI) / 180;
    const lx = c.x + Math.cos(a) * r0 * 0.88;
    const ly = c.y + Math.sin(a) * r0 * 0.88;
    if (rpx >= 80) label(ctx, nm, lx, ly, inv, col, true);
  }
  ctx.beginPath();
  ctx.arc(c.x, c.y, 0.5, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(232,165,75,0.5)";
  ctx.fill();
}

function drawPlot(ctx) {
  const p = state.plot;
  if (!p || !(p.w > 0) || !(p.d > 0)) return;
  ctx.save();
  ctx.strokeStyle = "rgba(80,60,30,0.55)";
  ctx.setLineDash([0.6, 0.35]);
  ctx.lineWidth = 0.08;
  ctx.strokeRect(0, 0, p.w, p.d);
  ctx.setLineDash([]);
  const f = p.front || 0, b = p.back || 0, l = p.left || 0, r = p.right || 0;
  if (f + b < p.d - 0.2 && l + r < p.w - 0.2) {
    ctx.strokeStyle = "rgba(160,60,40,0.4)";
    ctx.setLineDash([0.35, 0.25]);
    ctx.lineWidth = 0.05;
    ctx.strokeRect(l, f, p.w - l - r, p.d - f - b);
    ctx.setLineDash([]);
  }
  ctx.restore();
}

function drawFurniture2d(ctx, f, sel) {
  const kind = FURNITURE[f.kind] || FURNITURE.bed;
  ctx.save();
  ctx.translate(f.x, f.y);
  ctx.rotate(((f.rot || 0) * Math.PI) / 180);
  drawFixture2d(ctx, f, kind, sel);
  ctx.restore();
}
function drawMep2d(ctx, m, sel) {
  const kind = MEP[m.kind] || MEP.light;
  ctx.save();
  ctx.fillStyle = kind.color;
  ctx.strokeStyle = sel ? "#e8a54b" : "rgba(0,0,0,0.4)";
  ctx.lineWidth = sel ? 0.12 : 0.05;
  ctx.beginPath();
  if (kind.kind === "p") ctx.rect(m.x - 0.35, m.y - 0.35, 0.7, 0.7);
  else ctx.arc(m.x, m.y, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawCornerAngles(ctx, inv) {
  const eps = 0.18;
  const nodes = [];
  const add = (x, y, wall, fromStart) => {
    let n = nodes.find((p) => Math.hypot(p.x - x, p.y - y) < eps);
    if (!n) { n = { x, y, arms: [] }; nodes.push(n); }
    const ox = fromStart ? wall.x2 : wall.x1;
    const oy = fromStart ? wall.y2 : wall.y1;
    n.arms.push({ wall, ang: Math.atan2(oy - y, ox - x) });
  };
  for (const w of state.walls) {
    add(w.x1, w.y1, w, true);
    add(w.x2, w.y2, w, false);
  }
  ctx.save();
  for (const n of nodes) {
    if (n.arms.length < 2) continue;
    const arms = n.arms.slice().sort((a, b) => a.ang - b.ang);
    for (let i = 0; i < arms.length; i++) {
      const a0 = arms[i].ang;
      const a1 = arms[(i + 1) % arms.length].ang;
      let delta = a1 - a0;
      if (delta <= 0) delta += Math.PI * 2;
      const deg = delta * 180 / Math.PI;
      if (deg < 2 || deg > 179.5) continue;
      const rad = 1.15;
      ctx.beginPath();
      ctx.arc(n.x, n.y, rad, a0, a0 + delta);
      ctx.strokeStyle = "rgba(160,80,30,0.7)";
      ctx.lineWidth = 0.06;
      ctx.stroke();
      const mid = a0 + delta / 2;
      label(ctx, Math.round(deg) + "°", n.x + Math.cos(mid) * (rad + 0.45), n.y + Math.sin(mid) * (rad + 0.45), inv, "#7a4a18", true);
    }
  }
  ctx.restore();
}

function drawNorthArrow(ctx, w, h) {
  const x = w - 36, y = 36;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((state.northDeg * Math.PI) / 180);
  ctx.fillStyle = "#1a1408";
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(7, 12);
  ctx.lineTo(0, 7);
  ctx.lineTo(-7, 12);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#c0392b";
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(5, 0);
  ctx.lineTo(-5, 0);
  ctx.closePath();
  ctx.fill();
  ctx.font = "700 11px system-ui";
  ctx.textAlign = "center";
  ctx.fillStyle = "#1a1408";
  ctx.fillText("N", 0, -20);
  ctx.restore();
}

/* ---------- tools / input ---------- */
function setTool(tool) {
  state.tool = tool;
  state.drawing = null;
  if (tool !== "measure") state.measureStart = null;
  $$("#tools [data-tool]").forEach((b) => b.classList.toggle("on", b.dataset.tool === tool));
  if (tool === "measure") toast(t("measureHint"), 2200);
  draw2d();
}

function canvasPos(ev, canvas) {
  const r = canvas.getBoundingClientRect();
  return { x: ev.clientX - r.left, y: ev.clientY - r.top };
}

function wallProps(type) {
  const s = state.settings;
  if (type === "partition") return { thickness: s.partT, color: s.partC, type: "partition" };
  return { thickness: s.outerT, color: s.outerC, type: "outer" };
}

function addWall(x1, y1, x2, y2, type) {
  const len = Math.hypot(x2 - x1, y2 - y1);
  if (len < MIN_WALL) return null;
  pushUndo();
  const p = wallProps(type);
  const w = {
    id: nextId("W", state.walls),
    type: p.type,
    x1, y1, x2, y2,
    thickness: p.thickness,
    color: p.color,
    colorIn: p.color,
    colorOut: p.color,
    height: state.settings.floorHeight
  };
  state.walls.push(w);
  refreshRooms();
  persist();
  return w;
}

function setWallLength(id, ft, rec = true) {
  const w = state.walls.find((x) => x.id.toUpperCase() === id.toUpperCase());
  if (!w || !(ft > 0)) return false;
  if (rec) pushUndo();
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const len = Math.hypot(dx, dy) || 1;
  w.x2 = w.x1 + (dx / len) * ft;
  w.y2 = w.y1 + (dy / len) * ft;
  refreshRooms();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}

function deleteWall(id) {
  const w = state.walls.find((x) => x.id.toUpperCase() === id.toUpperCase());
  if (!w) return false;
  pushUndo();
  state.walls = state.walls.filter((x) => x.id !== w.id);
  state.doors = state.doors.filter((d) => d.wallId !== w.id);
  state.windows = state.windows.filter((d) => d.wallId !== w.id);
  if (state.floors[state.floorIndex]) {
    state.floors[state.floorIndex].walls = state.walls;
    state.floors[state.floorIndex].doors = state.doors;
    state.floors[state.floorIndex].windows = state.windows;
  }
  refreshRooms();
  if (state.selection && state.selection.id === w.id) state.selection = null;
  closeSheet();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}

function bindCanvas() {
  const c = $("#c2d");
  const stage = $("#stage");
  let lastTap = 0;
  let pan0 = null;
  let pinch0 = null;
  let swipe0 = null;
  let moved = false;
  let multi = false; // a two-finger gesture happened since the first finger went down

  const getTouches = () => [...state.pointers.values()];

  stage.addEventListener("pointerdown", (ev) => {
    try { stage.setPointerCapture?.(ev.pointerId); } catch {}
    const p = canvasPos(ev, c);
    state.pointers.set(ev.pointerId, { x: p.x, y: p.y, t: Date.now() });
    const pts = getTouches();
    moved = false;
    if (pts.length === 1) multi = false;
    if (pts.length >= 2) multi = true;
    if (pts.length === 2) {
      state.drawing = null;
      const [a, b] = pts;
      pinch0 = {
        dist: Math.hypot(a.x - b.x, a.y - b.y),
        mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        zoom: state.view.zoom,
        panX: state.view.panX,
        panY: state.view.panY
      };
      swipe0 = { y: (a.y + b.y) / 2, dist: pinch0.dist, t: Date.now() };
      return;
    }
    if (state.mode === "3d") return;
    if (state.tool === "select" || ev.shiftKey) {
      pan0 = { x: p.x, y: p.y, panX: state.view.panX, panY: state.view.panY };
    } else if (state.tool === "outer" || state.tool === "partition") {
      const wpt = snapPt(...Object.values(toWorld(p.x, p.y)));
      const pr = wallProps(state.tool);
      state.drawing = { x1: wpt.x, y1: wpt.y, x2: wpt.x, y2: wpt.y, ...pr };
      draw2d();
    }
  });

  stage.addEventListener("pointermove", (ev) => {
    if (!state.pointers.has(ev.pointerId)) return;
    const p = canvasPos(ev, c);
    state.pointers.set(ev.pointerId, { x: p.x, y: p.y, t: Date.now() });
    const pts = getTouches();
    if (pts.length === 2 && pinch0) {
      const [a, b] = pts;
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const factor = dist / (pinch0.dist || 1);
      const z = Math.max(0.2, Math.min(6, pinch0.zoom * factor));
      const world = {
        x: (pinch0.mid.x - pinch0.panX) / (pinch0.zoom * PX),
        y: (pinch0.mid.y - pinch0.panY) / (pinch0.zoom * PX)
      };
      state.view.zoom = z;
      state.view.panX = mid.x - world.x * z * PX;
      state.view.panY = mid.y - world.y * z * PX;
      if (state.mode === "2d") draw2d();
      return;
    }
    if (state.mode === "3d") return;
    if (state.drawing && pts.length === 1) {
      moved = true;
      const d0 = state.drawing;
      const raw = toWorld(p.x, p.y);
      // 1) an existing wall end close to the finger wins (closes rooms exactly)
      const r = SNAP_END_PX / (state.view.zoom * PX);
      let endHit = null, bestD = r * 0.9;
      for (const w of state.walls) {
        for (const q of [{ x: w.x1, y: w.y1 }, { x: w.x2, y: w.y2 }]) {
          const dd = Math.hypot(q.x - raw.x, q.y - raw.y);
          if (dd < bestD && (q.x !== d0.x1 || q.y !== d0.y1)) { bestD = dd; endHit = q; }
        }
      }
      if (endHit) {
        d0.x2 = endHit.x;
        d0.y2 = endHit.y;
      } else {
        // 2) otherwise keep the angle snap (Off / 15 / 45 / 90) and round the length to the grid.
        // (Before, the grid-snapped point always "won", so the angle snap never applied.)
        const len = Math.hypot(raw.x - d0.x1, raw.y - d0.y1);
        const deg = snapWorldAngle(worldAngle(d0.x1, d0.y1, raw.x, raw.y));
        const g = snapSetting();
        const L = state.angleSnap ? Math.round(len / g) * g : len;
        if (state.angleSnap) {
          const q = pointAtAngle(d0.x1, d0.y1, deg, L);
          d0.x2 = q.x;
          d0.y2 = q.y;
        } else {
          const q = snapPt(raw.x, raw.y, false);
          d0.x2 = q.x;
          d0.y2 = q.y;
        }
      }
      draw2d();
      return;
    }
    if (pan0 && pts.length === 1) {
      const dx = p.x - pan0.x, dy = p.y - pan0.y;
      if (Math.hypot(dx, dy) > 4) moved = true;
      state.view.panX = pan0.panX + dx;
      state.view.panY = pan0.panY + dy;
      draw2d();
    }
  });

  const endPtr = (ev) => {
    const had = state.pointers.has(ev.pointerId);
    const p = canvasPos(ev, c);
    const ptsBefore = getTouches();
    state.pointers.delete(ev.pointerId);

    // two-finger swipe up / down
    if (swipe0 && ptsBefore.length >= 2 && state.pointers.size < 2) {
      const [a, b] = ptsBefore;
      const midY = (a.y + b.y) / 2;
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const dy = midY - swipe0.y;
      const dDist = Math.abs(dist - swipe0.dist);
      if (dDist < 50) {
        if (dy < -70) switchMode("3d");
        else if (dy > 70) switchMode("2d");
      }
      pinch0 = null;
      swipe0 = null;
      pan0 = null;
      state.drawing = null;
      return;
    }

    if (state.pointers.size === 0) {
      pinch0 = null;
      swipe0 = null;
    }
    if (multi) {
      // last finger of a pinch / two-finger swipe: never treat it as a tap or a wall
      if (state.pointers.size === 0) multi = false;
      pan0 = null;
      state.drawing = null;
      return;
    }
    if (!had || state.mode === "3d") {
      pan0 = null;
      return;
    }

    if (state.drawing) {
      const d = state.drawing;
      state.drawing = null;
      const w = addWall(d.x1, d.y1, d.x2, d.y2, d.type);
      if (w) {
        state.selection = { type: "wall", id: w.id };
        openWallSheet(w);
      }
      draw2d();
      pan0 = null;
      return;
    }

    if (moved) {
      pan0 = null;
      return;
    }

    // tap
    const world = toWorld(p.x, p.y);
    if (state.tool === "measure") {
      onMeasureTap(world);
    } else if (state.tool === "door") {
      const hit = hitWall(world.x, world.y);
      if (!hit) toast(t("wallNeed"));
      else placeDoor(hit.wall, hit.t);
    } else if (state.tool === "window") {
      const hit = hitWall(world.x, world.y);
      if (!hit) toast(t("wallNeed"));
      else placeWindow(hit.wall, hit.t);
    } else if (state.tool === "column") {
      placeColumn(snapPt(world.x, world.y, false));
    } else if (state.tool === "stair") {
      placeStair(snapPt(world.x, world.y, false));
    } else if (state.tool === "furniture") {
      const hit = hitFurniture(world.x, world.y);
      if (hit) { state.selection = { type: "furniture", id: hit.id }; openFurnitureSheet(hit); draw2d(); }
      else placeFurniture(snapPt(world.x, world.y, false));
    } else if (state.tool === "mep") {
      const hit = hitMep(world.x, world.y);
      if (hit) { state.selection = { type: "mep", id: hit.id }; openMepSheet(hit); draw2d(); }
      else placeMep(snapPt(world.x, world.y, false));
    } else {
      const fu = hitFurniture(world.x, world.y);
      if (fu) {
        state.selection = { type: "furniture", id: fu.id };
        openFurnitureSheet(fu);
        draw2d();
        pan0 = null;
        return;
      }
      const me = hitMep(world.x, world.y);
      if (me) {
        state.selection = { type: "mep", id: me.id };
        openMepSheet(me);
        draw2d();
        pan0 = null;
        return;
      }
      const col = hitColumn(world.x, world.y);
      if (col) {
        state.selection = { type: "column", id: col.id };
        openColumnSheet(col);
        draw2d();
        pan0 = null;
        return;
      }
      const st = hitStair(world.x, world.y);
      if (st) {
        state.selection = { type: "stair", id: st.id };
        openStairSheet(st);
        draw2d();
        pan0 = null;
        return;
      }
      const hit = hitWall(world.x, world.y);
      if (hit) {
        const door = state.doors.find((d) => d.wallId === hit.wall.id && Math.abs((d.t ?? 0.5) - hit.t) * wallLen(hit.wall) < (d.width || 3) / 2 + 0.3);
        const win = state.windows.find((d) => d.wallId === hit.wall.id && Math.abs((d.t ?? 0.5) - hit.t) * wallLen(hit.wall) < (d.width || 4) / 2 + 0.3);
        if (door && (!win || Math.abs((door.t ?? 0.5) - hit.t) <= Math.abs((win.t ?? 0.5) - hit.t))) {
          state.selection = { type: "door", id: door.id };
          openDoorSheet(door);
        } else if (win) {
          state.selection = { type: "window", id: win.id };
          openWindowSheet(win);
        } else {
          state.selection = { type: "wall", id: hit.wall.id };
          openWallSheet(hit.wall);
        }
      } else {
        const rm = hitRoom(world.x, world.y);
        if (rm) {
          state.selection = { type: "room", id: rm.id };
          openRoomSheet(rm);
        } else {
          state.selection = null;
          closeSheet();
        }
      }
      draw2d();
    }
    pan0 = null;
    lastTap = Date.now();
    void lastTap;
  };

  stage.addEventListener("pointerup", endPtr);
  stage.addEventListener("pointercancel", endPtr);
  stage.addEventListener("lostpointercapture", () => {});

  stage.addEventListener(
    "wheel",
    (ev) => {
      if (state.mode !== "2d") return;
      ev.preventDefault();
      const p = canvasPos(ev, c);
      const world = toWorld(p.x, p.y);
      const z = Math.max(0.2, Math.min(6, state.view.zoom * (ev.deltaY > 0 ? 0.9 : 1.1)));
      state.view.zoom = z;
      state.view.panX = p.x - world.x * z * PX;
      state.view.panY = p.y - world.y * z * PX;
      draw2d();
    },
    { passive: false }
  );

  addEventListener("resize", () => {
    if (state.mode === "2d") draw2d();
    else if (view3d) view3d.resize();
  });
}

function onMeasureTap(world) {
  if (!state.measureStart) {
    state.measureStart = snapPt(world.x, world.y);
    draw2d();
    openMeasureSheet();
    return;
  }
}

function dirVec(heading) {
  // heading 0 = N, 90 = E, clockwise; northDeg rotates the compass
  const a = ((heading + state.northDeg) * Math.PI) / 180 - Math.PI / 2;
  return { x: Math.cos(a), y: Math.sin(a) };
}

function openMeasureSheet() {
  const u = unitLabel();
  const rel0 = !!state.measureRel;
  $("#sheet").innerHTML = `
    <h3>${t("tMeasure")}</h3>
    <label>${t("length")} (${u})</label>
    <input id="ms-len" type="number" step="0.1" value="${u === "m" ? 3 : 10}">
    <label>${t("angle")} (°)</label>
    <input id="ms-ang" type="number" step="1" min="0" max="360" value="0" placeholder="0–360">
    <div class="seg" id="ms-mode">
      <button type="button" data-v="abs" class="${rel0?"":"on"}">${t("absolute")}</button>
      <button type="button" data-v="rel" class="${rel0?"on":""}">${t("relative")}</button>
    </div>
    <label>${t("dir")}</label>
    <div class="seg" id="ms-dir" style="flex-wrap:wrap">
      ${["N","NE","E","SE","S","SW","W","NW"].map((d,i)=>`<button type="button" data-h="${i*45}" class="${d==="E"?"on":""}">${d}</button>`).join("")}
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ms-ok">${t("apply")}</button>
      <button class="btn ghost small" id="ms-cancel">Cancel</button>
    </div>`;
  openSheet();
  $$("#ms-dir button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ms-dir button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      const h = parseFloat(b.dataset.h);
      // compass heading 0=N to world angle 0=E CCW: world = 90 - heading - north? 
      // dirVec already used heading; also fill angle field as world degrees of that dir
      const v = dirVec(h);
      $("#ms-ang").value = String(Math.round(worldAngle(0, 0, v.x, v.y)));
    })
  );
  $$("#ms-mode button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ms-mode button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      state.measureRel = b.dataset.v === "rel";
    })
  );
  $("#ms-ok").onclick = () => {
    const len = displayToFt(parseFloat($("#ms-len").value) || 0, state.settings.units);
    const s = state.measureStart;
    const rel = $("#ms-mode .on")?.dataset.v === "rel";
    state.measureRel = rel;
    let ang = $("#ms-ang").value;
    let deg;
    if (ang !== "" && !isNaN(parseFloat(ang))) {
      deg = parseFloat(ang);
      if (rel) {
        const base = lastWallAngleAt(s.x, s.y) ?? 0;
        deg = base + deg;
      }
    } else {
      const h = parseFloat($("#ms-dir .on")?.dataset.h || "90");
      const v = dirVec(h);
      deg = worldAngle(0, 0, v.x, v.y);
    }
    if (s && len > MIN_WALL) {
      const p = pointAtAngle(s.x, s.y, deg, len);
      const w = addWall(s.x, s.y, p.x, p.y, "outer");
      if (w) {
        state.selection = { type: "wall", id: w.id };
        openWallSheet(w);
      }
    }
    state.measureStart = null;
    draw2d();
  };
  $("#ms-cancel").onclick = () => {
    state.measureStart = null;
    closeSheet();
    draw2d();
  };
}

// Soft keyboard: Android Chrome resizes the layout (interactive-widget=resizes-content / adjustResize
// in the APK); iOS Safari only shrinks the visual viewport, so lift the command bar by the hidden part.
// While the command box is focused the tool row is hidden so the plan keeps some room.
function setupKeyboardInsets() {
  const root = document.documentElement;
  const vv = window.visualViewport;
  const upd = () => {
    const kb = vv ? Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop)) : 0;
    root.style.setProperty("--kb", kb + "px");
  };
  if (vv) { vv.addEventListener("resize", upd); vv.addEventListener("scroll", upd); }
  upd();
  const cmd = $("#cmd");
  if (cmd) {
    cmd.addEventListener("focus", () => document.body.classList.add("kb-cmd"));
    cmd.addEventListener("blur", () => document.body.classList.remove("kb-cmd"));
  }
}

// voice/typed commands should not cover the mic + command bar with an edit sheet after every
// command; only commands that need options (staircase) force it open
let cmdQuiet = false, cmdForceSheet = false;
function openSheet() {
  const sh = $("#sheet");
  // during a typed/voice command only element edit sheets (W1, D2, F3 ...) stay closed
  if (cmdQuiet && !cmdForceSheet && /^[A-Z]\d+$/.test((sh.querySelector("h3")?.textContent || "").trim())) return;
  // every sheet gets a visible close button (some sheets had no way out except tapping the plan)
  if (!sh.querySelector(".sheet-close")) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "sheet-close"; b.textContent = "✕";
    b.setAttribute("aria-label", "Close");
    b.addEventListener("click", closeSheet);
    sh.prepend(b);
  }
  sh.scrollTop = 0;
  sh.classList.add("open");
}
function closeSheet() {
  $("#sheet").classList.remove("open");
}

function openWallSheet(w) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${w.id}</h3>
    <div class="row">
      <div><label>${t("length")} (${u})</label><input id="ws-len" type="number" step="0.1" value="${ftToDisplay(wallLen(w), state.settings.units)}"></div>
      <div><label>${t("height")} (${u})</label><input id="ws-h" type="number" step="0.1" value="${ftToDisplay(w.height || state.settings.floorHeight, state.settings.units)}"></div>
    </div>
    <label>${t("angle")} (°)</label>
    <input id="ws-ang" type="number" step="1" value="${Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2))}">
    <label>${t("type")}</label>
    <div class="seg" id="ws-type">
      <button type="button" data-v="outer" class="${w.type==="partition"?"":"on"}">${t("tOuter")}</button>
      <button type="button" data-v="partition" class="${w.type==="partition"?"on":""}">${t("tPart")}</button>
    </div>
    <div class="row">
      <div><label>${t("colorIn")}</label><input id="ws-cin" type="color" value="${w.colorIn || w.color || "#2c3d4f"}"></div>
      <div><label>${t("colorOut")}</label><input id="ws-cout" type="color" value="${w.colorOut || w.color || "#2c3d4f"}"></div>
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ws-ok">${t("apply")}</button>
      <button class="btn danger small" id="ws-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#ws-type button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ws-type button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $("#ws-ok").onclick = () => {
    const wall = state.walls.find((x) => x.id === w.id);
    if (!wall) return;
    pushUndo();
    setWallLength(wall.id, displayToFt(parseFloat($("#ws-len").value) || 0, state.settings.units), false);
    const ang = parseFloat($("#ws-ang")?.value);
    if (!isNaN(ang)) setWallAngle(wall.id, ang, false);
    const w2 = state.walls.find((x) => x.id === w.id);
    if (w2) {
      w2.height = displayToFt(parseFloat($("#ws-h").value) || 0, state.settings.units) || w2.height;
      const typ = $("#ws-type .on")?.dataset.v || w2.type;
      const cin = $("#ws-cin").value, cout = $("#ws-cout").value;
      const pickedIn = cin.toLowerCase() !== String(w.colorIn || w.color || "#2c3d4f").toLowerCase();
      const pickedOut = cout.toLowerCase() !== String(w.colorOut || w.color || "#2c3d4f").toLowerCase();
      w2.colorIn = cin;
      w2.colorOut = cout;
      if (typ !== w2.type) {
        w2.type = typ;
        const p = wallProps(typ);
        w2.thickness = p.thickness;
        w2.color = p.color;
        if (!pickedIn) w2.colorIn = p.color;
        if (!pickedOut) w2.colorOut = p.color;
      }
      refreshRooms();
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
    }
  };
  $("#ws-del").onclick = () => deleteWall(w.id);
}

function placeDoor(wall, t) {
  pushUndo();
  const width = state.settings.units === "m" ? 0.9 / 0.3048 : 3;
  const d = {
    id: nextId("D", state.doors),
    wallId: wall.id,
    t: Math.max(0.1, Math.min(0.9, t)),
    width,
    height: state.settings.lintel
  };
  // keep door fully on wall
  const half = width / 2 / wallLen(wall);
  d.t = Math.max(half + 0.01, Math.min(1 - half - 0.01, d.t));
  state.doors.push(d);
  state.selection = { type: "door", id: d.id };
  persist();
  openDoorSheet(d);
  draw2d();
}

function openDoorSheet(d) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${d.id}</h3>
    <label>${t("width")} (${u})</label>
    <input id="ds-w" type="number" step="0.1" value="${ftToDisplay(d.width, state.settings.units)}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ds-ok">${t("apply")}</button>
      <button class="btn danger small" id="ds-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#ds-ok").onclick = () => {
    const door = state.doors.find((x) => x.id === d.id);
    if (!door) return;
    pushUndo();
    door.width = displayToFt(parseFloat($("#ds-w").value) || 0, state.settings.units) || door.width;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ds-del").onclick = () => {
    pushUndo();
    const di = state.doors.findIndex((x) => x.id === d.id);
    if (di >= 0) state.doors.splice(di, 1); // in place: state.doors is the floor's array
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

function placeStair(pt) {
  const d = stairDefaults();
  const room = roomAt(pt);
  let res = room ? makeStair(d, room, null) : null;
  if (!res || res.err) res = makeStair({ ...d, at: pt }, null, null);
  if (res.err) { toast(res.err); return; }
  openStairWizard({ stair: res.s });
  draw2d();
}

function openStairSheet(s) {
  return openStairWizard({ stair: s });
}
function openStairSheetOld(s) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${s.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="ss-type">
      <button type="button" data-v="straight" class="${s.type==="straight"?"on":""}">${t("straight")}</button>
      <button type="button" data-v="L" class="${s.type==="L"?"on":""}">${t("L")}</button>
      <button type="button" data-v="U" class="${s.type==="U"?"on":""}">${t("U")}</button>
      <button type="button" data-v="spiral" class="${s.type==="spiral"?"on":""}">${t("spiral")}</button>
    </div>
    <div class="row">
      <div><label>${t("riser")} (${u})</label><input id="ss-r" type="number" step="0.01" value="${ftToDisplay(s.riser, state.settings.units)}"></div>
      <div><label>${t("tread")} (${u})</label><input id="ss-t" type="number" step="0.01" value="${ftToDisplay(s.tread, state.settings.units)}"></div>
    </div>
    <div class="row">
      <div><label>${t("steps")}</label><input id="ss-n" type="number" step="1" value="${s.steps}"></div>
      <div><label>${t("width")} (${u})</label><input id="ss-w" type="number" step="0.1" value="${ftToDisplay(s.width, state.settings.units)}"></div>
    </div>
    <label>${t("rot")} (°)</label>
    <input id="ss-rot" type="number" step="45" value="${s.rot || 0}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ss-ok">${t("apply")}</button>
      <button class="btn danger small" id="ss-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#ss-type button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ss-type button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $("#ss-ok").onclick = () => {
    const st = state.stairs.find((x) => x.id === s.id);
    if (!st) return;
    pushUndo();
    st.type = $("#ss-type .on")?.dataset.v || st.type;
    st.riser = displayToFt(parseFloat($("#ss-r").value) || 0, state.settings.units) || st.riser;
    st.tread = displayToFt(parseFloat($("#ss-t").value) || 0, state.settings.units) || st.tread;
    st.steps = parseInt($("#ss-n").value, 10) || st.steps;
    st.width = displayToFt(parseFloat($("#ss-w").value) || 0, state.settings.units) || st.width;
    st.rot = parseFloat($("#ss-rot").value) || 0;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ss-del").onclick = () => {
    pushUndo();
    const si = state.stairs.findIndex((x) => x.id === s.id);
    if (si >= 0) state.stairs.splice(si, 1); // in place: state.stairs is the floor's array
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

function placeWindow(wall, t) {
  pushUndo();
  const width = state.settings.units === "m" ? 1.2 / 0.3048 : 4;
  const k = {
    id: nextId("K", state.windows),
    wallId: wall.id,
    t: Math.max(0.1, Math.min(0.9, t)),
    width,
    height: state.settings.units === "m" ? 1.2 / 0.3048 : 4,
    sill: state.settings.units === "m" ? 0.9 / 0.3048 : 3
  };
  const half = k.width / 2 / wallLen(wall);
  k.t = Math.max(half + 0.01, Math.min(1 - half - 0.01, k.t));
  state.windows.push(k);
  state.selection = { type: "window", id: k.id };
  persist();
  openWindowSheet(k);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openWindowSheet(k) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${k.id}</h3>
    <div class="row">
      <div><label>${t("width")} (${u})</label><input id="ks-w" type="number" step="0.1" value="${ftToDisplay(k.width, state.settings.units)}"></div>
      <div><label>${t("height")} (${u})</label><input id="ks-h" type="number" step="0.1" value="${ftToDisplay(k.height, state.settings.units)}"></div>
    </div>
    <label>${t("sill")} (${u})</label>
    <input id="ks-s" type="number" step="0.1" value="${ftToDisplay(k.sill, state.settings.units)}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ks-ok">${t("apply")}</button>
      <button class="btn danger small" id="ks-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#ks-ok").onclick = () => {
    const win = state.windows.find((x) => x.id === k.id);
    if (!win) return;
    pushUndo();
    win.width = displayToFt(parseFloat($("#ks-w").value) || 0, state.settings.units) || win.width;
    win.height = displayToFt(parseFloat($("#ks-h").value) || 0, state.settings.units) || win.height;
    win.sill = displayToFt(parseFloat($("#ks-s").value) || 0, state.settings.units) || win.sill;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ks-del").onclick = () => {
    pushUndo();
    state.windows = state.windows.filter((x) => x.id !== k.id);
    if (state.floors[state.floorIndex]) state.floors[state.floorIndex].windows = state.windows;
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}
function placeColumn(pt) {
  pushUndo();
  const c = {
    id: nextId("C", state.columns),
    x: pt.x, y: pt.y,
    w: 9 / 12, d: 12 / 12,
    rot: 0,
    height: state.settings.floorHeight
  };
  state.columns.push(c);
  state.selection = { type: "column", id: c.id };
  persist();
  openColumnSheet(c);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openColumnSheet(c) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${c.id}</h3>
    <div class="row">
      <div><label>${t("colSize")} W (${u})</label><input id="cs-w" type="number" step="0.01" value="${ftToDisplay(c.w, state.settings.units)}"></div>
      <div><label>D (${u})</label><input id="cs-d" type="number" step="0.01" value="${ftToDisplay(c.d, state.settings.units)}"></div>
    </div>
    <div class="row">
      <div><label>${t("height")} (${u})</label><input id="cs-h" type="number" step="0.1" value="${ftToDisplay(c.height || state.settings.floorHeight, state.settings.units)}"></div>
      <div><label>${t("rot")} (°)</label><input id="cs-r" type="number" step="15" value="${c.rot || 0}"></div>
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="cs-ok">${t("apply")}</button>
      <button class="btn danger small" id="cs-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#cs-ok").onclick = () => {
    const col = state.columns.find((x) => x.id === c.id);
    if (!col) return;
    pushUndo();
    col.w = displayToFt(parseFloat($("#cs-w").value) || 0, state.settings.units) || col.w;
    col.d = displayToFt(parseFloat($("#cs-d").value) || 0, state.settings.units) || col.d;
    col.height = displayToFt(parseFloat($("#cs-h").value) || 0, state.settings.units) || col.height;
    col.rot = parseFloat($("#cs-r").value) || 0;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#cs-del").onclick = () => {
    pushUndo();
    state.columns = state.columns.filter((x) => x.id !== c.id);
    if (state.floors[state.floorIndex]) state.floors[state.floorIndex].columns = state.columns;
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}
function openRoomSheet(r) {
  const pc = planCentre();
  const vck = vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang);
  $("#sheet").innerHTML = `
    <h3>${r.id}</h3>
    <label>${t("roomName")}</label>
    <input id="rs-n" type="text" value="${escapeHtml(r.name || "")}">
    <p class="hint">${t("area")}: ${fmtArea(r.area)}${vck ? " · " + vck.zone + " (" + vck.dir + ")" : ""}</p>
    ${vck ? `<p class="hint" style="color:${vck.color}">${escapeHtml(vck.text)}</p>` : ""}
    <label>${t("floorCol")}</label>
    <input id="rs-c" type="color" value="${r.floorColor || "#d9d1c3"}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="rs-ok">${t("apply")}</button>
    </div>`;
  openSheet();
  $("#rs-ok").onclick = () => {
    const rm = state.rooms.find((x) => x.id === r.id);
    if (!rm) return;
    pushUndo();
    rm.name = $("#rs-n").value.trim();
    rm.floorColor = $("#rs-c").value;
    persist();
    openRoomSheet(rm);
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

/* ---------- 3D toggle ---------- */
function show2d() {
  $("#c2d").classList.remove("hidden");
  if (view3d) {
    view3d.walk = false;
    view3d.controls.enabled = true;
    view3d.hide();
  }
  state.mode = "2d";
  $("#ed-2d3d").textContent = "3D";
  $("#walk-bar")?.classList.add("hidden");
  $("#sun-bar")?.classList.add("hidden");
  state.sunOn = false;
  draw2d();
}

function refresh3d(reframe = false) {
  if (!view3d) view3d = new View3D($("#c3d"));
  view3d.build({
    reframe,
    floors: state.floors,
    floorIndex: state.floorIndex,
    settings: state.settings,
    vastuOn: state.vastuOn,
    northDeg: state.northDeg,
    lang: state.lang,
    roofOn: state.roofOn,
    sunHour: state.sunHour,
    sunOn: state.sunOn
  });
}

function show3d() {
  persist();
  refresh3d(true);
  $("#c2d").classList.add("hidden");
  view3d.show();
  state.mode = "3d";
  $("#ed-2d3d").textContent = "2D";
}

function switchMode(m) {
  if (m === "3d") show3d();
  else show2d();
}

function handleFloorCommand(s) {
  if (/^(naya|new)\s*(floor|manzil)/.test(s) || /^add\s*(floor|manzil)$/.test(s)) {
    addFloor(false);
    return true;
  }
  if (/(floor|manzil)\s*copy/.test(s) || /^copy\s*(floor|manzil)$/.test(s)) {
    addFloor(true);
    return true;
  }
  if (/^(naya|new|add)?\s*(basement|tala|talaghar)\s*(banao|banaye|add|karo)?$/.test(s)
      || /^(basement|tala)\s*(banao|banaye|add)$/.test(s)) {
    addFloor(false, { basement: true });
    return true;
  }
  const level = parseFloorLevel(s);
  if (level == null) return false;
  if (!/(floor|manzil|basement|tala|ground|storey|story|\bb\d+)/.test(s) && !/^(g|gf)$/.test(s)) return false;
  const make = /(banao|banaye|add|banaao|create|make)/.test(s);
  const go = /\b(jao|chalo|go|switch|open|kholo|dikhao|show|par|pe)\b/.test(s);
  const i = state.floors.findIndex((f) => f.level === level);
  if (i >= 0) {
    switchFloor(i);
    toast(floorName(i));
    return true;
  }
  // "first floor par jao" must not silently create a floor; "teesri manzil banao" / "floor 2" does
  if (make || (!go && /(floor|manzil|basement|tala)/.test(s))) {
    addFloor(false, { level, basement: level < 0 });
    return true;
  }
  toast(defaultFloorName(level) + t("floorMissing").replace("{f}", defaultFloorName(level)), 2600);
  return true;
}

function hitFurniture(x, y) {
  let best = null, bd = Infinity;
  for (const f of state.furniture || []) {
    const kind = FURNITURE[f.kind] || FURNITURE.bed;
    const inside = itemPolys(f, kind).some((P) => polyContains(P, x, y));
    const d = Math.hypot(x - f.x, y - f.y) + (kind.onTop ? -1 : 0);
    if ((inside || d < 0.8) && d < bd) { bd = d; best = f; }
  }
  return best;
}
function hitMep(x, y) {
  return (state.mep || []).find((m) => Math.hypot(x - m.x, y - m.y) < 0.7) || null;
}
function placeFurniture(pt) {
  const kind = state.furnKind || "bed";
  const def = FURNITURE[kind] || FURNITURE.bed;
  let f = null;
  if (roomAt(pt)) { const r = smartPlace(kind, null, pt); f = r.item || null; }
  if (!f) {
    pushUndo();
    f = { id: nextId("F", state.furniture), kind, x: pt.x, y: pt.y, w: def.w, d: def.d, rot: 0 };
    if (def.leg) { f.leg = def.leg; f.legSide = -1; }
    if (def.elev) f.elev = def.elev;
    state.furniture.push(f);
  }
  state.selection = { type: "furniture", id: f.id };
  persist();
  openFurnitureSheet(f);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function placeMep(pt) {
  pushUndo();
  const kind = state.mepKind || "light";
  const def = MEP[kind] || MEP.light;
  const prefix = def.kind === "p" ? "P" : "E";
  const pool = state.mep.filter((x) => x.id[0] === prefix);
  const m = { id: nextId(prefix, pool.length ? pool : [{ id: prefix + "0" }]), kind, x: pt.x, y: pt.y };
  // unique among all mep
  if (state.mep.some((x) => x.id === m.id)) m.id = nextId(prefix, state.mep);
  state.mep.push(m);
  state.selection = { type: "mep", id: m.id };
  persist();
  openMepSheet(m);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openFurnitureSheet(f) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${f.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="fu-kind" style="flex-wrap:wrap">
      ${Object.keys(FURNITURE).map((k) => `<button type="button" data-v="${k}" class="${f.kind===k?"on":""}">${FURNITURE[k].name}</button>`).join("")}
    </div>
    <div class="row">
      <div><label>${t("width")} (${u})</label><input id="fu-w" type="number" step="0.1" value="${ftToDisplay(f.w, state.settings.units)}"></div>
      <div><label>D (${u})</label><input id="fu-d" type="number" step="0.1" value="${ftToDisplay(f.d, state.settings.units)}"></div>
    </div>
    <label>${t("rot")} (°)</label>
    <input id="fu-rot" type="number" step="15" value="${f.rot || 0}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="fu-ok">${t("apply")}</button>
      <button class="btn danger small" id="fu-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#fu-kind button").forEach((b) => b.addEventListener("click", () => {
    $$("#fu-kind button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    state.furnKind = b.dataset.v;
  }));
  $("#fu-ok").onclick = () => {
    const it = state.furniture.find((x) => x.id === f.id);
    if (!it) return;
    pushUndo();
    it.kind = $("#fu-kind .on")?.dataset.v || it.kind;
    state.furnKind = it.kind;
    it.w = displayToFt(parseFloat($("#fu-w").value) || 0, state.settings.units) || it.w;
    it.d = displayToFt(parseFloat($("#fu-d").value) || 0, state.settings.units) || it.d;
    it.rot = parseFloat($("#fu-rot").value) || 0;
    persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
  $("#fu-del").onclick = () => {
    pushUndo();
    const i = state.furniture.findIndex((x) => x.id === f.id);
    if (i >= 0) state.furniture.splice(i, 1);
    state.selection = null; closeSheet(); persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
}
function openMepSheet(m) {
  $("#sheet").innerHTML = `
    <h3>${m.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="me-kind" style="flex-wrap:wrap">
      ${Object.keys(MEP).map((k) => `<button type="button" data-v="${k}" class="${m.kind===k?"on":""}">${MEP[k].name}</button>`).join("")}
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="me-ok">${t("apply")}</button>
      <button class="btn danger small" id="me-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#me-kind button").forEach((b) => b.addEventListener("click", () => {
    $$("#me-kind button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    state.mepKind = b.dataset.v;
  }));
  $("#me-ok").onclick = () => {
    const it = state.mep.find((x) => x.id === m.id);
    if (!it) return;
    pushUndo();
    it.kind = $("#me-kind .on")?.dataset.v || it.kind;
    state.mepKind = it.kind;
    persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
  $("#me-del").onclick = () => {
    pushUndo();
    const i = state.mep.findIndex((x) => x.id === m.id);
    if (i >= 0) state.mep.splice(i, 1);
    state.selection = null; closeSheet(); persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
}

function openNorthSheet() {
  $("#sheet").innerHTML = `
    <h3>${t("setNorth")}</h3>
    <label>${t("angle")} (°)</label>
    <input id="nd-val" type="number" step="1" min="0" max="360" value="${Math.round(state.northDeg || 0)}">
    <div class="dial-wrap"><canvas id="north-dial" width="180" height="180"></canvas></div>
    <div class="row"><button class="btn small" id="nd-ok">${t("apply")}</button></div>`;
  openSheet();
  const c = $("#north-dial");
  const drawDial = () => {
    const ctx = c.getContext("2d");
    const w = c.width, h = c.height, r = 74, cx = w / 2, cy = h / 2;
    const n = normDeg(parseFloat($("#nd-val").value) || 0);
    ctx.clearRect(0, 0, w, h);
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = "#efe8d8"; ctx.fill();
    ctx.strokeStyle = "#5a4a32"; ctx.lineWidth = 3; ctx.stroke();
    for (let d = 0; d < 360; d += 10) {
      const a = -Math.PI / 2 + (d * Math.PI) / 180;
      const inner = d % 30 === 0 ? r - 12 : r - 7;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
      ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      ctx.strokeStyle = "#3a2e1c"; ctx.lineWidth = d % 30 === 0 ? 2 : 1; ctx.stroke();
    }
    // needle at northDeg clockwise from up
    const a = -Math.PI / 2 + (n * Math.PI) / 180;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * (r - 8), cy + Math.sin(a) * (r - 8));
    ctx.lineTo(cx, cy);
    ctx.strokeStyle = "#c0392b"; ctx.lineWidth = 3; ctx.stroke();
    ctx.fillStyle = "#c0392b"; ctx.font = "700 14px system-ui"; ctx.textAlign = "center";
    ctx.fillText("N", cx + Math.cos(a) * (r - 22), cy + Math.sin(a) * (r - 22) + 5);
    ctx.fillStyle = "#1a1408"; ctx.fillText(Math.round(n) + "°", cx, cy + r + 16);
  };
  drawDial();
  const setFromEv = (ev) => {
    const r = c.getBoundingClientRect();
    const x = ev.clientX - r.left - r.width / 2;
    const y = ev.clientY - r.top - r.height / 2;
    let deg = Math.atan2(x, -y) * 180 / Math.PI;
    if (deg < 0) deg += 360;
    $("#nd-val").value = String(Math.round(deg));
    drawDial();
  };
  c.addEventListener("pointerdown", (e) => { c.setPointerCapture?.(e.pointerId); setFromEv(e); });
  c.addEventListener("pointermove", (e) => { if (e.buttons) setFromEv(e); });
  $("#nd-val").addEventListener("input", drawDial);
  $("#nd-ok").onclick = () => {
    pushUndo();
    state.northDeg = normDeg(parseFloat($("#nd-val").value) || 0);
    persist();
    closeSheet();
    draw2d();
    toast("North " + Math.round(state.northDeg) + "°");
  };
}

function showBoq() {
  const q = boqFor(state.floors, state.settings);
  const u = state.settings?.units === "m";
  const L = (ft) => u ? (ft * 0.3048).toFixed(1) + " m" : Math.round(ft) + " ft";
  const A = (ft) => u ? (ft * 0.0929).toFixed(1) + " m²" : Math.round(ft) + " sq.ft";
  const V = (m3) => u ? (+m3).toFixed(1) + " m³" : Math.round(m3 / 0.0283168) + " cu.ft";
  const row = (a, b) => `<tr><td>${a}</td><td>${b}</td></tr>`;
  const head = (a) => `<tr class="boq-h"><td colspan="2">${a}</td></tr>`;
  const fx = Object.entries(q.fixtures).map(([k, n]) => `${(FURNITURE[k] || { name: k }).name} ×${n}`).join(", ");
  const mp = Object.entries(q.mep).map(([k, n]) => `${(MEP[k] || { name: k }).name} ×${n}`).join(", ");
  $("#sheet").innerHTML = `
    <h3>${t("boq")}</h3>
    <div class="boq"><table>
      ${head(t("boqWalls"))}
      ${row(t("floorsN"), q.floors)}
      ${row(t("tOuter"), L(q.outerLen))}
      ${row(t("tPart"), L(q.partLen))}
      ${row(t("boqNetWall"), A(q.wallArea))}
      ${row(t("boqBrickwork"), V(q.wallM3))}
      ${row(t("boqBricks"), q.wallBricks.toLocaleString())}
      ${row(t("boqPlaster"), u ? q.plasterM2 + " m²" : Math.round(q.plasterM2 / 0.0929) + " sq.ft")}
      ${row(t("boqCementWalls"), q.cementWalls + " " + t("bags"))}
      ${head(t("boqFound"))}
      ${row(t("boqExcav"), V(q.excavM3))}
      ${row(t("plinth") + " " + t("boqBeam"), V(q.plinthBeamM3))}
      ${row(t("boqPlinthFill") + " (" + L(q.plinth) + ")", V(q.plinthFillM3))}
      ${row("PCC", V(q.pccM3))}
      ${head(t("boqRcc"))}
      ${row(t("boqSlab") + " (5\")", V(q.slabM3))}
      ${row(t("boqLintel"), V(q.lintelM3))}
      ${row(t("tStair"), V(q.stairM3))}
      ${q.columnM3 ? row(t("tColumn"), V(q.columnM3)) : ""}
      ${head(t("boqTotal"))}
      ${row(t("boqBricks") + " (" + t("boqAll") + ")", q.bricks.toLocaleString())}
      ${row(t("boqCement"), q.cementBags + " " + t("bags"))}
      ${row(t("boqSand"), V(q.sandM3))}
      ${row(t("boqAgg"), V(q.aggM3))}
      ${row(t("boqSteel"), q.steelKg.toLocaleString() + " kg")}
      ${head(t("boqCounts"))}
      ${row(t("tDoor"), q.doors)}
      ${row(t("tWindow"), q.windows)}
      ${row(t("tStair"), q.stairs + (q.risers ? " (" + q.risers + " " + t("risers") + ")" : ""))}
      ${fx ? row(t("tFurn"), fx) : ""}
      ${mp ? row(t("tMep"), mp) : ""}
    </table></div>
    <p class="hint">${t("boqNote")}</p>`;
  openSheet();
}

function exportDxf() {
  const txt = toDxf(state.floors);
  const blob = new Blob([txt], { type: "application/dxf" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = (state.project?.name || "naksha") + ".dxf";
  a.click();
  toast("DXF");
}

function vastuReportPdf() {
  const jsPDF = window.jspdf?.jsPDF;
  if (!jsPDF) { toast(t("pdfLibMissing")); return; }
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const mark = state.settings?.watermark || "Bunty's";
  doc.setFontSize(16);
  doc.text("Vastu report — " + (state.project?.name || ""), 15, 18);
  doc.setFontSize(10);
  doc.text("North " + Math.round(state.northDeg || 0) + "°    " + mark, 15, 25);
  let y = 34;
  const pc = planCentre();
  for (const f of state.floors) {
    doc.setFont(undefined, "bold");
    doc.text((f.name || defaultFloorName(f.level || 0)), 15, y); y += 6;
    doc.setFont(undefined, "normal");
    const rooms = f.rooms || [];
    if (!rooms.length) { doc.text("—", 18, y); y += 6; }
    for (const r of rooms) {
      const vck = vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang);
      const line = `${r.id}  ${r.name || ""}  ${fmtArea(r.area)}  ${vck ? vck.zone + " " + vck.dir + "  " + (vck.text || "") : ""}`;
      const lines = doc.splitTextToSize(line, 180);
      doc.text(lines, 18, y);
      y += lines.length * 5 + 1;
      if (y > 280) { doc.addPage(); y = 18; }
    }
    y += 3;
  }
  doc.setTextColor(180);
  doc.setFontSize(22);
  doc.text(mark, 105, 150, { align: "center", angle: 20 });
  doc.save((state.project?.name || "naksha") + "-vastu.pdf");
  toast("Vastu report");
}

function downloadText(name, text, type = "application/json") {
  const blob = new Blob([text], { type });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60000);
}
function markBackedUp(ids) {
  const all = loadProjects();
  const now = Date.now();
  for (const p of all) if (!ids || ids.includes(p.id)) p.backedUp = now;
  if (state.project && (!ids || ids.includes(state.project.id))) state.project.backedUp = now;
  saveProjects(all);
  if (!ids) try { localStorage.setItem("naksha_lastBackup", String(now)); } catch {}
}
function backupJson() {
  persist();
  const payload = {
    kind: "naksha-project", app: "Naksha Art",
    name: state.project?.name,
    settings: state.settings,
    data: snapshot(),
    saved: Date.now()
  };
  downloadText((state.project?.name || "naksha").replace(/[\\/:*?"<>|]+/g, "_") + ".json", JSON.stringify(payload, null, 2));
  if (state.project) markBackedUp([state.project.id]);
  toast(t("backupDone"), 2600);
}
function backupAll() {
  if (state.project && !$("#screen-editor")?.classList.contains("hidden")) persist();
  const list = loadProjects();
  if (!list.length) { toast(t("noProjects")); return; }
  const payload = { kind: "naksha-all", app: "Naksha Art", saved: Date.now(), projects: list };
  const d = new Date();
  downloadText(`NakshaArt-backup-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}.json`, JSON.stringify(payload));
  markBackedUp(null);
  toast(t("backupDone") + " (" + list.length + ")", 2600);
  if (!$("#screen-home")?.classList.contains("hidden")) renderProjectList();
}
// restore never overwrites: a file becomes new project(s)
function restoreJson(file) {
  const reader = new FileReader();
  reader.onload = () => {
    let obj;
    try { obj = JSON.parse(reader.result); } catch { toast(t("jsonBad")); return; }
    const all = loadProjects();
    const ids = new Set(all.map((p) => p.id));
    const mk = (rec) => {
      let id = rec.id && !ids.has(rec.id) ? rec.id : "p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      ids.add(id);
      const taken = all.some((p) => p.name === rec.name);
      return { ...rec, id, name: (rec.name || "Project") + (taken ? " (" + t("restored") + ")" : ""), updated: Date.now(), backedUp: Date.now() };
    };
    let added = [];
    if (obj && obj.kind === "naksha-all" && Array.isArray(obj.projects)) {
      for (const r of obj.projects) if (r && r.data) added.push(mk(r));
    } else if (obj && (obj.data || obj.floors || obj.walls)) {
      const d = obj.data || obj;
      if (!Array.isArray(d.floors) && !Array.isArray(d.walls)) { toast(t("jsonBad")); return; }
      added.push(mk({ name: obj.name || file.name.replace(/\.json$/i, ""), settings: obj.settings || {}, created: Date.now(), data: d }));
    } else { toast(t("jsonBad")); return; }
    if (!added.length) { toast(t("jsonBad")); return; }
    if (state.project && !$("#screen-editor")?.classList.contains("hidden")) persist();
    const next = loadProjects().concat(added);
    if (!saveProjects(next)) return;
    toast(t("restoredNew") + ": " + added.map((p) => p.name).join(", "), 3200);
    if (added.length === 1) openProject(added[0].id);
    else openHome();
  };
  reader.readAsText(file);
}
function backupReminder() {
  const el = $("#backup-remind");
  if (!el) return;
  const list = loadProjects();
  const last = parseInt(localStorage.getItem("naksha_lastBackup") || "0", 10);
  const stale = list.filter((p) => (p.updated || 0) > Math.max(p.backedUp || 0, last));
  const due = stale.length && Date.now() - Math.max(last, ...list.map((p) => p.backedUp || 0)) > 3 * 864e5;
  el.classList.toggle("hidden", !due);
  if (due) el.querySelector("span").textContent = t("backupRemind").replace("{n}", stale.length);
}

function applyTemplate(key) {
  const tpl = TEMPLATES[key];
  if (!tpl) return;
  const { name, settings, plot: formPlot } = readForm();
  const plot = tpl.plot || formPlot;
  const floor = emptyFloor("Ground", 0);
  const pOuter = { thickness: settings.outerT, color: settings.outerC };
  const pPart = { thickness: settings.partT, color: settings.partC };
  (tpl.walls || []).forEach((w, i) => {
    const p = (w.type === "partition") ? pPart : pOuter;
    floor.walls.push({
      id: "W" + (i + 1), type: w.type || "outer",
      x1: w.x1, y1: w.y1, x2: w.x2, y2: w.y2,
      thickness: p.thickness, color: p.color, colorIn: p.color, colorOut: p.color,
      height: settings.floorHeight
    });
  });
  (tpl.doors || []).forEach((d, i) => {
    const wall = floor.walls[d.wall];
    if (!wall) return;
    floor.doors.push({ id: "D" + (i + 1), wallId: wall.id, t: d.t, width: d.width, height: settings.lintel });
  });
  floor.rooms = detectRooms(floor.walls, []);
  for (const hint of tpl.rooms || []) {
    const hit = floor.rooms.find((r) => pointInPoly(hint.cx, hint.cy, r.poly));
    if (hit) hit.name = hint.name;
  }
  const rec = {
    id: "p" + Date.now().toString(36),
    name: (name || "Mera ghar") + " — " + tpl.name,
    settings, created: Date.now(), updated: Date.now(),
    data: { floors: [floor], floorIndex: 0, northDeg: 0, vastuOn: false, plot }
  };
  const all = loadProjects();
  all.unshift(rec);
  saveProjects(all);
  enterEditor(rec);
}

function setSnap(v) {
  state.angleSnap = Number(v) || 0;
  $$("#snap-bar [data-snap]").forEach((b) => b.classList.toggle("on", Number(b.dataset.snap) === state.angleSnap));
  if (state.project) persist();
}

function toggleSun(on) {
  state.sunOn = on ?? !state.sunOn;
  $("#sun-bar")?.classList.toggle("hidden", !state.sunOn);
  if (state.mode === "3d") refresh3d();
  else if (state.sunOn) switchMode("3d");
}

function toggleWalk(on) {
  const walk = on ?? (view3d && view3d.walk);
  if (state.mode !== "3d") switchMode("3d");
  if (!view3d) return;
  const next = typeof on === "boolean" ? on : !view3d.walk;
  view3d.setWalk(next, {
    floors: state.floors, floorIndex: state.floorIndex, settings: state.settings
  });
  $("#walk-bar")?.classList.toggle("hidden", !next);
  if (!next) refresh3d(true); // back to the orbit view framed on the house
}

/* ---------- commands + voice ---------- */
function parseLenToFt(num, unit) {
  const n = parseFloat(num);
  if (!(n > 0)) return 0;
  let u = (unit || "").toLowerCase();
  if (!u) u = state.settings?.units === "m" ? "m" : "ft"; // a bare number uses the project's units
  if (u === "mm") return n / 304.8;
  if (u === "cm") return n / 30.48;
  if (u.startsWith("m")) return n / 0.3048;
  if (u.startsWith("in")) return n / 12;
  return n; // feet
}

const U_RE = "(feet|foot|ft|fit|feets|meters?|metres?|mtr|m|inch|inches|in|cm|mm)";
const N_RE = "(\\d+(?:\\.\\d+)?)";
const VERB_RE = "(?:\\s*(?:karo|kardo|kar do|karein|kar dijiye|kar|set karo|set|banao|do|please))?";
// "12 feet", "3 meter", "12 ft 6 inch", "10" -> feet (null when no number)
function lenFrom(num, unit, inchNum) {
  let ft = parseLenToFt(num, unit);
  if (inchNum != null && inchNum !== "") ft += parseFloat(inchNum) / 12;
  return ft;
}
const ITEM_KEYS = { d: "doors", k: "windows", c: "columns", s: "stairs", f: "furniture", e: "mep", p: "mep" };
const FURN_WORDS = {
  bed: "bed", palang: "bed", "double bed": "bed", sofa: "sofa", dining: "dining", table: "dining", "dining table": "dining",
  kitchen: "kitchen", platform: "kitchen", "kitchen platform": "kitchen", counter: "kitchen", "kitchen counter": "kitchen", slab: "kitchen", "kitchen slab": "kitchen",
  wc: "wc", toilet: "wc", commode: "wc", "western toilet": "wc", "indian toilet": "wc", "toilet seat": "wc",
  basin: "basin", washbasin: "basin", "wash basin": "basin", "hand basin": "basin",
  wardrobe: "wardrobe", almari: "wardrobe", almirah: "wardrobe", almira: "wardrobe", cupboard: "wardrobe", alamari: "wardrobe",
  chair: "chair", kursi: "chair",
  bathtub: "bathtub", tub: "bathtub", "bath tub": "bathtub", bathub: "bathtub",
  shower: "shower", "shower area": "shower", "shower tray": "shower", "shower cubicle": "shower", "shower cabin": "shower",
  geyser: "geyser", gizer: "geyser", geezer: "geyser", gyser: "geyser", "water heater": "geyser",
  sink: "sink", "kitchen sink": "sink", "bartan sink": "sink",
  hob: "hob", chulha: "hob", chula: "hob", stove: "hob", "gas stove": "hob", gas: "hob", cooktop: "hob", "gas chulha": "hob"
};
const MEP_WORDS = {
  light: "light", bulb: "light", fan: "fan", pankha: "fan", ac: "ac", switch: "switch", socket: "socket", plug: "socket",
  drain: "drain", nali: "drain", "floor trap": "drain", water: "water", pani: "water", tap: "water", nal: "water",
  "shower point": "shower", "shower pipe": "shower", plumbing: "water"
};
function furnKindOf(word) {
  let w = (word || "").replace(/\b(shape|shaped|shap|wala|wali|wale|type|style|modular|ek|a|an)\b/g, " ").replace(/\s+/g, " ").trim();
  if (FURN_WORDS[w]) return FURN_WORDS[w];
  const isL = /^(l|el)\s/.test(w) || /\s(l|el)$/.test(w) || /\sl\s/.test(w);
  const w2 = w.replace(/(^|\s)(l|el)(?=\s|$)/g, " ").replace(/\s+/g, " ").trim();
  if (/sofa/.test(w2)) return isL ? "sofaL" : "sofa";
  if (/^(kitchen\s*)?(platform|counter|slab)$|^kitchen$/.test(w2)) return isL ? "kitchenL" : "kitchen";
  return FURN_WORDS[w2] || null;
}

function cmdDone(msg) {
  const inp = $("#cmd");
  if (inp) inp.value = "";
  if (msg) toast(msg);
}
function refreshAfterEdit() {
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
}
// delete D1 / K2 / C1 / S1 / F1 / E1 / P1 in place (keeps the floor arrays linked)
function deleteItem(prefix, num) {
  const key = ITEM_KEYS[prefix];
  const id = prefix.toUpperCase() + num;
  const list = key && state[key];
  const i = list ? list.findIndex((x) => String(x.id).toUpperCase() === id) : -1;
  if (i < 0) return null;
  pushUndo();
  list.splice(i, 1);
  if (state.selection && state.selection.id === id) state.selection = null;
  closeSheet();
  refreshAfterEdit();
  return id;
}
function roomById(n) {
  return state.rooms.find((x) => x.id.toUpperCase() === "R" + n) || null;
}
function placeAtCentre(roomNum) {
  if (roomNum) {
    const rm = roomById(roomNum);
    if (!rm) return null;
    return { x: rm.cx, y: rm.cy };
  }
  const c = planCentre();
  return { x: c.x, y: c.y };
}

/* ===== smart placement (fixtures, openings, stairs) ===== */
const ROOM_PAT = { wet: /wash|bath|toilet|\bwc\b|shauch|snan|latrine|powder/, kitchen: /kitchen|rasoi|kichen|pantry/, bed: /bed|shayan|master/, living: /living|hall|drawing|baith|lounge/, stair: /stair|seedhi|sidhi|lobby/ };
function roomsWithPoly() { return (state.rooms || []).filter((r) => r.poly && r.poly.length > 2); }
function roomAt(pt) { return roomsWithPoly().find((r) => polyContains(r.poly, pt.x, pt.y)) || null; }
function roomForKind(kind, roomNum, pt) {
  if (roomNum) return roomById(roomNum);
  const rooms = roomsWithPoly();
  if (!rooms.length) return null;
  if (pt) { const r = roomAt(pt); if (r) return r; }
  const def = FURNITURE[kind] || {};
  const pat = ROOM_PAT[def.room];
  if (pat) { const r = rooms.find((x) => pat.test((x.name || "").toLowerCase())); if (r) return r; }
  const sorted = rooms.slice().sort((a, b) => a.area - b.area);
  if (def.room === "wet") return sorted.find((r) => r.area >= 15 && !r.name && !(state.stairs || []).some((st) => polyContains(r.poly, st.x, st.y))) || sorted.find((r) => r.area >= 15) || sorted[0];
  if (def.room === "kitchen") return sorted.find((r) => r.area >= 50) || sorted[sorted.length - 1];
  return sorted[sorted.length - 1];
}
function stairPoly(s) {
  const g = stairGeometry(s);
  if (g.type === "spiral") return rectPoly(s.x, s.y, 0, [-g.rad, -g.rad, g.rad, g.rad]);
  return rectPoly(s.x, s.y, s.rot || 0, [g.ox, g.oy, g.ox + g.bw, g.oy + g.bl]);
}
function placeCtx(room, opts = {}) {
  const wallsById = {};
  for (const w of state.walls) wallsById[w.id] = w;
  const others = [];
  for (const f of state.furniture || []) {
    const d = FURNITURE[f.kind] || {};
    if (d.onTop) continue;
    if (!!opts.high !== ((d.elev || 0) > 3)) continue;
    others.push(...itemPolys(f, d));
  }
  if (!opts.high) {
    for (const s of state.stairs || []) others.push(stairPoly(s));
    for (const c of state.columns || []) { const hw = (c.w || 0.75) / 2, hd = (c.d || 1) / 2; others.push(rectPoly(c.x, c.y, 0, [-hw, -hd, hw, hd])); }
  }
  return { room, walls: state.walls, doors: state.doors, windows: state.windows, wallsById, others };
}
function freeSpot(room, def, pt) {
  const ctx = placeCtx(room);
  const xs = room.poly.map((p) => p.x), ys = room.poly.map((p) => p.y);
  const c = pt || { x: room.cx, y: room.cy };
  let best = null, bd = Infinity;
  for (let x = Math.min(...xs) + 1; x <= Math.max(...xs) - 1; x += 0.5) {
    for (let y = Math.min(...ys) + 1; y <= Math.max(...ys) - 1; y += 0.5) {
      const f = { x, y, rot: 0, w: def.w, d: def.d };
      const P = itemPolys(f, def)[0];
      if (!P.every((q) => polyContains(room.poly, q.x, q.y))) continue;
      if (ctx.others.some((O) => polysOverlap(P, O, -0.05))) continue;
      const dd = Math.hypot(x - c.x, y - c.y);
      if (dd < bd) { bd = dd; best = f; }
    }
  }
  return best;
}
function addFurn(kind, spot) {
  const def = FURNITURE[kind] || FURNITURE.bed;
  const f = { id: nextId("F", state.furniture), kind, x: +spot.x.toFixed(3), y: +spot.y.toFixed(3), w: +(spot.w || def.w).toFixed(2), d: spot.d || def.d, rot: Math.round((spot.rot || 0) * 100) / 100 };
  if (def.leg) { f.leg = spot.leg || def.leg; f.legSide = spot.legSide || -1; }
  if (def.elev) f.elev = def.elev;
  state.furniture.push(f);
  return f;
}
// returns {item} or {err}
function smartPlace(kind, roomNum, pt, wOver) {
  const def0 = FURNITURE[kind] || FURNITURE.bed;
  const def = wOver ? { ...def0, w: wOver, fill: null } : def0;
  const room = roomForKind(kind, roomNum, pt);
  if (!room) return { err: roomNum ? "R" + roomNum + t("notFound") : null };
  pushUndo();
  if (def.onTop) {
    let plat = (state.furniture || []).find((f) => /^kitchen/.test(f.kind) && polyContains(room.poly, f.x, f.y));
    if (!plat) {
      const pd = FURNITURE.kitchen;
      const sp = findWallSpot(placeCtx(room), { w: pd.w, d: pd.d, h: pd.h }, { longest: true, fill: pd.fill });
      if (!sp) return { err: t("noSpace") };
      plat = addFurn("kitchen", sp);
    }
    const used = state.furniture.filter((f) => FURNITURE[f.kind]?.onTop && Math.hypot(f.x - plat.x, f.y - plat.y) < (plat.w || 8));
    const ex = Math.cos((plat.rot || 0) * Math.PI / 180), ey = Math.sin((plat.rot || 0) * Math.PI / 180);
    const slots = [-(plat.w || 8) / 4, (plat.w || 8) / 4, 0];
    let off = kind === "sink" ? slots[0] : slots[1];
    const free = (o) => !used.some((f) => Math.abs((f.x - plat.x) * ex + (f.y - plat.y) * ey - o) < 1.2);
    if (!free(off)) off = slots.find(free);
    if (off === undefined) return { err: t("noSpace") };
    const it = addFurn(kind, { x: plat.x + ex * off, y: plat.y + ey * off, rot: plat.rot || 0 });
    return { item: it, room };
  }
  let sp = null;
  if (!def.free) {
    const ctx = placeCtx(room, { high: (def.elev || 0) > 3 });
    const opts = { corner: def.corner, far: def.far, longest: def.longest, center: def.center, fill: def.fill, near: pt, ignoreDoors: (def.elev || 0) > 3 };
    const legs = def.leg ? [def.leg, def.leg - 1, def.leg - 2, 3.5] : [0];
    for (const leg of legs) {
      sp = findWallSpot(ctx, { w: def.w, d: def.d, h: def.h, leg }, opts);
      if (sp) break;
    }
    if (!sp && def.fill) sp = findWallSpot(ctx, { w: def.fill[0], d: def.d, h: def.h }, { ...opts, fill: null });
  }
  if (!sp) sp = freeSpot(room, def, pt);
  if (!sp) return { err: t("noSpace") };
  if (wOver) sp.w = wOver;
  return { item: addFurn(kind, sp), room };
}

// free position (t) along a wall for an opening of width w, inside [ta,tb]
function freeT(wall, w, ta = 0, tb = 1) {
  const L = wallLen(wall) || 1;
  const ops = [...state.doors, ...state.windows].filter((o) => o.wallId === wall.id);
  const lo = ta + (w / 2 + 0.45) / L, hi = tb - (w / 2 + 0.45) / L;
  if (hi < lo) return ops.length ? null : (ta + tb) / 2;
  const mid = (lo + hi) / 2;
  const cands = [mid];
  for (let k = 1; k < 200; k++) { const d = (k * 0.25) / L; if (mid - d < lo && mid + d > hi) break; cands.push(mid + d, mid - d); }
  // strict pass keeps door swings apart, loose pass only keeps the openings apart
  const isDoor = (o) => state.doors.includes(o);
  for (const strict of [true, false]) {
    for (const c of cands) {
      if (c < lo - 1e-9 || c > hi + 1e-9) continue;
      if (ops.every((o) => Math.abs(c - o.t) * L >= ((o.width || 3) + w) / 2 + (strict && isDoor(o) ? Math.min(o.width || 3, w) + 0.3 : 0.6))) return c;
    }
  }
  return null;
}
// walls lying along a room's edges with their t-range
function roomWallSegs(room) {
  const segs = [];
  const P = room.poly;
  for (let i = 0; i < P.length; i++) {
    const p = P[i], q = P[(i + 1) % P.length];
    for (const w of state.walls) {
      const L = wallLen(w) || 1;
      const ux = (w.x2 - w.x1) / L, uy = (w.y2 - w.y1) / L;
      const dist = (pt) => Math.abs((pt.x - w.x1) * uy - (pt.y - w.y1) * ux);
      if (dist(p) > 0.3 || dist(q) > 0.3) continue;
      const tp = ((p.x - w.x1) * ux + (p.y - w.y1) * uy) / L, tq = ((q.x - w.x1) * ux + (q.y - w.y1) * uy) / L;
      const ta = Math.max(0, Math.min(tp, tq)), tb = Math.min(1, Math.max(tp, tq));
      if ((tb - ta) * L < 1.5) continue;
      // neighbouring room across this edge
      const mx = w.x1 + (w.x2 - w.x1) * (ta + tb) / 2, my = w.y1 + (w.y2 - w.y1) * (ta + tb) / 2;
      const nb = roomsWithPoly().find((r) => r !== room && (polyContains(r.poly, mx + uy * 0.8, my - ux * 0.8) || polyContains(r.poly, mx - uy * 0.8, my + ux * 0.8)));
      segs.push({ wall: w, ta, tb, len: (tb - ta) * L, nb, outer: !nb });
    }
  }
  return segs;
}
function placeOpeningInRoom(room, isWin, toRoom) {
  const w = isWin ? (state.settings.units === "m" ? 1.2 / 0.3048 : 4) : (state.settings.units === "m" ? 0.9 / 0.3048 : 3);
  let segs = roomWallSegs(room);
  if (toRoom) segs = segs.filter((s) => s.nb === toRoom);
  if (!segs.length) return null;
  const score = (s) => isWin ? (s.outer ? 100 : 0) + s.len : (s.outer ? 0 : 50 + (s.nb ? Math.min(s.nb.area, 300) / 10 : 0)) + s.len / 10;
  segs.sort((a, b) => score(b) - score(a));
  for (const s of segs) {
    const tt = freeT(s.wall, w, s.ta, s.tb);
    if (tt == null) continue;
    if (isWin) placeWindow(s.wall, tt); else placeDoor(s.wall, tt);
    const list = isWin ? state.windows : state.doors;
    const it = list[list.length - 1];
    it.t = tt;
    return { it, wall: s.wall };
  }
  return null;
}

// ---- stairs ----
function storyHeight() { return (state.settings.floorHeight || 10) + 0.85; }
function stairDefaults() {
  const m = state.settings.units === "m";
  return { f2f: storyHeight(), riserIn: m ? 165 / 25.4 : 6.5, treadIn: m ? 250 / 25.4 : 10, width: m ? 1 / 0.3048 : 3.5, type: "auto" };
}
function roomInnerBox(room) {
  const xs = room.poly.map((p) => p.x), ys = room.poly.map((p) => p.y);
  const m = 0.45;
  return { x0: Math.min(...xs) + m, y0: Math.min(...ys) + m, x1: Math.max(...xs) - m, y1: Math.max(...ys) - m };
}
function fitStair(o, box, doorsXY) {
  const c = stairCalc(o.f2f, o.riserIn, o.treadIn);
  const types = o.type && o.type !== "auto" ? [o.type] : ["straight", "U", "L", "spiral"];
  const bw0 = box ? box.x1 - box.x0 : 1e9, bh0 = box ? box.y1 - box.y0 : 1e9;
  for (let W = o.width; W >= Math.min(o.width, o.minW || 2.5) - 1e-6; W -= 0.25) {
    for (const type of types) {
      const b = stairBox(type, c.risers, c.tread, W);
      for (const rot of [0, 90]) {
        const ex = rot ? b.bl : b.bw, ey = rot ? b.bw : b.bl;
        if (ex > bw0 + 1e-6 || ey > bh0 + 1e-6) continue;
        let x = 0, y = 0;
        if (box) {
          const corners = [[box.x0 + ex / 2, box.y0 + ey / 2], [box.x1 - ex / 2, box.y0 + ey / 2], [box.x0 + ex / 2, box.y1 - ey / 2], [box.x1 - ex / 2, box.y1 - ey / 2]];
          let bestC = corners[0], bd = -1;
          for (const cc of corners) {
            const dd = (doorsXY || []).reduce((m, d) => Math.min(m, Math.hypot(d.x - cc[0], d.y - cc[1])), 99);
            if (dd > bd) { bd = dd; bestC = cc; }
          }
          [x, y] = bestC;
        }
        return { type, rot, x, y, W, ...c, b };
      }
    }
  }
  return null;
}
function doorsOfRoom(room) {
  const out = [];
  for (const sg of roomWallSegs(room)) for (const d of state.doors.filter((d) => d.wallId === sg.wall.id && d.t >= sg.ta - 0.01 && d.t <= sg.tb + 0.01)) out.push({ x: sg.wall.x1 + (sg.wall.x2 - sg.wall.x1) * d.t, y: sg.wall.y1 + (sg.wall.y2 - sg.wall.y1) * d.t });
  return out;
}
function bestStairRoom(o) {
  const rooms = roomsWithPoly();
  const named = rooms.find((r) => ROOM_PAT.stair.test((r.name || "").toLowerCase()));
  if (named) return named;
  const free = rooms.filter((r) => !r.name).sort((a, b) => a.area - b.area);
  const all = rooms.slice().sort((a, b) => a.area - b.area);
  const fixedW = { ...o, minW: o.width };
  for (const [list, oo] of [[free, fixedW], [all, fixedW], [free, o], [all, o]]) {
    const r = list.find((x) => fitStair(oo, roomInnerBox(x)));
    if (r) return r;
  }
  return null;
}
function makeStair(o, room, existing) {
  const fit = room ? fitStair(o, roomInnerBox(room), doorsOfRoom(room)) : fitStair(o, null);
  if (!fit) return { err: t("stairNoFit") };
  let x = fit.x, y = fit.y;
  if (!room) { const c = o.at || existing || planCentre(); x = c.x; y = c.y; }
  pushUndo();
  const s = existing || { id: nextId("S", state.stairs) };
  Object.assign(s, { v: 2, type: fit.type, x: +x.toFixed(3), y: +y.toFixed(3), rot: room ? fit.rot : (existing?.rot || 0), steps: fit.risers, riser: fit.riser, tread: fit.tread, width: fit.W, f2f: o.f2f });
  delete s.base;
  if (!existing) state.stairs.push(s);
  state.selection = { type: "stair", id: s.id };
  refreshAfterEdit();
  return { s, fit };
}
function stairInfo(o) {
  const c = stairCalc(o.f2f, o.riserIn, o.treadIn);
  const m = state.settings.units === "m";
  const rv = m ? Math.round(c.riser * 304.8) + " mm" : (c.riser * 12).toFixed(2) + '"';
  return `${c.risers} ${t("risers")} × ${rv} = ${fmtLen(c.risers * c.riser)}`;
}
function openStairWizard(opts = {}) {
  const ex = opts.stair || null;
  const d = stairDefaults();
  const m = state.settings.units === "m";
  const o = {
    f2f: ex?.f2f || opts.f2f || d.f2f,
    riserIn: ex ? (ex.riser * 12) : d.riserIn,
    treadIn: ex ? (ex.tread * 12) : d.treadIn,
    width: ex?.width || d.width,
    type: opts.type || (ex ? ex.type : "auto")
  };
  const rooms = roomsWithPoly();
  const pre = opts.room || (ex ? roomAt(ex) : null) || bestStairRoom(o);
  const inU = m ? "mm" : "in";
  const toIn = (v) => m ? Math.round(v * 25.4) : +v.toFixed(2);
  const fromIn = (v) => m ? v / 25.4 : v;
  $("#sheet").innerHTML = `
    <h3>${t("stairWiz")}${ex ? " · " + ex.id : ""}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="sw-type" style="flex-wrap:wrap">
      ${["auto", "straight", "L", "U", "spiral"].map((k) => `<button type="button" data-v="${k}" class="${o.type === k ? "on" : ""}">${k === "auto" ? t("auto") : k === "U" ? t("U") : k === "L" ? t("L") : t(k)}</button>`).join("")}
    </div>
    <div class="row">
      <div><label>${t("f2f")} (${unitLabel()})</label><input id="sw-h" type="number" step="0.01" value="${ftToDisplay(o.f2f, state.settings.units)}"></div>
      <div><label>${t("width")} (${unitLabel()})</label><input id="sw-w" type="number" step="0.1" value="${ftToDisplay(o.width, state.settings.units)}"></div>
    </div>
    <div class="row">
      <div><label>${t("riser")} (${inU})</label><input id="sw-r" type="number" step="0.1" value="${toIn(o.riserIn)}"></div>
      <div><label>${t("tread")} (${inU})</label><input id="sw-t" type="number" step="0.1" value="${toIn(o.treadIn)}"></div>
    </div>
    <label>${t("stairRoom")}</label>
    <select id="sw-room">${rooms.map((r) => `<option value="${r.id}" ${pre === r ? "selected" : ""}>${r.id}${r.name ? " " + escapeHtml(r.name) : ""} (${fmtArea(r.area)})</option>`).join("")}<option value="" ${pre ? "" : "selected"}>${t("planCentre")}</option></select>
    <p class="hint" id="sw-info"></p>
    <div class="row" style="margin-top:8px">
      <button class="btn small" id="sw-ok">${ex ? t("apply") : t("stairMake")}</button>
      ${ex ? `<button class="btn danger small" id="sw-del">${t("delete")}</button>` : ""}
    </div>`;
  cmdForceSheet = true;
  openSheet();
  const read = () => ({
    f2f: displayToFt(parseFloat($("#sw-h").value) || 0, state.settings.units) || o.f2f,
    width: displayToFt(parseFloat($("#sw-w").value) || 0, state.settings.units) || o.width,
    riserIn: fromIn(parseFloat($("#sw-r").value) || 0) || o.riserIn,
    treadIn: fromIn(parseFloat($("#sw-t").value) || 0) || o.treadIn,
    type: $("#sw-type .on")?.dataset.v || "auto"
  });
  const info = () => {
    const r = read();
    const rm = rooms.find((x) => x.id === $("#sw-room").value) || null;
    const fit = rm ? fitStair(r, roomInnerBox(rm)) : fitStair(r, null);
    $("#sw-info").textContent = stairInfo(r) + (fit ? ` · ${fit.type === "U" ? t("U") : fit.type} · ${t("going")} ${fmtLen(fit.rot ? fit.b.bl : fit.b.bl)} × ${fmtLen(fit.b.bw)}` : " · " + t("stairNoFit"));
  };
  $$("#sw-type button").forEach((b) => b.addEventListener("click", () => { $$("#sw-type button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); info(); }));
  ["#sw-h", "#sw-w", "#sw-r", "#sw-t", "#sw-room"].forEach((q) => $(q).addEventListener("input", info));
  $("#sw-room").addEventListener("change", info);
  info();
  $("#sw-ok").onclick = () => {
    const r = read();
    const rm = rooms.find((x) => x.id === $("#sw-room").value) || null;
    const res = makeStair(r, rm, ex);
    if (res.err) { toast(res.err, 2600); return; }
    closeSheet();
    toast(res.s.id + " · " + stairInfo(r) + (rm ? " · " + rm.id : ""), 3200);
  };
  if (ex) $("#sw-del").onclick = () => {
    pushUndo();
    const i = state.stairs.indexOf(ex);
    if (i >= 0) state.stairs.splice(i, 1);
    state.selection = null; closeSheet(); refreshAfterEdit();
  };
}
// entry steps from ground up to plinth, outside the main door
function mainDoor() {
  const outer = state.doors.map((d) => ({ d, w: state.walls.find((w) => w.id === d.wallId) })).filter((x) => x.w && x.w.type !== "partition");
  if (!outer.length) return null;
  const c = planCentre();
  let minY = Infinity;
  for (const w of state.walls) minY = Math.min(minY, w.y1, w.y2);
  outer.sort((a, b) => {
    const ya = a.w.y1 + (a.w.y2 - a.w.y1) * a.d.t, yb = b.w.y1 + (b.w.y2 - b.w.y1) * b.d.t;
    return ya - yb || String(a.d.id).localeCompare(String(b.d.id), undefined, { numeric: true });
  });
  return outer[0];
}
function makeEntrySteps(n) {
  const md = mainDoor();
  if (!md) return { err: t("needMainDoor") };
  const plinth = state.settings.plinth ?? 2;
  if (!(plinth > 0.2)) return { err: t("needPlinth") };
  const R = n && n > 0 ? Math.min(12, n) : Math.max(1, Math.round((plinth * 12) / 6.5));
  const w = md.w, L = wallLen(w) || 1;
  const px = w.x1 + (w.x2 - w.x1) * md.d.t, py = w.y1 + (w.y2 - w.y1) * md.d.t;
  let nx = -(w.y2 - w.y1) / L, ny = (w.x2 - w.x1) / L;
  const c = planCentre();
  if ((px - c.x) * nx + (py - c.y) * ny < 0) { nx = -nx; ny = -ny; } // outward
  const T = 11 / 12, Wd = (md.d.width || 3) + 2;
  const bl = Math.max(1, R - 1) * T;
  const apron = 2;
  const off = apron - 0.05 + bl / 2; // plinth block reaches 2 ft past the wall line
  // ascend toward the wall: local +y -> -n
  const ax = -nx, ay = -ny;
  const rot = Math.atan2(-ax, ay) * 180 / Math.PI;
  pushUndo();
  let s = state.stairs.find((x) => x.base === "ground");
  if (!s) { s = { id: nextId("S", state.stairs) }; state.stairs.push(s); }
  Object.assign(s, { v: 2, base: "ground", type: "straight", x: +(px + nx * off).toFixed(3), y: +(py + ny * off).toFixed(3), rot: Math.round(rot), steps: R, riser: plinth / R, tread: T, width: Wd, f2f: plinth });
  refreshAfterEdit();
  return { s, door: md.d };
}

function wallsBox() {
  if (!state.walls.length) return "";
  let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
  for (const w of state.walls) { a = Math.min(a, w.x1, w.x2); b = Math.min(b, w.y1, w.y2); c = Math.max(c, w.x1, w.x2); d = Math.max(d, w.y1, w.y2); }
  return [a, b, c, d].map((v) => v.toFixed(2)).join(",");
}
function runCommand(text) {
  const raw = (text || "").trim();
  if (!raw) return;
  const s = normCmd(raw);
  const sc = normCmd(raw, true); // same, case kept (room names)
  if (!s) { toast(t("unknown") + ": " + raw, 2200); return false; }
  const box0 = wallsBox(), fl0 = state.floorIndex, n0 = toast._n || 0;
  cmdQuiet = true; cmdForceSheet = false;
  closeSheet();
  let handled = false;
  try {
    const pre = preParse(s, sc, raw);
    if (pre !== null) handled = pre;
    else {
      const action = matchVoiceAction(raw) || matchVoiceAction(s);
      if (action && runAction(action, commandApi())) handled = true;
      else handled = runParsedCommand(s, sc, raw);
    }
  } finally {
    cmdQuiet = false; cmdForceSheet = false;
  }
  if (handled) {
    cmdDone();
    // auto-fit when a voice edit changed the plan outline (new walls, floor switch, ...)
    if (state.mode === "2d" && (wallsBox() !== box0 || state.floorIndex !== fl0)) { fitView(); draw2d(); }
  } else if ((toast._n || 0) === n0) {
    // every no-op gets feedback
    toast(t("unknown") + ": " + raw, 2200);
  }
  return handled;
}

// commands that must win over the generic tool phrases (seedhi / partition ...)
function preParse(s, sc, raw) {
  let m;
  if (/^(fit|fit karo|fit kar do|fit kardo|zoom fit|fit view|fit to screen|zoom to fit|zoom out full|plan fit karo|poora plan dikhao|pura plan dikhao|poora naksha dikhao|pura naksha dikhao|sab dikhao|poora dikhao|pura dikhao|full plan|show full plan|show whole plan)$/.test(s)) {
    if (state.mode !== "2d") switchMode("2d");
    fitView(); draw2d(); toast(t("fitDone")); return true;
  }
  // plinth 3 feet karo / plinth level 2.5 ft / 3 feet ki plinth
  m = s.match(new RegExp("^(?:plinth|plinth level|plinth height|kursi)\\s*(?:ko|ki height|ki unchai|height|level|=)?\\s*" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:ki|ka|ke|unchi|uncha|high)?" + "(?:\\s*(?:karo|kardo|kar do|rakho|set|banao|do|please))?$"))
    || s.match(new RegExp("^" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:ki|ka|ke)?\\s*(?:unchi\\s*)?(?:plinth|kursi)\\s*(?:level)?(?:\\s*(?:banao|rakho|karo|set|do))?$"));
  if (m) {
    const ft = lenFrom(m[1], m[2], m[3]);
    if (!(ft >= 0 && ft <= 8)) { toast(t("unknown") + ": " + raw); return false; }
    pushUndo();
    state.settings.plinth = ft;
    refreshAfterEdit();
    toast(t("plinth") + " = " + fmtLen(ft), 2400);
    return true;
  }
  // entry steps
  m = s.match(/^(?:(\d+)\s*)?(?:entry|entrance|bahar|plinth|main door|main gate|gate|darwaze|front)\s*(?:ki|ke|par|pe|mein|ke bahar|ke aage|ke saamne)?\s*(?:(\d+)\s*)?(?:seedhi|sidhi|seedhiyan|sidhiyan|seedhiya|steps?|pairi|paidi|paydi|sidi)(?:\s*(?:lagao|banao|add|do|karo|daalo|dalo|chahiye))?(?:\s*(?:karo|do))?$/)
    || s.match(/^(?:(\d+)\s*)?(?:steps?|pairi|paidi|paydi)(?:\s*(?:lagao|banao|add|do|karo|daalo|dalo|chahiye))?()$/)
    || s.match(/^(?:add|make)\s*(?:(\d+)\s*)?(?:entry|entrance)\s*(?:(\d+)\s*)?steps?$/);
  if (m) {
    const n = parseInt(m[1] || m[2] || "0", 10);
    const r = makeEntrySteps(n);
    if (r.err) { toast(r.err, 2800); return false; }
    toast(r.s.id + " " + t("entrySteps") + ": " + r.s.steps + " × " + (r.s.riser * 12).toFixed(1) + '" · ' + r.door.id, 3000);
    return true;
  }
  // "floor height 12 feet ki seedhi banao" / "12.85 feet ki seedhi" -> stair options prefilled
  m = s.match(new RegExp("^(floor height|floor ki height|manzil ki unchai|floor to floor|f2f)?\\s*" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:ki|ka|ke liye|wali|height ki|height ke liye|unchai ki)?\\s*(?:seedhi|sidhi|staircase|stairs?)(?:\\s*(?:banao|lagao|add|chahiye|options?))?(?:\\s*(?:karo|do))?$"));
  if (m) {
    const ft = lenFrom(m[2], m[3], m[4]);
    if (!(ft > 1 && ft < 40)) return false;
    const f2f = m[1] && /height|unchai/.test(m[1]) ? ft + 0.85 : ft;
    openStairWizard({ f2f });
    toast(t("stairWiz") + " · " + t("f2f") + " " + fmtLen(f2f), 2600);
    return true;
  }
  // bare stair -> options sheet ; "R3 mein seedhi lagao" -> options for that room
  m = s.match(/^(?:r(\d+)\s*(?:mein|me|main|men|in)\s*)?(?:ek\s+)?(?:seedhi|sidhi|sidi|seedhiyan|staircase|stairs?|zeena|jeena)(?:\s*(?:lagao|lagani hai|banao|add|chahiye|daalo|dalo|rakho|options?|dikhao|wizard))?(?:\s*(?:karo|do|hai))?$/)
    || s.match(/^(?:add|make)\s*(?:a\s+)?(?:stair|stairs|staircase)(?:\s*in\s*r(\d+))?$/);
  if (m) {
    const room = m[1] ? roomById(m[1]) : null;
    if (m[1] && !room) { toast("R" + m[1] + t("notFound")); return false; }
    openStairWizard({ room });
    toast(t("stairWiz"));
    return true;
  }
  // partition: 10 feet 90 degree par partition (4 inch)
  m = s.match(new RegExp("^" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:ki|ka)?\\s*(\\d+(?:\\.\\d+)?)\\s*(?:degree|degrees|deg|°)\\s*(?:par|pe|at|mein)?\\s*(?:(\\d+(?:\\.\\d+)?)\\s*(?:inch|in|mm)\\s*(?:ki|ka)?\\s*)?(?:partition|andar ki deewar|andar deewar|andar wall)(?:\\s*(?:wall|deewar))?\\s*(?:banao|lagao|karo|draw)?$"));
  if (m) {
    const len = lenFrom(m[1], m[2], m[3]);
    const deg = parseFloat(m[4]);
    if (!(len > 0)) return false;
    pushUndo0Part(m[5]);
    const last = state.walls.slice(-1)[0];
    const start = state.measureStart || (last ? { x: last.x2, y: last.y2 } : { x: 10, y: 10 });
    const p = pointAtAngle(start.x, start.y, deg, len);
    const w = addWall(start.x, start.y, p.x, p.y, "partition");
    if (w) { state.selection = { type: "wall", id: w.id }; draw2d(); toast(w.id + " " + t("tPart") + " " + Math.round((w.thickness || 0) * 12 * 10) / 10 + '"'); return true; }
    return false;
  }
  // "partition banao" / "4 inch ki partition deewar banao" -> partition tool with thickness
  m = s.match(/^(?:(\d+(?:\.\d+)?)\s*(inch|in|mm)\s*(?:ki|ka|wali)?\s*)?(?:partition|andar ki deewar|andar deewar)(?:\s*(?:wall|deewar))?(?:\s*(?:banao|lagao|draw|chalu|tool))?(?:\s*(?:karo|do))?$/);
  if (m) {
    pushUndo0Part(m[1], m[2]);
    setTool("partition");
    toast(t("tPart") + " " + Math.round(state.settings.partT * 12 * 10) / 10 + '" · ' + t("partHint"), 3000);
    return true;
  }
  m = s.match(new RegExp("^(?:r(\\d+)\\s*(?:mein|me|main|men|in)\\s*)?(?:([a-z ]+?)\\s+" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?|" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:ka|ki|ke|lamba|lambi|wala|wali)?\\s+([a-z ]+?))\\s*(?:ka|ki|ke|lamba|lambi|wala|wali|long)?\\s*(?:lagao|banao|rakho|add|daalo|dalo)(?:\\s*(?:karo|do))?$"));
  if (m) {
    const word = (m[2] || m[9] || "").trim();
    const fk = furnKindOf(word);
    const ft = m[2] ? lenFrom(m[3], m[4], m[5]) : lenFrom(m[6], m[7], m[8]);
    if (fk && ft > 0.5 && ft < 30) {
      if (m[1] && !roomById(m[1])) { toast("R" + m[1] + t("notFound")); return false; }
      const r = smartPlace(fk, m[1], null, ft);
      if (!r.item) { toast(r.err || t("noSpace"), 2600); return false; }
      refreshAfterEdit();
      toast(r.item.id + " " + FURNITURE[fk].name + " " + fmtLen(r.item.w) + "×" + fmtLen(r.item.d) + (r.room ? " · " + r.room.id : ""), 2600);
      return true;
    }
  }
  // R4 mein khidki lagao / R2 mein darwaza / R2 aur R3 ke beech darwaza
  m = s.match(/^r(\d+)\s*(?:aur|and|se)\s*r(\d+)\s*(?:ke\s*)?(?:beech|between|ke bich|bich)?\s*(?:mein|me)?\s*(darwaza|door|gate)\s*(?:lagao|banao|add|rakho|daalo|dalo|karo)?$/)
    || (() => { const e = s.match(/^r(\d+)\s*(?:mein|me|main|men|in|par|pe|ke liye)\s*(?:ek\s+)?(khidki|window|darwaza|door|gate)\s*(?:lagao|lagaye|banao|add|rakho|daalo|dalo|karo|chahiye)?$/); return e ? [e[0], e[1], null, e[2]] : null; })();
  if (m) {
    const room = roomById(m[1]);
    if (!room) { toast("R" + m[1] + t("notFound")); return false; }
    const other = m[2] ? roomById(m[2]) : null;
    if (m[2] && !other) { toast("R" + m[2] + t("notFound")); return false; }
    const isWin = /khidki|window/.test(m[3]);
    const r = placeOpeningInRoom(room, isWin, other);
    if (!r) { toast(room.id + ": " + t("noSpace"), 2600); return false; }
    refreshAfterEdit();
    toast(r.it.id + " · " + room.id + (other ? "–" + other.id : "") + " · " + r.wall.id, 2600);
    return true;
  }
  return null;
}
function pushUndo0Part(num, unit) {
  if (!num) return;
  const v = parseFloat(num);
  if (!(v > 0)) return;
  state.settings.partT = unit === "mm" ? v / 304.8 : v / 12;
  persist();
}

function runParsedCommand(s, sc, raw) {
  let m;
  if (/^(3d|3 d|three d|teen d)\s*(dikhao|show|kholo)?$/.test(s) || /^show\s*3d$/.test(s)) { switchMode("3d"); toast("3D"); return true; }
  if (/^(2d|2 d|two d|plan)\s*(dikhao|show|kholo)?$/.test(s) || /^show\s*2d$/.test(s)) { switchMode("2d"); toast("2D"); return true; }
  if (/^undo$/.test(s) || /^peeche\s*(karo)?$/.test(s) || /^wapas\s*(lo|karo)?$/.test(s)) { undo(); toast("Undo"); return true; }
  if (/^redo$/.test(s) || /^aage\s*(karo)?$/.test(s)) { redo(); toast("Redo"); return true; }
  if (/^(vastu\s*(report|pdf))/.test(s)) { vastuReportPdf(); return true; }
  if (/^vastu\s*(ko\s*)?(dikhao|show|on|chalu|lagao)/.test(s) || /^(show|turn on)\s*vastu$/.test(s)) { setVastu(true); return true; }
  if (/^vastu\s*(ko\s*)?(hatao|hataao|hide|off|band)/.test(s) || /^(hide|turn off)\s*vastu$/.test(s)) { setVastu(false); return true; }

  // W1 ko 12 feet karo / W3 ko 4 meter / set w1 to 20 feet / make w3 4 meters / W1 ki lambai 10 feet
  m = s.match(new RegExp("^w(\\d+)\\s*(?:ko|to|=|ki lambai|ka length|length|lambai)?\\s*" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:lamba|lambi|long)?" + VERB_RE + "$"))
    || s.match(new RegExp("^(?:set|make)\\s*w(\\d+)\\s*(?:to|=|ko|length)?\\s*" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:long)?$"));
  if (m) {
    const id = "W" + m[1];
    const ft = lenFrom(m[2], m[3], m[4]);
    if (!(ft > 0)) { toast(t("unknown") + ": " + raw); return false; }
    if (setWallLength(id, ft)) {
      toast(id + " = " + fmtLen(ft));
      const w = state.walls.find((x) => x.id === id);
      if (w) { state.selection = { type: "wall", id }; openWallSheet(w); draw2d(); }
      return true;
    }
    toast(id + t("notFound"));
    return false;
  }

  // delete: W2 hatao / delete d1 / K1 delete karo / remove wall 3
  m = s.match(/^(?:delete|remove|hatao|mitao|nikalo)\s*([wdkcsfep])(\d+)$/)
    || s.match(/^([wdkcsfep])(\d+)\s*(?:ko\s*)?(?:delete|hatao|hataao|hata do|mitao|remove|nikalo|hata)(?:\s*(?:karo|kardo|kar do|do|dijiye))?$/);
  if (m) {
    const p = m[1], n = m[2];
    if (p === "w") {
      const id = "W" + n;
      if (deleteWall(id)) { toast(id + " delete"); return true; }
      toast(id + t("notFound")); return false;
    }
    const id = deleteItem(p, n);
    if (id) { toast(id + " delete"); return true; }
    toast(p.toUpperCase() + n + t("notFound"));
    return false;
  }

  // R1 ka naam Bedroom / R2 ko Kitchen naam do / name r1 kitchen
  m = sc.match(/^r(\d+)\s*(?:ka\s*|ki\s*)?(?:naam|name)\s*(?:hai\s*|is\s*|to\s*)?(.+?)\s*(?:rakho|karo|do|hai)?$/i)
    || sc.match(/^r(\d+)\s*ko\s*(.+?)\s*(?:naam\s*(?:do|de do|karo|rakho)?|banao)$/i)
    || sc.match(/^(?:name|rename)\s*r(\d+)\s*(?:as|to)?\s*(.+)$/i);
  if (m) {
    const id = "R" + m[1];
    const rm = roomById(m[1]);
    const name = (m[2] || "").replace(/\s*(naam|name)$/i, "").trim();
    if (rm && name) {
      pushUndo();
      rm.name = name.replace(/^./, (c) => c.toUpperCase());
      persist();
      state.selection = { type: "room", id: rm.id };
      openRoomSheet(rm);
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(rm.id + " = " + rm.name);
      return true;
    }
    toast(id + t("notFound"));
    return false;
  }

  // R1 ke floor ka rang white
  m = s.match(/^r(\d+)\s*(?:ke|ka|ki)?\s*(?:floor|fars|farsh)?\s*(?:ka|ki|ko)?\s*(?:rang|color|colour)\s*(.+)$/)
    || s.match(/^r(\d+)\s*(?:ke\s*(?:floor|farsh)\s*)?(?:ko|ka|ki)?\s*([a-z#0-9]+)\s*(?:rang|color|colour)(?:\s*(?:karo|kardo|kar do|do|set))?$/);
  if (m) {
    const id = "R" + m[1];
    const rm = roomById(m[1]);
    const hex = parseColorName((m[2] || "").replace(/\b(karo|kardo|kar do|kar|do|set|rang|color)\b/g, "").trim());
    if (rm && hex) {
      pushUndo();
      rm.floorColor = hex;
      refreshAfterEdit();
      toast(id + " floor rang set");
      return true;
    }
    toast(!rm ? id + t("notFound") : t("colorUnknown"));
    return false;
  }

  // door / window width: K1 ko 4 feet chauda karo / D1 ko 3.5 feet karo
  m = s.match(new RegExp("^([dk])(\\d+)\\s*(?:ko|to|ki chaudai|width)?\\s*" + N_RE + "\\s*" + U_RE + "?(?:\\s*" + N_RE + "\\s*(?:inch|inches|in))?\\s*(?:chauda|chaura|chaudi|wide|width)?" + VERB_RE + "$"));
  if (m) {
    const key = m[1] === "d" ? "doors" : "windows";
    const id = m[1].toUpperCase() + m[2];
    const it = state[key].find((x) => x.id.toUpperCase() === id);
    const ft = lenFrom(m[3], m[4], m[5]);
    if (it && ft > 0) {
      pushUndo();
      it.width = ft;
      refreshAfterEdit();
      toast(id + " = " + fmtLen(ft));
      return true;
    }
    toast(id + t("notFound"));
    return false;
  }

  // W4 mein 4 by 4 khidki / W2 par darwaza lagao / add door on w2
  m = s.match(new RegExp("^w(\\d+)\\s*(?:mein|me|main|par|pe|on|in)\\s*(?:" + N_RE + "\\s*(?:by|x|×)\\s*" + N_RE + "\\s*" + U_RE + "?\\s*(?:ki|ka)?\\s*)?(khidki|window|darwaza|door|gate)\\s*(?:lagao|lagaye|banao|add|rakho|daalo|dalo|karo)?$"))
    || (() => {
      const e = s.match(/^(?:add|place|put)\s*(?:a\s*)?(door|window)\s*(?:on|to|in)\s*w(\d+)$/);
      return e ? [e[0], e[2], undefined, undefined, undefined, e[1]] : null;
    })();
  if (m) {
    const wall = state.walls.find((x) => x.id.toUpperCase() === "W" + m[1]);
    if (!wall) { toast("W" + m[1] + t("notFound")); return false; }
    const isWin = /khidki|window/.test(m[5]);
    const wantW = m[2] ? parseLenToFt(m[2], m[4]) : (isWin ? 4 : 3);
    const tt = freeT(wall, wantW);
    if (tt == null) { toast(wall.id + ": " + t("noSpace"), 2600); return false; }
    if (isWin) placeWindow(wall, tt); else placeDoor(wall, tt);
    const list = isWin ? state.windows : state.doors;
    const it = list[list.length - 1];
    if (m[2] && m[3]) {
      it.width = parseLenToFt(m[2], m[4]);
      it.height = parseLenToFt(m[3], m[4]);
      const half = it.width / 2 / (wallLen(wall) || 1);
      it.t = Math.max(Math.min(half + 0.01, 0.5), Math.min(Math.max(1 - half - 0.01, 0.5), it.t));
    }
    refreshAfterEdit();
    if (isWin) openWindowSheet(it); else openDoorSheet(it);
    toast(it.id + " " + wall.id + " par");
    return true;
  }

  // wall angle: W3 ko 30 degree ghumao / W3 ka angle 120 degree
  m = s.match(/^w(\d+)\s*(?:ko|ka|ki)?\s*(\d+(?:\.\d+)?)\s*(?:degree|degrees|deg|°)\s*(ghumao|rotate|ghuma do|ghumaye)?(?:\s*karo)?$/)
    || s.match(/^w(\d+)\s*(?:ko|ka|ki)?\s*(?:angle|kon|degree|disha)\s*(\d+(?:\.\d+)?)\s*(?:degree|degrees|deg|°)?(?:\s*(?:karo|kardo|set))?$/)
    || s.match(/^(?:rotate)\s*w(\d+)\s*(?:by)?\s*(\d+(?:\.\d+)?)\s*(?:degree|degrees|deg|°)?$/);
  if (m) {
    const id = "W" + m[1];
    const wall = state.walls.find((x) => x.id.toUpperCase() === id);
    const n = parseFloat(m[2]);
    if (wall && !isNaN(n)) {
      if (/ghuma|rotate/.test(s)) setWallAngle(id, worldAngle(wall.x1, wall.y1, wall.x2, wall.y2) + n);
      else setWallAngle(id, n);
      state.selection = { type: "wall", id };
      openWallSheet(state.walls.find((x) => x.id === id) || wall);
      toast(id + " = " + Math.round(worldAngle(wall.x1, wall.y1, wall.x2, wall.y2)) + "°");
      return true;
    }
    toast(id + t("notFound"));
    return false;
  }

  // wall colour: W1 ka rang grey / W1 andar se cream karo / wall 2 ka color laal karo / W1 bahar se grey
  m = s.match(/^w(\d+)\s*(?:(andar|inside|bahar|outside)\s*(?:se|ka|ki|side|wala)?\s*)?(?:ka|ki|ko|se)?\s*(?:(rang|color|colour)\s*)?(?:ko\s*)?([a-z#0-9]+)\s*(?:rang|color|colour)?(?:\s*(?:karo|kardo|kar do|karein|kar|set|do|paint))?$/)
    || s.match(/^(?:paint|colour|color)\s*w(\d+)\s*()()([a-z#0-9]+)$/);
  if (m && (parseColorName(m[4]) || m[3])) {
    const id = "W" + m[1];
    const w = state.walls.find((x) => x.id.toUpperCase() === id);
    const side = (m[2] || "").toLowerCase();
    const hex = parseColorName(m[4]);
    if (w && hex) {
      pushUndo();
      if (side === "andar" || side === "inside") w.colorIn = hex;
      else if (side === "bahar" || side === "outside") w.colorOut = hex;
      else { w.colorIn = hex; w.colorOut = hex; w.color = hex; }
      refreshAfterEdit();
      toast(id + " rang set");
      return true;
    }
    toast(hex ? id + t("notFound") : t("colorUnknown"));
    return false;
  }

  // 10 feet 45 degree par wall
  m = s.match(new RegExp("^" + N_RE + "\\s*" + U_RE + "?\\s*(?:ki|ka)?\\s*(\\d+(?:\\.\\d+)?)\\s*(?:degree|degrees|deg|°)\\s*(?:par|pe|at|mein)?\\s*(?:wall|deewar|w)?\\s*(?:banao|lagao|karo|draw)?$"));
  if (m) {
    const len = parseLenToFt(m[1], m[2]);
    const deg = parseFloat(m[3]);
    const last = state.walls.slice(-1)[0];
    const start = state.measureStart || (last ? { x: last.x2, y: last.y2 } : { x: 10, y: 10 });
    const p = pointAtAngle(start.x, start.y, deg, len);
    const w = addWall(start.x, start.y, p.x, p.y, "outer");
    if (w) { state.selection = { type: "wall", id: w.id }; openWallSheet(w); draw2d(); toast(w.id); return true; }
    toast(t("unknown") + ": " + raw);
    return false;
  }
  m = s.match(/^(?:set\s*)?(?:north|uttar)\s*(?:ko|to|=|disha)?\s*(\d+(?:\.\d+)?)\s*(?:degree|degrees|deg|°)?(?:\s*(?:par|pe))?(?:\s*(?:karo|kardo|set|rakho))?$/);
  if (m) {
    const n = parseFloat(m[1]);
    pushUndo();
    state.northDeg = normDeg(n);
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
    toast("North " + Math.round(state.northDeg) + "°");
    return true;
  }

  // furniture / MEP by voice: bed lagao / R1 mein bed lagao / toilet lagao / R2 mein drain lagao / add sofa in r1
  m = s.match(/^(?:r(\d+)\s*(?:mein|me|main|men|in)\s*)?(?:(?:ek|a|an|1)\s+)?([a-z ]+?)\s*(?:lagao|lagaye|lagaen|lagana|rakho|rakhe|daalo|dalo|add|banao|place|chahiye)(?:\s*(?:karo|do))?$/)
    || (() => {
      const e = s.match(/^(?:add|place|put)\s*(?:(?:a|an)\s+)?([a-z ]+?)(?:\s*(?:in|to|inside)\s*r(\d+))?$/);
      return e ? [e[0], e[2], e[1]] : null;
    })();
  if (m) {
    const word = (m[2] || "").trim();
    const fk = furnKindOf(word);
    const mk = !fk ? MEP_WORDS[word] : null;
    const col = /^(column|khamba|pillar)$/.test(word);
    if (fk || mk || col) {
      if (m[1] && !roomById(m[1])) { toast("R" + m[1] + t("notFound")); return false; }
      if (fk) {
        const r = roomsWithPoly().length ? smartPlace(fk, m[1]) : { err: null };
        let it = r.item;
        if (!it) {
          if (r.err) { toast(r.err, 2600); return false; }
          const pt = placeAtCentre(m[1]);
          state.furnKind = fk; placeFurniture(pt);
          it = state.furniture[state.furniture.length - 1];
        }
        state.furnKind = fk;
        state.selection = { type: "furniture", id: it.id };
        refreshAfterEdit();
        const rr = r.room || (m[1] ? roomById(m[1]) : null);
        toast(it.id + " " + FURNITURE[fk].name + " " + fmtLen(it.w) + "×" + fmtLen(it.d) + (rr ? " · " + rr.id + (rr.name ? " " + rr.name : "") : ""), 2600);
        return true;
      }
      const pt = placeAtCentre(m[1]);
      if (col) { placeColumn(snapPt(pt.x, pt.y, false)); toast(state.columns[state.columns.length - 1].id); return true; }
      state.mepKind = mk; placeMep(pt);
      const it = state.mep[state.mep.length - 1];
      toast(it.id + " " + MEP[mk].name + (m[1] ? " R" + m[1] + " mein" : ""));
      return true;
    }
  }
  // spiral / L / U seedhi lagao, S1 ko spiral karo
  m = s.match(/^(?:r(\d+)\s*(?:mein|me|main|men|in)\s*)?(spiral|gol|l|u|dog legged|dogleg|straight|seedhi wali|seedha)\s*(?:shape\s*)?(?:ki\s*|wali\s*)?(?:seedhi|sidhi|stair|staircase|stairs|zeena)\s*(?:lagao|banao|add|rakho|daalo|dalo)?(?:\s*(?:karo|do))?$/);
  if (m) {
    const typ = { spiral: "spiral", gol: "spiral", l: "L", u: "U", "dog legged": "U", dogleg: "U" }[m[2]] || "straight";
    const o = { ...stairDefaults(), type: typ };
    const room = m[1] ? roomById(m[1]) : bestStairRoom(o);
    if (m[1] && !room) { toast("R" + m[1] + t("notFound")); return false; }
    let res = room ? makeStair(o, room, null) : makeStair(o, null, null);
    if (res.err) { toast(res.err, 2600); return false; }
    toast(res.s.id + " " + typ + " · " + stairInfo(o) + (room ? " · " + room.id : ""), 3200);
    return true;
  }
  m = s.match(/^s(\d+)\s*(?:ko)?\s*(spiral|gol|l|u|straight|seedha)\s*(?:shape|wali|type)?\s*(?:karo|banao|kardo)?$/);
  if (m) {
    const st = state.stairs.find((x) => x.id.toUpperCase() === "S" + m[1]);
    if (!st) { toast("S" + m[1] + t("notFound")); return false; }
    pushUndo();
    st.type = { spiral: "spiral", gol: "spiral", l: "L", u: "U" }[m[2]] || "straight";
    refreshAfterEdit();
    toast(st.id + " " + st.type);
    return true;
  }

  // floors — unlimited + basements
  if (handleFloorCommand(s)) return true;
  toast(t("unknown") + ": " + raw, 2600);
  return false;
}

let recog = null;
let recogTimer = 0;
function setupVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const micOff = () => {
    clearTimeout(recogTimer);
    recogTimer = 0;
    $("#mic").classList.remove("on");
  };
  $("#mic").addEventListener("click", () => {
    const SRnow = window.SpeechRecognition || window.webkitSpeechRecognition || SR;
    if (!SRnow) {
      toast(t("noSpeech"), 2500);
      $("#cmd").focus();
      return;
    }
    if (recog) {
      // second tap = stop listening (no error toast for a user abort)
      const r = recog;
      recog = null;
      r._stopped = true;
      try { r.abort ? r.abort() : r.stop(); } catch {}
      micOff();
      return;
    }
    let r;
    try { r = new SRnow(); } catch { toast(t("noSpeech")); return; }
    recog = r;
    r.lang = speechLang();            // follows the chosen language (hi-IN, en-US, ...)
    r.interimResults = false;
    r.continuous = false;             // one command per tap: no auto-restart loop
    r.maxAlternatives = 3;
    $("#mic").classList.add("on");
    toast(t("listening"), 2500);
    let gotResult = false;
    r.onresult = (e) => {
      if (r !== recog || gotResult) return;
      const res = e.results && e.results[e.resultIndex || 0] || (e.results && e.results[0]);
      const text = res && res[0] && res[0].transcript ? String(res[0].transcript) : "";
      if (!text.trim()) return;
      gotResult = true;
      $("#cmd").value = text;
      runCommand(text);
    };
    r.onend = () => {
      if (r !== recog) return;     // a newer session owns the mic
      recog = null;
      micOff();
    };
    r.onerror = (e) => {
      if (r !== recog) return;
      const code = (e && e.error) || "";
      recog = null;
      micOff();
      if (r._stopped || code === "aborted") return;
      if (code === "not-allowed" || code === "service-not-allowed") toast(t("micDenied"), 3000);
      else if (code === "no-speech" || code === "no-match") toast(t("voiceNoHear"), 2200);
      else if (code === "network") toast(t("voiceNet"), 3000);
      else toast(t("noSpeech"), 2500);
    };
    // watchdog: if the engine never fires end/error, release the mic instead of hanging "on"
    recogTimer = setTimeout(() => {
      if (recog !== r) return;
      recog = null;
      r._stopped = true;
      try { r.abort ? r.abort() : r.stop(); } catch {}
      micOff();
    }, 15000);
    try { r.start(); } catch { recog = null; micOff(); toast(t("noSpeech")); }
  });
}

/* ---------- export ---------- */
async function exportPng() {
  const src = $("#c2d");
  const was3d = state.mode === "3d";
  if (was3d) show2d();
  // render to a slightly larger offscreen canvas with watermark
  const out = document.createElement("canvas");
  const w = Math.max(src.clientWidth, 900);
  const h = Math.max(src.clientHeight, 1200);
  out.width = w * 2;
  out.height = h * 2;
  out.style.width = w + "px";
  out.style.height = h + "px";
  // temporarily draw using same view on offscreen — easier: copy current after redraw with watermark
  draw2d();
  const mark = state.settings?.watermark || "Bunty's";
  const tmp = document.createElement("canvas");
  tmp.width = src.width;
  tmp.height = src.height;
  tmp.style.width = src.style.width;
  tmp.style.height = (src.clientHeight || 1) + "px";
  // Use the on-screen canvas size
  const exportCanvas = document.createElement("canvas");
  exportCanvas.width = src.width;
  exportCanvas.height = src.height;
  const ectx = exportCanvas.getContext("2d");
  ectx.drawImage(src, 0, 0);
  // watermark in pixel space
  ectx.fillStyle = "rgba(30,24,16,0.38)";
  ectx.font = `600 ${Math.max(18, exportCanvas.width / 40)}px system-ui, sans-serif`;
  ectx.textAlign = "right";
  ectx.textBaseline = "bottom";
  ectx.fillText(mark, exportCanvas.width - 20, exportCanvas.height - 16);

  const blob = await new Promise((res) => exportCanvas.toBlob(res, "image/png"));
  if (!blob) return;
  const file = new File([blob], (state.project?.name || "naksha") + ".png", { type: "image/png" });
  try {
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: state.project?.name || "Naksha", text: mark });
      toast(t("copied"));
      return;
    }
  } catch (err) {
    if (err && err.name === "AbortError") return;
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = file.name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast(t("copied"));
}

const STD_SCALES = [20, 25, 50, 75, 100, 125, 150, 200, 250, 300, 400, 500, 750, 1000];
function pdfBounds() {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  const add = (x, y, m = 0) => { if (!isFinite(x) || !isFinite(y)) return; minX = Math.min(minX, x - m); minY = Math.min(minY, y - m); maxX = Math.max(maxX, x + m); maxY = Math.max(maxY, y + m); };
  for (const w of state.walls) { add(w.x1, w.y1, 1); add(w.x2, w.y2, 1); }
  for (const d of state.doors) { const w = state.walls.find((x) => x.id === d.wallId); if (w) add(w.x1 + (w.x2 - w.x1) * d.t, w.y1 + (w.y2 - w.y1) * d.t, (d.width || 3) + 0.8); }
  for (const s of state.stairs || []) for (const p of stairPoly(s)) add(p.x, p.y, 0.5);
  for (const f of state.furniture || []) for (const P of itemPolys(f, FURNITURE[f.kind] || FURNITURE.bed)) for (const p of P) add(p.x, p.y, 0.3);
  for (const c of state.columns || []) add(c.x, c.y, 1.5);
  for (const m of state.mep || []) add(m.x, m.y, 1);
  if (!isFinite(minX)) { minX = 0; minY = 0; maxX = 20; maxY = 20; }
  if (state.vastuOn) {
    const ext0 = (SIZE[state.settings?.size] || SIZE.medium).extent;
    const vc = planCenter(ext0);
    const vr = vc.r * 1.16 * 1.08 + 1.5;
    add(vc.x, vc.y, vr);
  }
  // room for dimension labels outside the walls
  return { minX: minX - 2.5, minY: minY - 2.5, maxX: maxX + 2.5, maxY: maxY + 2.5 };
}
function openPdfSheet(paper) {
  const cur = state.settings?.scale || 100;
  $("#sheet").innerHTML = `
    <h3>PDF</h3>
    <label>${t("paper")}</label>
    <div class="seg" id="pdf-paper"><button type="button" data-v="a4" class="${paper !== "a3" ? "on" : ""}">A4</button><button type="button" data-v="a3" class="${paper === "a3" ? "on" : ""}">A3</button></div>
    <label>${t("scale")}</label>
    <div class="seg" id="pdf-scale" style="flex-wrap:wrap">${[0, 50, 100, 200].map((v) => `<button type="button" data-v="${v}" class="${(v === 0 && ![50, 100, 200].includes(cur)) || v === cur ? "on" : ""}">${v ? "1:" + v : t("auto")}</button>`).join("")}</div>
    <p class="hint">${t("pdfScaleHint")}</p>
    <div class="row" style="margin-top:8px"><button class="btn small" id="pdf-go">${t("pdfMake")}</button></div>`;
  openSheet();
  for (const g of ["#pdf-paper", "#pdf-scale"]) $$(g + " button").forEach((b) => b.addEventListener("click", () => { $$(g + " button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); }));
  $("#pdf-go").onclick = () => {
    const pp = $("#pdf-paper .on")?.dataset.v || "a4";
    const sc = parseInt($("#pdf-scale .on")?.dataset.v || "0", 10);
    if (sc) { state.settings.scale = sc; persist(); }
    closeSheet();
    exportPdf(pp, sc || 0);
  };
}
async function exportPdf(paper, wantScale) {
  const JSPDF = window.jspdf?.jsPDF;
  if (!JSPDF) { toast(t("pdfLibMissing")); return; }
  const was3d = state.mode === "3d";
  if (was3d) show2d();
  const want = wantScale === undefined ? (state.settings?.scale || 0) : wantScale;
  const fmt = paper === "a3" ? "a3" : "a4";
  const P = fmt === "a3" ? [297, 420] : [210, 297];
  const margin = 10, titleH = 26;
  const bb = pdfBounds();
  const worldW = Math.max(1, bb.maxX - bb.minX), worldH = Math.max(1, bb.maxY - bb.minY);
  // pick orientation + the largest standard scale (1:n with smallest n) that fits
  let best = null;
  for (const orient of ["portrait", "landscape"]) {
    const pw = orient === "portrait" ? P[0] : P[1], ph = orient === "portrait" ? P[1] : P[0];
    const boxW = pw - margin * 2, boxH = ph - margin * 2 - titleH;
    const fit = Math.max(worldW / boxW, worldH / boxH) * 304.8;
    const sc = STD_SCALES.find((x) => x >= fit - 1e-6) || Math.ceil(fit / 50) * 50;
    if (!best || sc < best.sc || (sc === best.sc && (orient === "portrait") === (worldH >= worldW))) best = { orient, pw, ph, boxW, boxH, sc };
  }
  let usedScale = best.sc, note = "";
  if (want && want >= best.sc) usedScale = want;
  else if (want && want < best.sc) note = ` (1:${want} ${t("pdfNoFit")})`;
  const { pw, ph, boxW, boxH } = best;
  const doc = new JSPDF({ orientation: best.orient, unit: "mm", format: fmt });
  const mmPerFt = 304.8 / usedScale;
  const drawW = worldW * mmPerFt, drawH = worldH * mmPerFt;

  const cnv = document.createElement("canvas");
  const dprNow = Math.min(devicePixelRatio || 1, 2);
  const capPx = Math.sqrt(9e6 / Math.max(1, drawW * drawH * dprNow * dprNow));
  const pxPerMm = Math.max(2, Math.min(capPx, 7));
  const pxW = Math.round(drawW * pxPerMm), pxH = Math.round(drawH * pxPerMm);
  cnv.width = pxW; cnv.height = pxH;
  const saved = { ...state.view };
  cnv.style.width = pxW + "px"; cnv.style.height = pxH + "px";
  const zoom = Math.min(pxW / (worldW * PX), pxH / (worldH * PX));
  state.view.zoom = zoom;
  state.view.panX = -bb.minX * zoom * PX;
  state.view.panY = -bb.minY * zoom * PX;
  cnv.style.position = "fixed"; cnv.style.left = "-9999px";
  document.body.appendChild(cnv);
  labelK = Math.max(1, (2.4 * pxPerMm) / 12); // ~2.4 mm label text on paper
  try { draw2d(cnv, { watermark: "" }); } finally { labelK = 1; }
  document.body.removeChild(cnv);
  state.view = saved;
  draw2d();

  const img = cnv.toDataURL("image/jpeg", 0.9);
  const x0 = margin + (boxW - drawW) / 2, y0 = margin + (boxH - drawH) / 2;
  doc.setDrawColor(60); doc.setLineWidth(0.4);
  doc.rect(margin, margin, boxW, ph - margin * 2);
  try { doc.addImage(img, "JPEG", x0, y0, drawW, drawH); } catch (e) { console.warn(e); }

  const mark = state.settings?.watermark || "";
  if (mark) { doc.setFontSize(26); doc.setTextColor(215, 208, 196); doc.text(mark, pw / 2, ph / 2, { align: "center", angle: 20 }); }

  // title block
  const ty = ph - margin - titleH;
  doc.setFillColor(247, 243, 235); doc.rect(margin, ty, boxW, titleH, "F");
  doc.setDrawColor(60); doc.rect(margin, ty, boxW, titleH);
  const split = margin + boxW * 0.62;
  doc.line(split, ty, split, ty + titleH);
  doc.setTextColor(30, 24, 16);
  const proj = state.project?.name || "Naksha";
  const fl = floorName(state.floorIndex);
  const date = new Date().toLocaleDateString("en-IN");
  const ascii = (x) => String(x).replace(/[^\x20-\x7e]/g, "").trim() || "-";
  doc.setFont("helvetica", "bold"); doc.setFontSize(15);
  doc.text("Naksha Art", split + 4, ty + 9);
  doc.setFont("helvetica", "normal"); doc.setFontSize(8.5);
  doc.text(`Scale 1:${usedScale} (${fmt.toUpperCase()})${note ? " *" : ""}`, split + 4, ty + 15);
  doc.text(`Date ${date}`, split + 4, ty + 20);
  doc.setFont("helvetica", "bold"); doc.setFontSize(11);
  doc.text(ascii(proj).slice(0, 48), margin + 4, ty + 8);
  doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  const ps = state.settings?.plotW && state.settings?.plotD ? `Plot ${fmtLen(state.settings.plotW)} x ${fmtLen(state.settings.plotD)}  ·  ` : "";
  doc.text(ascii(`${fl}  ·  ${ps}Floor ${fmtLen(state.settings.floorHeight || 10)}  ·  Plinth ${fmtLen(state.settings.plinth ?? 2)}`).replace(/\s+/g, " "), margin + 4, ty + 14);
  if (note) { doc.setFontSize(7.5); doc.text(ascii("* " + note.trim()), margin + 4, ty + 19); }
  // scale bar: 5 segments of 1 m or 2 ft
  const metric = state.settings?.units === "m";
  const segFt = metric ? 1 / 0.3048 : 2, segMm = segFt * mmPerFt;
  const nSeg = Math.max(2, Math.min(5, Math.floor((split - margin - 20) / Math.max(1, segMm))));
  const sbx = margin + 4, sby = ty + titleH - 5;
  for (let i = 0; i < nSeg; i++) { doc.setFillColor(i % 2 ? 255 : 40, i % 2 ? 255 : 40, i % 2 ? 255 : 40); doc.rect(sbx + i * segMm, sby - 1.6, segMm, 1.6, "FD"); }
  doc.setFontSize(6.5);
  for (let i = 0; i <= nSeg; i++) doc.text(String(Math.round(i * (metric ? 1 : 2))) + (i === nSeg ? (metric ? " m" : " ft") : ""), sbx + i * segMm, sby - 2.4, { align: "center" });

  const fname = (proj + "-" + fl + ".pdf").replace(/\s+/g, "_");
  doc.save(fname);
  toast(`PDF 1:${usedScale} ${fmt.toUpperCase()} ${best.orient === "portrait" ? "↕" : "↔"}`, 2600);
  if (was3d) switchMode("3d");
}

/* ---------- boot ---------- */
function bindUI() {
  $("#login-btn").addEventListener("click", tryLogin);
  if(/[?&]demo=1/.test(location.search)){state.user="naksha_1dba71";localStorage.setItem("naksha_session",state.user);}
  const db=$("#demo-btn"); if(db) db.addEventListener("click",()=>{state.user="naksha_1dba71";localStorage.setItem("naksha_session",state.user);$("#login-err").textContent="";openHome();});
  $("#login-pass").addEventListener("keydown", (e) => {
    if (e.key === "Enter") tryLogin();
  });
  $("#login-user").addEventListener("keydown", (e) => {
    if (e.key === "Enter") $("#login-pass").focus();
  });
  setupKeyboardInsets();
  $("#lang-btn").addEventListener("click", openLangPicker);
  $("#lang-btn-2").addEventListener("click", openLangPicker);
  $("#logout-btn").addEventListener("click", () => {
    persist();
    localStorage.removeItem("naksha_session");
    state.user = "naksha_1dba71";
    localStorage.setItem("naksha_session", state.user);
    openHome();
  });
  $("#new-btn").addEventListener("click", () => {
    fillFormDefaults();
    showScreen("screen-form");
    applyI18n();
  });
  $("#form-back").addEventListener("click", () => openHome());
  $("#home-backup")?.addEventListener("click", backupAll);
  $("#home-restore")?.addEventListener("click", () => $("#restore-file")?.click());
  $("#remind-go")?.addEventListener("click", backupAll);
  $("#form-go").addEventListener("click", newProjectFromForm);
  $$("#f-size").forEach(() => {});
  $$("#f-size button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#f-size button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $$("#f-units button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#f-units button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      onUnitsChange();
    })
  );
  $("#f-scale").addEventListener("change", () => {
    $("#f-scale-custom").classList.toggle("hidden", $("#f-scale").value !== "custom");
  });

  $("#ed-back").addEventListener("click", leaveEditor);
  $("#ed-2d3d").addEventListener("click", () => switchMode(state.mode === "2d" ? "3d" : "2d"));
  $("#ed-undo").addEventListener("click", undo);
  $("#ed-redo").addEventListener("click", redo);
  $("#ed-menu").addEventListener("click", (e) => {
    e.stopPropagation();
    $("#menu").classList.toggle("open");
  });
  document.addEventListener("click", (e) => {
    if (!$("#menu").contains(e.target) && e.target !== $("#ed-menu")) $("#menu").classList.remove("open");
  });
  $("#m-vastu").addEventListener("click", () => {
    state.vastuOn = !state.vastuOn;
    applyI18n();
    if (state.mode === "3d") show2d();
    draw2d();
    persist();
    $("#menu").classList.remove("open");
  });
  $("#m-north").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    openNorthSheet();
  });
  $("#m-export").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    exportPng();
  });
  $("#m-pdf-a4").addEventListener("click", () => { $("#menu").classList.remove("open"); openPdfSheet("a4"); });
  $("#m-pdf-a3").addEventListener("click", () => { $("#menu").classList.remove("open"); openPdfSheet("a3"); });
  $("#m-floor-add").addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(false); });
  $("#m-floor-copy").addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(true); });
  const mBase = $("#m-basement");
  if (mBase) mBase.addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(false, { basement: true }); });
  const bindMenu = (id, fn) => { const el = $(id); if (el) el.addEventListener("click", () => { $("#menu").classList.remove("open"); fn(); }); };
  bindMenu("#m-corners", () => { state.showCornerAngles = !state.showCornerAngles; persist(); draw2d(); toast(t("corners") + (state.showCornerAngles ? " on" : " off")); });
  bindMenu("#m-wallang", () => { state.showWallAngles = !state.showWallAngles; persist(); draw2d(); toast(t("wallAng") + (state.showWallAngles ? " on" : " off")); });
  bindMenu("#m-boq", () => showBoq());
  bindMenu("#m-dxf", () => exportDxf());
  bindMenu("#m-vreport", () => vastuReportPdf());
  bindMenu("#m-backup", () => backupJson());
  bindMenu("#m-restore", () => $("#restore-file")?.click());
  bindMenu("#m-roof", () => { state.roofOn = !state.roofOn; persist(); if (state.mode === "3d") refresh3d(); else switchMode("3d"); toast(t("roof") + (state.roofOn ? " on" : " off")); });
  bindMenu("#m-walk", () => toggleWalk());
  bindMenu("#m-sun", () => toggleSun(true));
  $("#restore-file")?.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) restoreJson(f);
    e.target.value = "";
  });
  $$("#snap-bar [data-snap]").forEach((b) => b.addEventListener("click", () => setSnap(b.dataset.snap)));
  setSnap(state.angleSnap);
  $$(".tmpl").forEach((b) => b.addEventListener("click", () => applyTemplate(b.dataset.tmpl)));
  $("#walk-exit")?.addEventListener("click", () => toggleWalk(false));
  $$("#walk-bar [data-w]").forEach((b) => b.addEventListener("click", () => {
    if (!view3d) return;
    const k = b.dataset.w;
    if (k === "l" || k === "r") view3d.lookWalk(k);
    else view3d.moveWalk(k);
  }));
  $("#sun-hour")?.addEventListener("input", (e) => {
    state.sunHour = parseFloat(e.target.value) || 10;
    const h = Math.floor(state.sunHour), m = Math.round((state.sunHour - h) * 60);
    const lab = $("#sun-lab"); if (lab) lab.textContent = String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
    // only move the sun; rebuilding the scene would reset the user's camera on every slider tick
    if (state.mode === "3d" && view3d) view3d.setSun(state.sunHour, state.northDeg, state.sunOn);
  });
  $("#m-save").addEventListener("click", () => {
    persist();
    toast(t("saved"));
    $("#menu").classList.remove("open");
  });
  $("#m-lang").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    openLangPicker();
  });
  const mImp = $("#m-import");
  if (mImp) mImp.addEventListener("click", () => { $("#menu").classList.remove("open"); openImport(); });
  const imp = $("#import-file");
  if (imp) imp.addEventListener("change", (e) => {
    const f = e.target.files && e.target.files[0];
    if (f) onImportFile(f);
    e.target.value = "";
  });

  $$("#tools [data-tool]").forEach((b) => b.addEventListener("click", () => setTool(b.dataset.tool)));
  // keep the command box focused while tapping "Kar do" / mic: otherwise the keyboard closes,
  // the bar jumps down and the tap lands on nothing (v1.0.2 bug)
  for (const id of ["#cmd-go", "#mic"]) {
    $(id).addEventListener("pointerdown", (e) => { if (document.activeElement === $("#cmd")) e.preventDefault(); });
    $(id).addEventListener("mousedown", (e) => { if (document.activeElement === $("#cmd")) e.preventDefault(); });
  }
  $("#cmd-go").addEventListener("click", () => {
    runCommand($("#cmd").value);
  });
  $("#cmd").addEventListener("keydown", (e) => {
    if (e.key === "Enter") runCommand($("#cmd").value);
  });

  setupVoice();
  bindCanvas();

  addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
      e.preventDefault();
      if (e.shiftKey) redo();
      else undo();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
      e.preventDefault();
      redo();
    }
  });
}

// In-app back stack, shared by the Android back button (APK calls window.__nakshaBack) and the
// browser/PWA back gesture (history.popstate). Returns true when it handled the back press.
function appBack() {
  const vis = (id) => { const e = $(id); return e && !e.classList.contains("hidden"); };
  if ($("#menu")?.classList.contains("open")) { $("#menu").classList.remove("open"); return true; }
  if ($("#sheet")?.classList.contains("open")) { closeSheet(); return true; }
  if (view3d && view3d.walk) { toggleWalk(false); return true; }
  if (vis("#screen-editor")) {
    if (state.mode === "3d") { switchMode("2d"); return true; }
    leaveEditor(); return true;
  }
  if (vis("#screen-form")) { openHome(); return true; }
  return false;
}
window.__nakshaBack = appBack;
function setupHistoryBack() {
  if (window.NakshaNative) return; // the APK drives back itself
  try {
    history.replaceState({ naksha: "base" }, "");
    history.pushState({ naksha: "app" }, "");
    addEventListener("popstate", () => {
      if (appBack()) history.pushState({ naksha: "app" }, "");
    });
  } catch {}
}

async function boot() {
  const pref = localStorage.getItem("naksha_lang") || "hi";
  await initI18n(pref);
  state.lang = (currentLocale() && currentLocale().code) || pref;
  applyI18n();
  bindUI();
  if ("serviceWorker" in navigator) {
    try { await navigator.serviceWorker.register("./sw.js"); } catch {}
  }
  state.user = localStorage.getItem("naksha_session") || "naksha_1dba71";
  try { localStorage.setItem("naksha_session", state.user); } catch {}
  // ask the browser not to evict our projects under storage pressure
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {}); } catch {}
  // toast lives on <body> so it also shows on the home screen
  const tEl = $("#toast"); if (tEl && tEl.parentElement !== document.body) document.body.appendChild(tEl);
  setupHistoryBack();
  openHome();
}

window.Naksha = { state, addWall, draw2d, switchMode, persist, setTool, runCommand, placeWindow, placeColumn, refreshRooms, addFloor, switchFloor, exportPdf, applyTemplate, showBoq, setSnap, openImport, openLangPicker, setVastu };
boot();
