import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { stairGeometry, itemRects } from "./smart.js";

const FT = 1; // world units are feet

export class View3D {
  constructor(canvas) {
    this.canvas = canvas;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x1c2228);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 800);
    this.camera.position.set(18, 22, 28);
    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true;
    this.controls.target.set(10, 0, 10);
    this.group = new THREE.Group();
    this.scene.add(this.group);

    const hemi = new THREE.HemisphereLight(0xe8e0d0, 0x3a3530, 1.05);
    this.scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xfff3d8, 1.1);
    dir.position.set(20, 40, 12);
    this.sun = dir;
    this.scene.add(dir);
    this.scene.add(dir.target);
    // real shadows for the sun study (only switched on while "dhoop" is on, to keep phones fast)
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    dir.shadow.mapSize.set(1024, 1024);
    dir.shadow.bias = -0.0008;
    this.walk = false;
    this._walkYaw = 0;
    this._walkEye = 5.2;
    const fill = new THREE.DirectionalLight(0x88a0b8, 0.35);
    fill.position.set(-20, 10, -10);
    this.scene.add(fill);

    this.ground = new THREE.Mesh(
      new THREE.PlaneGeometry(400, 400),
      new THREE.MeshStandardMaterial({ color: 0x3e4540, roughness: 1 })
    );
    this.ground.rotation.x = -Math.PI / 2;
    this.scene.add(this.ground);

    const grid = new THREE.GridHelper(200, 200, 0x555e55, 0x454c46);
    grid.position.y = 0.01;
    this.scene.add(grid);

    this.human = makeHuman();
    this.scene.add(this.human);

    this._running = false;
    this._raf = 0;
    this._onResize = () => this.resize();
  }

  resize() {
    const p = this.canvas.parentElement || this.canvas;
    const w = p.clientWidth || 1;
    const h = p.clientHeight || 1;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  show() {
    this.canvas.classList.remove("hidden");
    this.resize();
    this._running = true;
    cancelAnimationFrame(this._raf);
    const loop = () => {
      if (!this._running) return;
      // OrbitControls.update() re-aims the camera at its target even when disabled,
      // which froze walkthrough look/move — skip it while walking.
      if (!this.walk) this.controls.update();
      this.renderer.render(this.scene, this.camera);
      this._raf = requestAnimationFrame(loop);
    };
    loop();
    addEventListener("resize", this._onResize);
  }

  hide() {
    this._running = false;
    cancelAnimationFrame(this._raf);
    this.canvas.classList.add("hidden");
    removeEventListener("resize", this._onResize);
  }

  build(data) {
    this.group.clear();
    const floorH = data.settings?.floorHeight ?? 10;
    const plinth = data.settings?.plinth ?? 2;
    const story = floorH + 0.85;
    const floors = (data.floors && data.floors.length)
      ? data.floors
      : [{ walls: data.walls || [], doors: data.doors || [], windows: data.windows || [], stairs: data.stairs || [], columns: data.columns || [], rooms: data.rooms || [] }];

    let union = null;
    let maxLevel = 0, minLevel = 0;
    let topFloor = floors[0];
    floors.forEach((f, i) => {
      const level = f.level != null ? f.level : i;
      if (level > maxLevel) { maxLevel = level; topFloor = f; }
      if (level < minLevel) minLevel = level;
      const y0 = plinth + level * story;
      const b = buildStorey(this.group, f, floorH, y0, data);
      if (b) union = union ? mergeB(union, b) : b;
    });

    const b = union || { minX: 0, minY: 0, maxY: 16, cx: 8, cy: 8, w: 16, h: 16 };
    if (data.roofOn && topFloor) {
      addRoof(this.group, topFloor, floorH, plinth + maxLevel * story, data);
    }
    this.setSun(data.sunHour ?? 10, data.northDeg ?? 0, data.sunOn, b);
    const stackH = plinth + (maxLevel + 1) * story;
    const minY = plinth + minLevel * story;
    this.human.position.set(b.cx, Math.max(0, plinth), b.maxY + 2.8);
    // keep the user's orbit while editing in 3D; frame the house on entry / when asked
    if (!this.walk && (data.reframe || !this._framed)) {
      this._framed = true;
      this.controls.target.set(b.cx, (minY + stackH) * 0.4, b.cy);
      const dist = Math.max(20, Math.max(b.w, b.h, stackH - minY) * 1.5 + 16);
      this.camera.position.set(b.minX - dist * 0.25, minY + dist * 0.62, b.cy + dist * 0.75);
      this.controls.update();
    }
  }

  setSun(hour, northDeg, on, bounds) {
    if (!this.sun) return;
    const b = bounds || this._bounds || { cx: 0, cy: 0, w: 40, h: 40 };
    this._bounds = b;
    const h = hour ?? 10;
    const t = Math.max(0, Math.min(1, (h - 6) / 12));
    const az = t * Math.PI;
    const alt = Math.sin(t * Math.PI) * 0.85 + 0.08;
    const r = 80;
    let x = Math.cos(az) * r * Math.cos(alt);
    let z = Math.sin(az) * r * Math.cos(alt);
    const y = r * Math.sin(alt);
    const th = ((northDeg || 0) * Math.PI) / 180;
    const x2 = x * Math.cos(th) - z * Math.sin(th);
    const z2 = x * Math.sin(th) + z * Math.cos(th);
    this.sun.position.set(b.cx + x2, y, b.cy + z2);
    this.sun.target.position.set(b.cx, 0, b.cy);
    this.sun.target.updateMatrixWorld();
    this.sun.intensity = on === false ? 0.35 : 1.15;
    this.sun.visible = true;
    const shadows = !!on;
    this.sun.castShadow = shadows;
    if (shadows) {
      const half = Math.max(b.w || 0, b.h || 0) * 0.75 + 20;
      const cam = this.sun.shadow.camera;
      cam.left = -half; cam.right = half; cam.top = half; cam.bottom = -half;
      cam.near = 1; cam.far = 260;
      cam.updateProjectionMatrix();
    }
    this.ground.receiveShadow = shadows;
    this.group.traverse((o) => {
      if (o.isMesh) { o.castShadow = shadows; o.receiveShadow = shadows; }
    });
    this.human.traverse((o) => { if (o.isMesh) o.castShadow = shadows; });
  }

  setWalk(on, data) {
    this.walk = !!on;
    this.controls.enabled = !this.walk;
    if (!this.walk) return;
    const floors = data.floors || [];
    const f = floors[data.floorIndex] || floors[0] || {};
    const level = f.level != null ? f.level : (data.floorIndex || 0);
    const story = (data.settings?.floorHeight ?? 10) + 0.85;
    const y0 = (data.settings?.plinth ?? 2) + level * story;
    this._walkEye = y0 + 5.2;
    this._walkYaw = 0;
    let cx = 10, cy = 10;
    const w = (f.walls || [])[0];
    if (w) { cx = (w.x1 + w.x2) / 2; cy = (w.y1 + w.y2) / 2; }
    if (f.rooms && f.rooms[0]) { cx = f.rooms[0].cx; cy = f.rooms[0].cy; }
    this.camera.position.set(cx, this._walkEye, cy);
    this.camera.lookAt(cx, this._walkEye, cy + 4);
    this.controls.target.set(cx, this._walkEye, cy + 4);
  }
  moveWalk(dir) {
    if (!this.walk) return;
    const speed = 1.4;
    const yaw = this._walkYaw || 0;
    const fx = Math.sin(yaw), fz = Math.cos(yaw);
    if (dir === "f") { this.camera.position.x += fx * speed; this.camera.position.z += fz * speed; }
    if (dir === "b") { this.camera.position.x -= fx * speed; this.camera.position.z -= fz * speed; }
    this.camera.lookAt(
      this.camera.position.x + Math.sin(yaw),
      this._walkEye,
      this.camera.position.z + Math.cos(yaw)
    );
  }
  lookWalk(dir) {
    if (!this.walk) return;
    this._walkYaw = (this._walkYaw || 0) + (dir === "l" ? -0.28 : 0.28);
    const yaw = this._walkYaw;
    this.camera.lookAt(
      this.camera.position.x + Math.sin(yaw),
      this._walkEye,
      this.camera.position.z + Math.cos(yaw)
    );
  }
}

function mergeB(a, b) {
  const minX = Math.min(a.minX, b.minX), minY = Math.min(a.minY, b.minY);
  const maxX = Math.max(a.maxX, b.maxX), maxY = Math.max(a.maxY, b.maxY);
  return { minX, minY, maxX, maxY, w: maxX - minX, h: maxY - minY, cx: (minX + maxX) / 2, cy: (minY + maxY) / 2 };
}

function buildStorey(group, f, floorH, y0, data) {
  const walls = f.walls || [];
  const doors = f.doors || [];
  const windows = f.windows || [];
  const stairs = f.stairs || [];
  const columns = f.columns || [];
  const rooms = f.rooms || [];
  if (!walls.length && !columns.length) return null;
  const b = walls.length ? boundsOf(walls) : boundsOf(columns.map((c) => ({ x1: c.x, y1: c.y, x2: c.x, y2: c.y })));
  const pad = 2;
  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(b.w + pad * 2, 0.25, b.h + pad * 2),
    new THREE.MeshStandardMaterial({ color: 0x8a8680, roughness: 0.9 })
  );
  slab.position.set(b.cx, y0 - 0.12, b.cy);
  group.add(slab);
  const plinthH = data.settings?.plinth ?? 2;
  if (Math.abs(y0 - plinthH) < 0.01 && plinthH > 0.05) {
    // solid plinth (masonry + filling) from ground to floor level
    const pl = new THREE.Mesh(
      new THREE.BoxGeometry(b.w + pad * 2 - 0.1, plinthH, b.h + pad * 2 - 0.1),
      new THREE.MeshStandardMaterial({ color: 0x9c8f7d, roughness: 0.95 })
    );
    pl.position.set(b.cx, y0 - plinthH / 2 - 0.01, b.cy);
    group.add(pl);
  }

  for (const r of rooms) addRoomFloor(group, r, y0, data);
  for (const w of walls) {
    addWallWithOpenings(
      group, w,
      doors.filter((d) => d.wallId === w.id),
      windows.filter((k) => k.wallId === w.id),
      rooms, floorH, y0
    );
  }
  for (const s of stairs) addStair(group, s, floorH, s.base === "ground" ? y0 - (data.settings?.plinth ?? 2) : y0);
  for (const c of columns) addColumn(group, c, floorH, y0);
  for (const fu of f.furniture || []) addFurniture(group, fu, y0);
  for (const m of f.mep || []) addMep(group, m, y0, floorH);
  return b;
}

function addRoomFloor(group, r, y0, data) {
  if (!r.poly || r.poly.length < 3) return;
  const shape = new THREE.Shape();
  r.poly.forEach((p, i) => i ? shape.lineTo(p.x, p.y) : shape.moveTo(p.x, p.y));
  shape.closePath();
  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  let col = r.floorColor || "#d9d1c3";
  if (data.vastuOn) {
    // tint is applied by caller via room.floorColor; keep room colour unless vastu overlay
    // (vastu fill is already in 2D; 3D uses floor colour so the paint choice stays visible)
  }
  const mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.95, metalness: 0 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = y0 + 0.02;
  group.add(mesh);
}

function addColumn(group, c, floorH, y0) {
  const h = c.height || floorH;
  const mat = new THREE.MeshStandardMaterial({ color: 0x6a645c, roughness: 0.8 });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(c.w || 0.75, h, c.d || 1), mat);
  mesh.position.set(c.x, y0 + h / 2, c.y);
  mesh.rotation.y = -((c.rot || 0) * Math.PI) / 180;
  group.add(mesh);
}

function wallFaceMats(wall, rooms) {
  const out = new THREE.Color(wall.colorOut || wall.color || "#2c3d4f");
  const inn = new THREE.Color(wall.colorIn || wall.color || "#2c3d4f");
  const mOut = new THREE.MeshStandardMaterial({ color: out, roughness: 0.85, metalness: 0.02 });
  const mIn = new THREE.MeshStandardMaterial({ color: inn, roughness: 0.85, metalness: 0.02 });
  const edge = mOut;
  // +Z is left of start→end. If left is inside a room, +Z gets inside colour.
  const leftIn = leftInside(wall, rooms);
  const pz = leftIn ? mIn : mOut;
  const nz = leftIn ? mOut : mIn;
  return [edge, edge, mOut, mOut, pz, nz];
}

function leftInside(wall, rooms) {
  if (!rooms || !rooms.length) return false;
  const dx = wall.x2 - wall.x1, dy = wall.y2 - wall.y1;
  const len = Math.hypot(dx, dy) || 1;
  const mx = (wall.x1 + wall.x2) / 2, my = (wall.y1 + wall.y2) / 2;
  const lx = mx + (-dy / len) * 0.4, ly = my + (dx / len) * 0.4;
  return rooms.some((r) => r.poly && pointInPoly3(lx, ly, r.poly));
}

function pointInPoly3(x, y, pts) {
  let inr = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
    const hit = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-12) + xi;
    if (hit) inr = !inr;
  }
  return inr;
}

function boundsOf(walls) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const w of walls) {
    minX = Math.min(minX, w.x1, w.x2);
    minY = Math.min(minY, w.y1, w.y2);
    maxX = Math.max(maxX, w.x1, w.x2);
    maxY = Math.max(maxY, w.y1, w.y2);
  }
  return { minX, minY, maxX, maxY, w: maxX - minX, h: maxY - minY, cx: (minX + maxX) / 2, cy: (minY + maxY) / 2 };
}

function addWallWithOpenings(group, wall, doors, windows, rooms, floorH, y0) {
  const dx = wall.x2 - wall.x1, dy = wall.y2 - wall.y1;
  const len = Math.hypot(dx, dy);
  if (len < 0.05) return;
  const rotY = -Math.atan2(dy, dx);
  const th = wall.thickness || 0.75;
  const h = wall.height || floorH;
  const mats = wallFaceMats(wall, rooms);
  const holes = [];
  for (const d of doors || []) {
    const mid = (d.t ?? 0.5) * len;
    const half = (d.width || 3) / 2;
    holes.push({ a: Math.max(0, mid - half), b: Math.min(len, mid + half), z0: 0, z1: Math.min(d.height || 7, h) });
  }
  for (const k of windows || []) {
    const mid = (k.t ?? 0.5) * len;
    const half = (k.width || 4) / 2;
    const z0 = Math.max(0, k.sill || 3);
    const z1 = Math.min(h, z0 + (k.height || 4));
    holes.push({ a: Math.max(0, mid - half), b: Math.min(len, mid + half), z0, z1 });
  }
  const clean = holes.filter((x) => x.b > x.a + 0.05 && x.z1 > x.z0 + 0.05).sort((a, b) => a.a - b.a);

  const cuts = [0];
  for (const ho of clean) { cuts.push(ho.a, ho.b); }
  cuts.push(len);
  const xs = [...new Set(cuts.map((v) => Math.round(v * 1000) / 1000))].sort((a, b) => a - b);

  const ux = dx / len, uy = dy / len;
  function addBox(a, b, yb, yt) {
    const sl = b - a, hh = yt - yb;
    if (sl < 0.03 || hh < 0.06) return;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(sl, hh, th), mats);
    const mid = a + sl / 2;
    mesh.position.set(wall.x1 + ux * mid, y0 + yb + hh / 2, wall.y1 + uy * mid);
    mesh.rotation.y = rotY;
    group.add(mesh);
  }
  for (let i = 0; i < xs.length - 1; i++) {
    const a = xs[i], b = xs[i + 1];
    const here = clean.filter((ho) => ho.a < b - 0.01 && ho.b > a + 0.01);
    if (!here.length) {
      addBox(a, b, 0, h);
      continue;
    }
    const bands = here.map((ho) => [ho.z0, ho.z1]).sort((p, q) => p[0] - q[0]);
    let y = 0;
    for (const [z0, z1] of bands) {
      if (z0 > y + 0.05) addBox(a, b, y, z0);
      y = Math.max(y, z1);
    }
    if (h > y + 0.05) addBox(a, b, y, h);
  }
}

function addStair(group, s, floorH, base) {
  const g = stairGeometry(s);
  const mat = new THREE.MeshStandardMaterial({ color: s.base === "ground" ? 0x8f8a82 : 0x9a8b76, roughness: 0.8 });
  const root = new THREE.Group();
  root.position.set(s.x, base, s.y);
  if (g.type === "spiral") {
    const radius = g.rad;
    const n = g.R;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, n * g.h + 3, 10), mat);
    pole.position.set(0, (n * g.h + 3) / 2, 0);
    root.add(pole);
    for (let i = 0; i < n - 1; i++) {
      const ang = i * (Math.PI / 6);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(radius - 0.2, 0.15, Math.max(0.9, g.T)), mat);
      mesh.position.set(Math.cos(ang) * (radius / 2 + 0.1), (i + 1) * g.h - 0.075, Math.sin(ang) * (radius / 2 + 0.1));
      mesh.rotation.y = -ang;
      root.add(mesh);
    }
  } else {
    root.rotation.y = -((s.rot || 0) * Math.PI) / 180;
    // solid steps: each tread is a block from the ground of this run up to its top
    for (const r of [...g.treads, ...g.land]) {
      const w = r.x1 - r.x0, d = r.y1 - r.y0;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, r.top, d), mat);
      mesh.position.set((r.x0 + r.x1) / 2, r.top / 2, (r.y0 + r.y1) / 2);
      root.add(mesh);
    }
  }
  group.add(root);
}

const FCOL = { bed: 0x6b4a2b, sofa: 0x3d5a7a, sofaL: 0x3d5a7a, dining: 0x8a7348, kitchen: 0x7a6a58, kitchenL: 0x7a6a58, wc: 0xeef0f2, basin: 0xf2f0ea, wardrobe: 0x5c4030, chair: 0x4a4038, bathtub: 0xf4f6f8, shower: 0xb9d3e0, geyser: 0xf0f0ee, sink: 0xb8bec4, hob: 0x222222 };
const FH = { bed: 1.6, sofa: 2.6, sofaL: 2.6, dining: 2.5, kitchen: 2.83, kitchenL: 2.83, wc: 1.35, basin: 2.8, wardrobe: 7, chair: 3, bathtub: 1.8, shower: 0.15, geyser: 1.8, sink: 0.6, hob: 0.12 };
const FELEV = { geyser: 5.3, sink: 2.25, hob: 2.83 };
function addFurniture(group, f, y0) {
  const k = f.kind || "bed";
  const root = new THREE.Group();
  root.position.set(f.x, y0 + (f.elev ?? FELEV[k] ?? 0), f.y);
  root.rotation.y = -((f.rot || 0) * Math.PI) / 180;
  const M = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.75, ...o });
  const box = (x0, y0b, z0, x1, y1, z1, mat) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(Math.max(0.02, x1 - x0), Math.max(0.02, y1 - y0b), Math.max(0.02, z1 - z0)), mat);
    m.position.set((x0 + x1) / 2, (y0b + y1) / 2, (z0 + z1) / 2);
    root.add(m);
    return m;
  };
  const w = f.w || 6, d = f.d || 6, h = FH[k] ?? 2.2;
  const col = M(FCOL[k] ?? 0x6b4a2b);
  const dark = M(0x2a2420), white = M(0xf5f5f5);
  const rects = itemRects(f, { w, d });
  if (k === "kitchen" || k === "kitchenL") {
    const top = M(0x3b3b3b, { roughness: 0.35 });
    for (const r of rects) {
      box(r[0] + 0.05, 0.33, r[1], r[2] - 0.05, h - 0.13, r[3] - 0.08, col);     // cabinets
      box(r[0] + 0.15, 0, r[1], r[2] - 0.15, 0.33, r[3] - 0.25, dark);            // toe kick
      box(r[0], h - 0.13, r[1], r[2], h, r[3], top);                              // granite top
      const horiz = r[2] - r[0] >= r[3] - r[1];
      const n = Math.max(1, Math.round((horiz ? r[2] - r[0] : r[3] - r[1]) / 1.5));
      for (let i = 1; i < n; i++) {
        if (horiz) { const x = r[0] + (i * (r[2] - r[0])) / n; box(x - 0.015, 0.4, r[3] - 0.1, x + 0.015, h - 0.2, r[3] - 0.07, dark); }
        else { const z = r[1] + (i * (r[3] - r[1])) / n; box(r[2] - 0.1, 0.4, z - 0.015, r[2] - 0.07, h - 0.2, z + 0.015, dark); }
      }
    }
  } else if (k === "wardrobe") {
    box(-w / 2, 0, -d / 2, w / 2, h, d / 2 - 0.05, col);
    const n = Math.max(2, Math.round(w / 1.5));
    for (let i = 1; i < n; i++) { const x = -w / 2 + (i * w) / n; box(x - 0.015, 0.3, d / 2 - 0.06, x + 0.015, h - 0.1, d / 2, dark); }
    for (let i = 0; i < n; i++) { const x = -w / 2 + ((i + 0.5) * w) / n + (i % 2 ? -0.25 : 0.25); box(x - 0.03, 3, d / 2, x + 0.03, 4, d / 2 + 0.06, M(0xc9b27a)); }
    box(-w / 2, 6.2, d / 2 - 0.06, w / 2, 6.23, d / 2, dark); // loft line
  } else if (k === "sofa" || k === "sofaL") {
    for (const r of rects) box(r[0], 0, r[1], r[2], 1.4, r[3], col);
    box(-w / 2, 1.4, -d / 2, w / 2, h, -d / 2 + 0.7, col);
    if (k === "sofa") { box(-w / 2, 1.4, -d / 2, -w / 2 + 0.5, 2, d / 2, col); box(w / 2 - 0.5, 1.4, -d / 2, w / 2, 2, d / 2, col); }
    else if (rects[1]) { const r = rects[1], sd = f.legSide || -1; box(sd < 0 ? r[0] : r[2] - 0.7, 1.4, r[1], sd < 0 ? r[0] + 0.7 : r[2], h, r[3], col); }
  } else if (k === "bed") {
    box(-w / 2, 0, -d / 2, w / 2, 1.2, d / 2, col);
    box(-w / 2 + 0.1, 1.2, -d / 2 + 0.1, w / 2 - 0.1, 1.6, d / 2 - 0.1, white);
    box(-w / 2, 0, -d / 2, w / 2, 3.2, -d / 2 + 0.25, col);
  } else if (k === "bathtub") {
    box(-w / 2, 0, -d / 2, w / 2, h, d / 2, col);
    box(-w / 2 + 0.3, h - 0.5, -d / 2 + 0.3, w / 2 - 0.3, h + 0.01, d / 2 - 0.3, M(0x9cc6dc, { roughness: 0.2 }));
  } else if (k === "shower") {
    box(-w / 2, 0, -d / 2, w / 2, 0.15, d / 2, col);
    const glass = M(0xcfe8f2, { transparent: true, opacity: 0.3, roughness: 0.1 });
    box(-w / 2, 0.15, d / 2 - 0.04, w / 2, 6.5, d / 2, glass);
    box(-0.2, 6.6, -d / 2 + 0.05, 0.2, 6.7, -d / 2 + 0.8, M(0xb0b0b0, { metalness: 0.6 }));
  } else if (k === "wc") {
    box(-w / 2 + 0.1, 0, -d / 2, w / 2 - 0.1, 2.6, -d / 2 + 0.6, col);         // cistern
    const bowl = new THREE.Mesh(new THREE.CylinderGeometry(w / 2 - 0.1, w / 2 - 0.25, 1.35, 16), col);
    bowl.scale.z = (d - 0.6) / (w - 0.2);
    bowl.position.set(0, 0.675, 0.3);
    root.add(bowl);
  } else if (k === "basin") {
    box(-0.25, 0, -d / 2, 0.25, 2.5, -d / 2 + 0.5, col);
    box(-w / 2, 2.5, -d / 2, w / 2, 2.8, d / 2, col);
  } else if (k === "geyser") {
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(Math.min(w, d) / 2, Math.min(w, d) / 2, h, 16), col);
    cyl.position.set(0, h / 2, 0);
    root.add(cyl);
  } else if (k === "sink") {
    box(-w / 2, 0.45, -d / 2, w / 2, 0.6, d / 2, M(0xc0c6cc, { metalness: 0.6, roughness: 0.3 }));
    box(-0.05, 0.6, -d / 2 + 0.05, 0.05, 1.3, -d / 2 + 0.15, M(0xb0b0b0, { metalness: 0.6 }));
  } else if (k === "hob") {
    box(-w / 2, 0, -d / 2, w / 2, h, d / 2, col);
  } else {
    for (const r of rects) box(r[0], 0, r[1], r[2], h, r[3], col);
  }
  group.add(root);
}
function addMep(group, m, y0, floorH) {
  const isP = /drain|water|shower/.test(m.kind || "");
  const y = isP ? y0 + 0.15 : y0 + (floorH || 10) - 0.15;
  const col = isP ? 0x3a6a9a : 0xe8c547;
  const mesh = new THREE.Mesh(
    isP ? new THREE.BoxGeometry(0.4, 0.2, 0.4) : new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color: col, emissive: isP ? 0x000000 : 0x665210, roughness: 0.5 })
  );
  mesh.position.set(m.x, y, m.y);
  group.add(mesh);
}
function addRoof(group, f, floorH, y0, data) {
  const walls = f.walls || [];
  if (!walls.length) return;
  const b = boundsOf(walls);
  const y = y0 + floorH + 0.15;
  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(b.w + 1.2, 0.35, b.h + 1.2),
    new THREE.MeshStandardMaterial({ color: 0x8a8680, roughness: 0.9 })
  );
  slab.position.set(b.cx, y, b.cy);
  group.add(slab);
  const paraH = 2.5;
  const mat = new THREE.MeshStandardMaterial({ color: 0x9a9590, roughness: 0.85 });
  const thick = 0.4;
  const edges = [
    [b.cx, b.minY - 0.4, b.w + 1.2, thick],
    [b.cx, b.maxY + 0.4, b.w + 1.2, thick],
    [b.minX - 0.4, b.cy, thick, b.h + 1.2],
    [b.maxX + 0.4, b.cy, thick, b.h + 1.2]
  ];
  for (const [x, z, sx, sz] of edges) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(sx, paraH, sz), mat);
    m.position.set(x, y + paraH / 2, z);
    group.add(m);
  }
}

function makeHuman() {
  // ~5'8" = 5.667 ft
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xc4a882, roughness: 0.7 });
  const cloth = new THREE.MeshStandardMaterial({ color: 0x3d5a7a, roughness: 0.8 });
  const pants = new THREE.MeshStandardMaterial({ color: 0x2c3340, roughness: 0.85 });
  const add = (geo, mat, x, y, z) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  // body centered so feet at y=0
  // Standing height ~5.67 ft (5'8")
  add(new THREE.BoxGeometry(0.16, 2.45, 0.16), pants, -0.12, 2.45 / 2, 0);
  add(new THREE.BoxGeometry(0.16, 2.45, 0.16), pants, 0.12, 2.45 / 2, 0);
  add(new THREE.BoxGeometry(0.42, 0.45, 0.28), pants, 0, 2.45 + 0.22, 0);
  add(new THREE.BoxGeometry(0.50, 2.05, 0.30), cloth, 0, 2.90 + 2.05 / 2, 0);
  add(new THREE.SphereGeometry(0.32, 12, 10), skin, 0, 4.95 + 0.36, 0);
  add(new THREE.BoxGeometry(0.14, 1.85, 0.14), skin, -0.36, 2.95 + 1.85 / 2, 0);
  add(new THREE.BoxGeometry(0.14, 1.85, 0.14), skin, 0.36, 2.95 + 1.85 / 2, 0);
  return g;
}
