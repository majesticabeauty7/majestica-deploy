import { stairGeometry, itemPolys, rectPoly } from "./smart.js";
/* Templates, furniture, MEP, BOQ, DXF, floor names — used by app.js */

export const FURNITURE = {
  bed: { name: "Bed", w: 6, d: 6.5, h: 1.6, color: "#6b4a2b", room: "bed", far: true },
  sofa: { name: "Sofa", w: 6, d: 3, h: 2.6, color: "#3d5a7a", room: "living", center: true },
  sofaL: { name: "L Sofa", w: 7, d: 3, leg: 5, h: 2.6, color: "#3d5a7a", room: "living" },
  dining: { name: "Dining", w: 5, d: 3, h: 2.5, color: "#8a7348", free: true },
  kitchen: { name: "Platform", w: 8, d: 2, h: 2.83, color: "#7a6a58", room: "kitchen", longest: true, fill: [4, 10] },
  kitchenL: { name: "L Platform", w: 8, d: 2, leg: 6, h: 2.83, color: "#7a6a58", room: "kitchen", fill: [5, 10] },
  sink: { name: "Sink", w: 2.5, d: 1.7, h: 0.6, elev: 2.25, color: "#b8bec4", room: "kitchen", onTop: true },
  hob: { name: "Hob", w: 2.3, d: 1.7, h: 0.12, elev: 2.83, color: "#2b2b2b", room: "kitchen", onTop: true },
  wc: { name: "WC", w: 1.5, d: 2.3, h: 1.35, color: "#d0d4d8", room: "wet", far: true },
  basin: { name: "Basin", w: 2, d: 1.5, h: 2.8, color: "#e8e4dc", room: "wet" },
  bathtub: { name: "Bathtub", w: 5.5, d: 2.5, h: 1.8, color: "#e9eef2", room: "wet", corner: true, far: true },
  shower: { name: "Shower", w: 3, d: 3, h: 0.15, color: "#b9d3e0", room: "wet", corner: true },
  geyser: { name: "Geyser", w: 1.3, d: 1.1, h: 1.8, elev: 5.3, color: "#f0f0ee", room: "wet", small: true },
  wardrobe: { name: "Wardrobe", w: 6, d: 2, h: 7, color: "#5c4030", room: "bed", far: true },
  chair: { name: "Chair", w: 1.6, d: 1.6, h: 3, color: "#4a4038", free: true }
};

export const MEP = {
  light: { name: "Light", kind: "e", color: "#e8c547" },
  fan: { name: "Fan", kind: "e", color: "#6a8aaa" },
  ac: { name: "AC", kind: "e", color: "#7aa0b8" },
  switch: { name: "Switch", kind: "e", color: "#c9a227" },
  socket: { name: "Socket", kind: "e", color: "#c9a227" },
  drain: { name: "Drain", kind: "p", color: "#5a7a4a" },
  water: { name: "Water", kind: "p", color: "#3a6a9a" },
  shower: { name: "Shower", kind: "p", color: "#4a8aaa" }
};

const ORDS = {
  ground: 0, gf: 0,
  first: 1, "1st": 1, pehli: 1, pehla: 1, pehle: 1,
  second: 2, "2nd": 2, dusri: 2, dusra: 2, doosri: 2, doosra: 2, doosre: 2,
  third: 3, "3rd": 3, tisri: 3, teesri: 3, teesra: 3, tisra: 3, teesre: 3,
  fourth: 4, "4th": 4, chauthi: 4, chautha: 4, chauthe: 4,
  fifth: 5, "5th": 5, panchvi: 5, panchwen: 5, panchwa: 5,
  sixth: 6, "6th": 6, chhathi: 6, chhatha: 6,
  seventh: 7, "7th": 7, satvin: 7, satwi: 7,
  eighth: 8, "8th": 8, aathvin: 8,
  ninth: 9, "9th": 9, nauvin: 9,
  tenth: 10, "10th": 10, dasvin: 10
};

function ordinalIn(t) {
  for (const [k, v] of Object.entries(ORDS)) {
    if (k.length < 3 && t !== k) continue;
    if (t === k) return v;
    const re = new RegExp("(^|[^a-z0-9])" + k + "([^a-z]|$)", "i");
    if (re.test(t)) return v;
  }
  return null;
}

export function parseFloorLevel(s) {
  const t = (s || "").toLowerCase().replace(/[।.]/g, " ").replace(/\s+/g, " ").trim();
  if (!t) return null;
  const isBase = /\b(basement|cellar|talaghar|tala)\b/.test(t) || /\bb\d+\b/.test(t);
  const bm = t.match(/\bb(?:asement)?\s*[-]?\s*(\d+)\b/) || t.match(/\btala(?:ghar)?\s*(\d+)\b/);
  if (isBase) {
    if (bm) return -Math.max(1, parseInt(bm[1], 10));
    const ord = ordinalIn(t);
    if (ord && ord > 0) return -ord;
    return -1;
  }
  if (/\b(ground|gf)\b/.test(t) || /(?:^|\s)g(?:\s|$)/.test(t)) return 0;
  for (const [k, v] of Object.entries(ORDS)) {
    const re = new RegExp("(^|[^a-z0-9])" + k.replace(/[0-9]/g, (d) => d) + "([^a-z]|$)", "i");
    if (re.test(t) && (/\b(floor|manzil|storey|story)\b/.test(t) || ORDS[t] != null || t === k)) return v;
  }
  // "3 floor", "floor 3", "3rd floor", "teesri manzil"
  for (const [k, v] of Object.entries(ORDS)) {
    if (k.length < 3) continue;
    if (t.includes(k) && /\b(floor|manzil|storey|story)\b/.test(t)) return v;
  }
  const m = t.match(/\b(?:floor|manzil|storey|story)\s*(\d+)\b/) || t.match(/\b(\d+)\s*(?:floor|manzil|storey|story)\b/);
  if (m) return parseInt(m[1], 10);
  if (/^(g|gf|ground)$/.test(t)) return 0;
  return null;
}

export function defaultFloorName(level) {
  if (level === 0) return "Ground";
  if (level < 0) return "B" + Math.abs(level);
  return "Floor " + level;
}

export function shortFloorName(level) {
  if (level === 0) return "G";
  if (level < 0) return "B" + Math.abs(level);
  return String(level);
}

function W(x1, y1, x2, y2, type = "outer") {
  return { x1, y1, x2, y2, type };
}

export const TEMPLATES = {
  "1bhk": {
    name: "1BHK",
    plot: { w: 20, d: 30, front: 3, back: 3, left: 2, right: 2 },
    walls: [
      W(5, 5, 25, 5), W(25, 5, 25, 35), W(25, 35, 5, 35), W(5, 35, 5, 5),
      W(5, 20, 16, 20, "partition"), W(16, 5, 16, 20, "partition"),
      W(16, 27, 25, 27, "partition"), W(16, 20, 16, 27, "partition")
    ],
    doors: [{ wall: 0, t: 0.35, width: 3 }, { wall: 4, t: 0.6, width: 2.75 }, { wall: 6, t: 0.45, width: 2.5 }],
    rooms: [
      { cx: 10.5, cy: 12.5, name: "Bedroom" },
      { cx: 20.5, cy: 23.5, name: "Kitchen" },
      { cx: 15, cy: 28, name: "Living" }
    ]
  },
  "2bhk": {
    name: "2BHK",
    plot: { w: 30, d: 40, front: 5, back: 3, left: 3, right: 3 },
    walls: [
      W(6, 6, 30, 6), W(30, 6, 30, 40), W(30, 40, 6, 40), W(6, 40, 6, 6),
      W(6, 22, 18, 22, "partition"), W(18, 6, 18, 22, "partition"),
      W(18, 28, 30, 28, "partition"), W(18, 22, 18, 40, "partition"),
      W(6, 32, 18, 32, "partition")
    ],
    doors: [
      { wall: 0, t: 0.4, width: 3.5 }, { wall: 4, t: 0.55, width: 2.75 },
      { wall: 6, t: 0.4, width: 2.75 }, { wall: 8, t: 0.4, width: 2.5 }
    ],
    rooms: [
      { cx: 12, cy: 14, name: "Bedroom" },
      { cx: 12, cy: 36, name: "Bedroom" },
      { cx: 24, cy: 17, name: "Living" },
      { cx: 24, cy: 34, name: "Kitchen" }
    ]
  },
  "3bhk": {
    name: "3BHK",
    plot: { w: 30, d: 50, front: 5, back: 4, left: 3, right: 3 },
    walls: [
      W(5, 5, 32, 5), W(32, 5, 32, 48), W(32, 48, 5, 48), W(5, 48, 5, 5),
      W(5, 20, 18, 20, "partition"), W(18, 5, 18, 20, "partition"),
      W(18, 32, 32, 32, "partition"), W(18, 20, 18, 48, "partition"),
      W(5, 34, 18, 34, "partition"),
      W(24, 32, 24, 48, "partition")
    ],
    doors: [
      { wall: 0, t: 0.45, width: 3.5 }, { wall: 4, t: 0.5, width: 2.75 },
      { wall: 6, t: 0.35, width: 2.75 }, { wall: 8, t: 0.4, width: 2.5 }, { wall: 9, t: 0.35, width: 2.5 }
    ],
    rooms: [
      { cx: 11.5, cy: 12.5, name: "Master Bedroom" },
      { cx: 11.5, cy: 41, name: "Bedroom" },
      { cx: 25, cy: 18, name: "Living" },
      { cx: 21, cy: 40, name: "Kitchen" },
      { cx: 28, cy: 40, name: "Bedroom" }
    ]
  },
  shop: {
    name: "Dukaan",
    plot: { w: 15, d: 30, front: 0, back: 3, left: 0, right: 0 },
    walls: [
      W(4, 4, 18, 4), W(18, 4, 18, 28), W(18, 28, 4, 28), W(4, 28, 4, 4),
      W(4, 22, 18, 22, "partition")
    ],
    doors: [{ wall: 0, t: 0.5, width: 5 }, { wall: 4, t: 0.5, width: 2.75 }],
    rooms: [
      { cx: 11, cy: 13, name: "Shop" },
      { cx: 11, cy: 25, name: "Store" }
    ]
  }
};

// Quantity estimate. Factors (Indian practice, nominal mixes):
//  brickwork 1:6 : 500 bricks/m3, dry mortar 0.30 m3/m3  -> cement 1.23 bags, sand 0.257 m3 per m3
//  plaster 12-15 mm 1:5 : dry mortar 0.0156 m3/m2        -> cement 0.075 bags, sand 0.013 m3 per m2
//  RCC M20 (1:1.5:3) : cement 8.06 bags, sand 0.42 m3, aggregate 0.84 m3 per m3
//  PCC 1:4:8 : cement 3.41 bags, sand 0.47 m3, aggregate 0.95 m3 per m3
export const BOQ_F = {
  brickPerM3: 500, mortarDry: 0.30, masonryMix: 6, plasterDryPerM2: 0.0156, plasterMix: 5,
  rcc: { c: 8.06, s: 0.42, a: 0.84 }, pcc: { c: 3.41, s: 0.47, a: 0.95 },
  steel: { slab: 80, beam: 110, stair: 90, column: 160 }
};
const M3 = 0.0283168, M2 = 0.092903;
export function boqFor(floors, settings) {
  const fh = settings?.floorHeight || 10;
  const plinthH = settings?.plinth ?? 2;
  let outerLen = 0, partLen = 0, wallArea = 0, openArea = 0, masonry = 0, plasterA = 0;
  let lintel = 0, stairC = 0, slab = 0, columnsC = 0, entryC = 0;
  let doors = 0, windows = 0, stairs = 0, risers = 0;
  const fixtures = {}, mep = {};
  let ground = null;
  (floors || []).forEach((f, i) => {
    const lvl = f.level ?? i;
    if (lvl === 0 && !ground) ground = f;
    const walls = f.walls || [];
    const byId = {};
    for (const w of walls) byId[w.id] = w;
    for (const w of walls) {
      const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
      const h = w.height || fh, th = w.thickness || 0.75;
      let op = 0;
      for (const d of (f.doors || []).filter((d) => d.wallId === w.id)) op += (d.width || 3) * (d.height || 7);
      for (const k of (f.windows || []).filter((k) => k.wallId === w.id)) op += (k.width || 4) * (k.height || 4);
      const net = Math.max(0, L * h - op);
      wallArea += net; openArea += op;
      masonry += net * th;
      plasterA += net * 2;
      if (w.type === "partition") partLen += L; else outerLen += L;
    }
    for (const d of f.doors || []) { doors++; const w = byId[d.wallId]; lintel += ((d.width || 3) + 1) * (w?.thickness || 0.75) * 0.5; }
    for (const k of f.windows || []) { windows++; const w = byId[k.wallId]; lintel += ((k.width || 4) + 1) * (w?.thickness || 0.75) * 0.5; }
    for (const st of f.stairs || []) {
      const R = st.steps || 16, h = st.riser || 0.5, T = st.tread || 0.83, W = st.width || 3;
      if (st.base === "ground") { entryC += R * (R + 1) / 2 * h * T * W; continue; }
      stairs++; risers += R;
      const run = Math.max(1, R - 2) * T, rise = R * h;
      stairC += (Math.hypot(run, rise) * W * 0.5 + R * (h * T / 2) * W + (st.type === "U" || st.type === "L" ? W * W * 0.5 : 0));
    }
    for (const c of f.columns || []) columnsC += (c.w || 0.75) * (c.d || 1) * fh;
    if (walls.length) {
      let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
      for (const w of walls) { a = Math.min(a, w.x1, w.x2); b = Math.min(b, w.y1, w.y2); c = Math.max(c, w.x1, w.x2); d = Math.max(d, w.y1, w.y2); }
      slab += (c - a + 0.75) * (d - b + 0.75) * (5 / 12);
    }
    for (const fu of f.furniture || []) fixtures[fu.kind] = (fixtures[fu.kind] || 0) + 1;
    for (const m of f.mep || []) mep[m.kind] = (mep[m.kind] || 0) + 1;
  });
  // foundation + plinth (ground floor)
  let excav = 0, pccFound = 0, footMas = 0, plinthBeam = 0, plinthFill = 0, pccFloor = 0, plinthMas = 0, builtUp = 0;
  if (ground && (ground.walls || []).length) {
    const D = 4; // excavation depth (ft)
    for (const w of ground.walls) {
      const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1), th = w.thickness || 0.75;
      const heavy = w.type !== "partition" || th >= 0.7;
      const wf = heavy ? 2.5 : 1.5, dd = heavy ? D : 2;
      excav += L * wf * dd;
      pccFound += L * wf * 0.5;
      footMas += L * (th + (heavy ? 0.75 : 0.25)) * (dd - 0.5);
      plinthBeam += L * th * (heavy ? 0.75 : 0.5);
      if (heavy) plinthMas += L * th * Math.max(0, plinthH - 0.75);
    }
    let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
    for (const w of ground.walls) { a = Math.min(a, w.x1, w.x2); b = Math.min(b, w.y1, w.y2); c = Math.max(c, w.x1, w.x2); d = Math.max(d, w.y1, w.y2); }
    builtUp = (c - a) * (d - b);
    plinthFill = builtUp * Math.max(0, plinthH - 0.33);
    pccFloor = builtUp * 0.33;
  }
  const F = BOQ_F;
  const masM3 = (masonry + footMas + plinthMas) * M3;
  const wallM3 = masonry * M3;
  const mortar = masM3 * F.mortarDry;
  const cMas = (mortar / (1 + F.masonryMix)) * 1440 / 50;
  const sMas = mortar * F.masonryMix / (1 + F.masonryMix);
  const cWallOnly = (wallM3 * F.mortarDry / (1 + F.masonryMix)) * 1440 / 50;
  const plM2 = plasterA * M2;
  const cPl = plM2 * F.plasterDryPerM2 / (1 + F.plasterMix) * 1440 / 50;
  const sPl = plM2 * F.plasterDryPerM2 * F.plasterMix / (1 + F.plasterMix);
  const rccM3 = (lintel + stairC + slab + columnsC + plinthBeam) * M3;
  const pccM3 = (pccFound + pccFloor + entryC) * M3;
  const cement = cMas + cPl + rccM3 * F.rcc.c + pccM3 * F.pcc.c;
  const sand = sMas + sPl + rccM3 * F.rcc.s + pccM3 * F.pcc.s;
  const agg = rccM3 * F.rcc.a + pccM3 * F.pcc.a;
  const steel = slab * M3 * F.steel.slab + (lintel + plinthBeam) * M3 * F.steel.beam + stairC * M3 * F.steel.stair + columnsC * M3 * F.steel.column;
  const r1 = (v) => Math.round(v * 10) / 10;
  return {
    floors: (floors || []).length, outerLen, partLen, wallLen: outerLen + partLen, wallArea, openArea,
    plaster: plasterA, bricks: Math.round(masM3 * F.brickPerM3), wallBricks: Math.round(wallM3 * F.brickPerM3),
    cementWalls: r1(cWallOnly + cPl), cementBags: Math.round(cement), sandM3: r1(sand), aggM3: r1(agg), steelKg: Math.round(steel),
    // volumes in m3
    masonryM3: r1(masM3), wallM3: r1(wallM3), plasterM2: Math.round(plM2), rccM3: r1(rccM3), pccM3: r1(pccM3),
    slabM3: r1(slab * M3), lintelM3: r1(lintel * M3), stairM3: r1(stairC * M3), plinthBeamM3: r1(plinthBeam * M3), columnM3: r1(columnsC * M3),
    excavM3: r1(excav * M3), plinthFillM3: r1(plinthFill * M3), builtUp, plinth: plinthH,
    doors, windows, stairs, risers, fixtures, mep,
    // legacy fields
    sandCuft: Math.round(sand / M3), concreteCuft: Math.round(rccM3 / M3), stairVol: stairC
  };
}

export function toDxf(floors, opts = {}) {
  let ents = "";
  const layers = new Map();
  const COL = { WALLS: 7, DOORS: 3, WINDOWS: 5, STAIRS: 30, FURNITURE: 8, TEXT: 2, COLUMNS: 1 };
  const n = (v) => (Math.round(v * 10000) / 10000).toString();
  let L = "0", OX = 0;
  const use = (fl, kind) => { L = "NAKSHA_" + fl + "_" + kind; layers.set(L, COL[kind] || 7); };
  const P = (x, y) => [x + OX, -y];
  const line = (x1, y1, x2, y2) => { const a = P(x1, y1), b = P(x2, y2); ents += `0\nLINE\n8\n${L}\n10\n${n(a[0])}\n20\n${n(a[1])}\n30\n0\n11\n${n(b[0])}\n21\n${n(b[1])}\n31\n0\n`; };
  const poly = (pts) => { for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; line(a.x, a.y, b.x, b.y); } };
  const circle = (x, y, r) => { const a = P(x, y); ents += `0\nCIRCLE\n8\n${L}\n10\n${n(a[0])}\n20\n${n(a[1])}\n30\n0\n40\n${n(r)}\n`; };
  const arc = (x, y, r, a0, a1) => { const a = P(x, y); ents += `0\nARC\n8\n${L}\n10\n${n(a[0])}\n20\n${n(a[1])}\n30\n0\n40\n${n(r)}\n50\n${n(a0)}\n51\n${n(a1)}\n`; };
  const text = (x, y, h, s) => { const a = P(x, y); const t = String(s).replace(/[\r\n]/g, " ").replace(/[^\x20-\x7e]/g, "?"); ents += `0\nTEXT\n8\n${L}\n10\n${n(a[0])}\n20\n${n(a[1])}\n30\n0\n40\n${n(h)}\n1\n${t}\n72\n1\n11\n${n(a[0])}\n21\n${n(a[1])}\n31\n0\n`; };
  let offset = 0;
  (floors || []).forEach((f, fi) => {
    const walls = f.walls || [];
    const fl = shortFloorName(f.level ?? fi);
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const w of walls) { minX = Math.min(minX, w.x1, w.x2); minY = Math.min(minY, w.y1, w.y2); maxX = Math.max(maxX, w.x1, w.x2); maxY = Math.max(maxY, w.y1, w.y2); }
    if (!walls.length) { minX = 0; minY = 0; maxX = 10; maxY = 10; }
    OX = offset - minX;
    offset += (maxX - minX) + 20;
    use(fl, "TEXT");
    text((minX + maxX) / 2, minY - 6, 1.4, (f.name || fl) + " (" + fl + ")");
    const byId = {};
    for (const w of walls) byId[w.id] = w;
    const ends = walls.flatMap((w) => [[w.x1, w.y1, w], [w.x2, w.y2, w]]);
    const shared = (x, y, w) => ends.some((e) => e[2] !== w && Math.hypot(e[0] - x, e[1] - y) < 0.1);
    for (const w of walls) {
      const len = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
      if (len < 0.01) continue;
      const ux = (w.x2 - w.x1) / len, uy = (w.y2 - w.y1) / len, nx = -uy, ny = ux, h = (w.thickness || 0.75) / 2;
      const at = (s, o) => [w.x1 + ux * s + nx * o, w.y1 + uy * s + ny * o];
      const ops = [];
      for (const d of (f.doors || []).filter((d) => d.wallId === w.id)) ops.push({ d, door: true, s0: d.t * len - (d.width || 3) / 2, s1: d.t * len + (d.width || 3) / 2 });
      for (const k of (f.windows || []).filter((k) => k.wallId === w.id)) ops.push({ d: k, door: false, s0: k.t * len - (k.width || 4) / 2, s1: k.t * len + (k.width || 4) / 2 });
      ops.sort((a, b) => a.s0 - b.s0);
      use(fl, "WALLS");
      let s = 0;
      const seg = (a, b) => { if (b - a < 0.01) return; for (const o of [-h, h]) { const p = at(a, o), q = at(b, o); line(p[0], p[1], q[0], q[1]); } };
      for (const o of ops) {
        const a = Math.max(0, o.s0), b = Math.min(len, o.s1);
        seg(s, a);
        for (const j of [a, b]) { const p = at(j, -h), q = at(j, h); line(p[0], p[1], q[0], q[1]); }
        s = Math.max(s, b);
      }
      seg(s, len);
      if (!shared(w.x1, w.y1, w)) { const p = at(0, -h), q = at(0, h); line(p[0], p[1], q[0], q[1]); }
      if (!shared(w.x2, w.y2, w)) { const p = at(len, -h), q = at(len, h); line(p[0], p[1], q[0], q[1]); }
      for (const o of ops) {
        const a = Math.max(0, o.s0), b = Math.min(len, o.s1), wd = b - a;
        if (o.door) {
          use(fl, "DOORS");
          const side = o.d.flip ? -1 : 1;
          const hinge = at(a, side * h), tip = [hinge[0] + nx * side * wd, hinge[1] + ny * side * wd];
          line(hinge[0], hinge[1], tip[0], tip[1]);
          // arc from the leaf tip to the closed position (angles in DXF space, y flipped)
          const A = P(...hinge), T1 = P(...tip), T2 = P(...at(b, side * h));
          let a0 = Math.atan2(T1[1] - A[1], T1[0] - A[0]) * 180 / Math.PI, a1 = Math.atan2(T2[1] - A[1], T2[0] - A[0]) * 180 / Math.PI;
          let d = ((a1 - a0) % 360 + 360) % 360;
          if (d > 180) { const tmp = a0; a0 = a1; a1 = tmp; }
          arc(hinge[0], hinge[1], wd, (a0 + 360) % 360, (a1 + 360) % 360);
          use(fl, "TEXT"); const c = at((a + b) / 2, -side * (h + 0.8)); text(c[0], c[1], 0.5, o.d.id);
        } else {
          use(fl, "WINDOWS");
          for (const off of [-h, -h / 3, h / 3, h]) { const p = at(a, off), q = at(b, off); line(p[0], p[1], q[0], q[1]); }
          use(fl, "TEXT"); const c = at((a + b) / 2, h + 0.8); text(c[0], c[1], 0.5, o.d.id);
        }
      }
    }
    use(fl, "COLUMNS");
    for (const c of f.columns || []) poly(rectPoly(c.x, c.y, 0, [-(c.w || 0.75) / 2, -(c.d || 1) / 2, (c.w || 0.75) / 2, (c.d || 1) / 2]));
    use(fl, "STAIRS");
    for (const st of f.stairs || []) {
      const g = stairGeometry(st);
      if (g.type === "spiral") {
        circle(st.x, st.y, g.rad); circle(st.x, st.y, 0.35);
        for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; line(st.x + Math.cos(a) * 0.35, st.y + Math.sin(a) * 0.35, st.x + Math.cos(a) * g.rad, st.y + Math.sin(a) * g.rad); }
      } else for (const r of [...g.treads, ...g.land]) poly(rectPoly(st.x, st.y, st.rot || 0, [r.x0, r.y0, r.x1, r.y1]));
      use(fl, "TEXT"); text(st.x, st.y, 0.6, st.id + " UP " + (st.steps || 0) + "R"); use(fl, "STAIRS");
    }
    for (const fu of f.furniture || []) {
      use(fl, "FURNITURE");
      for (const pg of itemPolys(fu, FURNITURE[fu.kind] || FURNITURE.bed)) poly(pg);
      use(fl, "TEXT"); text(fu.x, fu.y, 0.4, (FURNITURE[fu.kind] || { name: fu.kind }).name);
    }
    use(fl, "TEXT");
    for (const r of f.rooms || []) {
      text(r.cx, r.cy, 0.9, (r.name ? r.name + " " : "") + r.id);
      if (r.area) text(r.cx, r.cy + 1.4, 0.6, Math.round(r.area) + " sq.ft");
    }
  });
  let tbl = `0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLTYPE\n70\n1\n0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0\n0\nENDTAB\n0\nTABLE\n2\nLAYER\n70\n${layers.size + 1}\n0\nLAYER\n2\n0\n70\n0\n62\n7\n6\nCONTINUOUS\n`;
  for (const [name, c] of layers) tbl += `0\nLAYER\n2\n${name}\n70\n0\n62\n${c}\n6\nCONTINUOUS\n`;
  tbl += `0\nENDTAB\n0\nENDSEC\n`;
  return `0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n9\n$INSUNITS\n70\n2\n0\nENDSEC\n${tbl}0\nSECTION\n2\nENTITIES\n${ents}0\nENDSEC\n0\nEOF\n`;
}
