/* Every app action has an id. Voice phrases live in each locale file under `phrases`.
 * Parameterized commands (W1 ko 12 feet, third floor par jao, …) stay in app.js. */
import { allPhrases, normPhrase } from "./i18n/index.js";

export function matchVoiceAction(text) {
  const n = normPhrase(text);
  if (!n) return null;
  const list = allPhrases();
  // exact first, then starts-with / equals ignoring filler words
  for (const p of list) {
    if (p.phrase === n) return p.id;
  }
  for (const p of list) {
    if (n === p.phrase + " karo" || n === p.phrase + " karein" || n === "please " + p.phrase) return p.id;
  }
  // Allow a trailing filler ("karo", "please") but do not prefix-match,
  // so "north 15 degree" is not stolen by the phrase "north".
  const fillers = [" karo", " karein", " kardo", " please", " now"];
  for (const p of list) {
    for (const f of fillers) {
      if (n === p.phrase + f) return p.id;
    }
  }
  return null;
}

export function runAction(id, api) {
  const fn = ACTIONS[id];
  if (!fn) return false;
  fn(api);
  return true;
}

const ACTIONS = {
  show3d: (api) => { api.switchMode("3d"); api.toast("3D"); },
  show2d: (api) => { api.switchMode("2d"); api.toast("2D"); },
  undo: (api) => { api.undo(); api.toast("Undo"); },
  redo: (api) => { api.redo(); api.toast("Redo"); },
  vastuOn: (api) => api.setVastu(true),
  vastuOff: (api) => api.setVastu(false),
  setNorth: (api) => api.openNorthSheet(),
  corners: (api) => api.toggleCorners(),
  wallAng: (api) => api.toggleWallAng(),
  boq: (api) => api.showBoq(),
  dxf: (api) => api.exportDxf(),
  vReport: (api) => api.vastuReportPdf(),
  backup: (api) => api.backupJson(),
  restore: (api) => api.openRestore(),
  roof: (api) => api.toggleRoof(),
  walk: (api) => api.toggleWalk(true),
  walkOff: (api) => api.toggleWalk(false),
  sun: (api) => api.toggleSun(true),
  exportPng: (api) => api.exportPng(),
  pdfA4: (api) => api.exportPdf("a4"),
  pdfA3: (api) => api.exportPdf("a3"),
  addFloor: (api) => api.addFloor(false),
  copyFloor: (api) => api.addFloor(true),
  addBasement: (api) => api.addFloor(false, { basement: true }),
  save: (api) => { api.persist(); api.toast(api.t("saved")); },
  language: (api) => api.openLangPicker(),
  select: (api) => api.setTool("select"),
  outer: (api) => api.setTool("outer"),
  partition: (api) => api.setTool("partition"),
  measure: (api) => api.setTool("measure"),
  door: (api) => api.setTool("door"),
  window: (api) => api.setTool("window"),
  column: (api) => api.setTool("column"),
  stair: (api) => api.setTool("stair"),
  furniture: (api) => api.setTool("furniture"),
  mep: (api) => api.setTool("mep"),
  importDraw: (api) => api.openImport(),
  snapOff: (api) => api.setSnap(0),
  snap15: (api) => api.setSnap(15),
  snap45: (api) => api.setSnap(45),
  snap90: (api) => api.setSnap(90)
};

export { ACTIONS };

/* ---------- command text normaliser (typed + spoken, Hindi / Hinglish / English) ----------
 * - Devanagari digits -> 0-9, common Devanagari words -> Hinglish tokens
 * - number words ("teen", "three", "तीन", "dedh", "saade teen") -> digits when they are
 *   clearly a quantity (before a unit / after "ko", "by", an element word)
 * - "wall 3" / "deewar teen" / "door 1" / "khidki 2" -> w3 / d1 / k2
 * - keeps decimal points ("12.5"), drops sentence punctuation. */
const DEV_DIGIT = { "०": "0", "१": "1", "२": "2", "३": "3", "४": "4", "५": "5", "६": "6", "७": "7", "८": "8", "९": "9" };
const DEV_WORDS = {
  "डब्ल्यू": "w", "डब्लू": "w", "दीवार": "deewar", "दिवार": "deewar", "दरवाजा": "darwaza", "दरवाज़ा": "darwaza",
  "खिडकी": "khidki", "कमरा": "kamra", "कमरे": "kamra", "रूम": "room", "वॉल": "wall", "वाल": "wall", "डोर": "door", "विंडो": "window",
  "को": "ko", "करो": "karo", "करें": "karein", "करिए": "karo", "कीजिए": "karo", "कर": "kar", "दो": "do", "दें": "do",
  "मीटर": "meter", "फीट": "feet", "फुट": "feet", "इंच": "inch", "सेंटीमीटर": "cm", "मिलीमीटर": "mm", "डिग्री": "degree",
  "हटाओ": "hatao", "हटा": "hata", "हटाएं": "hatao", "मिटाओ": "mitao", "डिलीट": "delete", "निकालो": "nikalo",
  "दिखाओ": "dikhao", "दिखाएं": "dikhao", "लगाओ": "lagao", "लगाएं": "lagao", "रखो": "rakho", "बनाओ": "banao", "बनाएं": "banao",
  "जाओ": "jao", "चलो": "chalo", "घुमाओ": "ghumao", "बदलो": "badlo", "चौड़ा": "chauda", "चौडा": "chauda", "लंबा": "lamba", "लम्बा": "lamba",
  "का": "ka", "की": "ki", "के": "ke", "में": "mein", "मे": "me", "पर": "par", "पे": "pe", "से": "se", "और": "aur",
  "रंग": "rang", "कलर": "color", "नाम": "naam", "अंदर": "andar", "अन्दर": "andar", "बाहर": "bahar", "बाय": "by",
  "फ्लोर": "floor", "मंजिल": "manzil", "ग्राउंड": "ground", "बेसमेंट": "basement", "तल": "tala",
  "पहली": "pehli", "पहला": "pehla", "पहले": "pehle", "दूसरी": "dusri", "दूसरा": "dusra", "दूसरे": "dusre",
  "तीसरी": "teesri", "तीसरा": "teesra", "तीसरे": "teesre", "चौथी": "chauthi", "चौथा": "chautha", "पांचवी": "panchvi", "पाँचवी": "panchvi",
  "लाल": "lal", "नीला": "neela", "नीली": "neela", "हरा": "hara", "हरी": "hara", "पीला": "peela", "पीली": "peela",
  "सफेद": "safed", "काला": "kala", "काली": "kala", "भूरा": "bhura", "गुलाबी": "gulabi", "नारंगी": "narangi",
  "क्रीम": "cream", "ग्रे": "grey", "स्लेटी": "slaty",
  "वास्तु": "vastu", "उत्तर": "north", "नॉर्थ": "north",
  "बेड": "bed", "पलंग": "bed", "सोफा": "sofa", "कुर्सी": "chair", "अलमारी": "wardrobe", "डाइनिंग": "dining", "किचन": "kitchen",
  "टॉयलेट": "toilet", "शौचालय": "toilet", "वॉशबेसिन": "basin", "बेसिन": "basin", "लाइट": "light", "बल्ब": "light", "पंखा": "fan",
  "स्विच": "switch", "सॉकेट": "socket", "नाली": "drain", "नल": "tap", "पानी": "water", "शॉवर": "shower", "एसी": "ac",
  "सीढ़ी": "seedhi", "सीढी": "seedhi", "गोल": "gol", "स्पाइरल": "spiral", "कॉलम": "column", "खंभा": "khamba"
};
const NUM_WORDS = {
  zero: 0, ek: 1, one: 1, do: 2, two: 2, teen: 3, three: 3, char: 4, chaar: 4, four: 4, paanch: 5, panch: 5, five: 5,
  chhe: 6, chhah: 6, chah: 6, cheh: 6, six: 6, saat: 7, seven: 7, aath: 8, eight: 8, nau: 9, nine: 9, das: 10, ten: 10,
  gyarah: 11, eleven: 11, barah: 12, baarah: 12, twelve: 12, terah: 13, thirteen: 13, chaudah: 14, fourteen: 14,
  pandrah: 15, fifteen: 15, solah: 16, sixteen: 16, satrah: 17, seventeen: 17, atharah: 18, athara: 18, eighteen: 18,
  unnis: 19, nineteen: 19, bees: 20, twenty: 20, pachchis: 25, pachis: 25, tees: 30, thirty: 30, chalis: 40, forty: 40,
  pachas: 50, fifty: 50, sath: 60, saath: 60, sixty: 60, sattar: 70, assi: 80, nabbe: 90, sau: 100, hundred: 100,
  dedh: 1.5, dhai: 2.5, dhaai: 2.5, half: 0.5, aadha: 0.5,
  "एक": 1, "दो": 2, "तीन": 3, "चार": 4, "पांच": 5, "पाँच": 5, "छह": 6, "छः": 6, "छे": 6, "सात": 7, "आठ": 8, "नौ": 9, "दस": 10,
  "ग्यारह": 11, "बारह": 12, "तेरह": 13, "चौदह": 14, "पंद्रह": 15, "सोलह": 16, "सत्रह": 17, "अठारह": 18, "उन्नीस": 19, "बीस": 20,
  "पच्चीस": 25, "तीस": 30, "चालीस": 40, "पचास": 50, "डेढ़": 1.5, "डेढ": 1.5, "ढाई": 2.5
};
const SAADE = { saade: 0.5, sadhe: 0.5, saadhe: 0.5, "साढ़े": 0.5, "साढे": 0.5, sava: 0.25, savaa: 0.25, "सवा": 0.25, paune: -0.25, "पौने": -0.25 };
const UNIT_WORDS = /^(feet|foot|ft|fit|feets|meter|meters|metre|metres|mtr|m|inch|inches|in|cm|mm|degree|degrees|deg|°|by|x|×)$/;
const ELEM = {
  w: "w", wall: "w", deewar: "w", diwar: "w", dewar: "w", deewaar: "w",
  d: "d", door: "d", darwaza: "d", darwaja: "d", darvaza: "d",
  k: "k", window: "k", khidki: "k", khirki: "k",
  r: "r", room: "r", kamra: "r",
  c: "c", column: "c", khamba: "c",
  s: "s", stair: "s", seedhi: "s", sidhi: "s",
  f: "f", e: "e", p: "p"
};

export function normCmd(raw, keepCase = false) {
  let t = String(raw || "").normalize("NFKC").replace(/\u093C/g, "");
  t = t.replace(/[०-९]/g, (c) => DEV_DIGIT[c]);
  // drop punctuation but keep decimal points between digits
  t = t.replace(/(\d)[.,](\d)/g, "$1\u0001$2").replace(/[।.!?؟,，、;:]/g, " ").replace(/\u0001/g, ".");
  t = t.replace(/(\d)\s*(['’′])\s*/g, "$1 ft ").replace(/(\d)\s*(["”″])/g, "$1 inch");
  t = t.replace(/(\d)(?=(?:ft|feet|foot|m|mtr|meters?|metres?|inch|inches|in|cm|mm|deg|degrees?)\b|[\u0900-\u097F])/gi, "$1 ");
  let toks = t.split(/\s+/).filter(Boolean).map((w) => {
    if (DEV_WORDS[w] != null) return DEV_WORDS[w];
    return keepCase ? w : w.toLowerCase();
  });
  const low = (x) => String(x).toLowerCase();
  const isNumTok = (x) => /^\d+(\.\d+)?$/.test(x);
  // number words -> digits when they are quantities
  for (let i = 0; i < toks.length; i++) {
    const w = low(toks[i]);
    const nextTok = low(toks[i + 1] || "");
    const prev = low(toks[i - 1] || "");
    if (SAADE[w] != null && i + 1 < toks.length) {
      const n2 = NUM_WORDS[nextTok] != null ? NUM_WORDS[nextTok] : (isNumTok(nextTok) ? parseFloat(nextTok) : null);
      if (n2 != null) { toks.splice(i, 2, String(n2 + SAADE[w])); continue; }
    }
    if (NUM_WORDS[w] == null) continue;
    const quantity = UNIT_WORDS.test(nextTok) || ELEM[prev] != null || /^(ko|to|by|x|×|=|floor|manzil|tala|basement|north|uttar|snap)$/.test(prev) ||
      (i === toks.length - 1 && /^(ko|to)$/.test(prev));
    // "do" (= give / 2) and "char" are only numbers before a unit or after ko/by/element
    if (!quantity) continue;
    if ((w === "do" || w === "दो") && !(UNIT_WORDS.test(nextTok) || /^(by|x|×)$/.test(prev) || ELEM[prev] != null)) continue;
    toks[i] = String(NUM_WORDS[w]);
  }
  // "12 point 5" -> 12.5
  for (let i = 1; i < toks.length - 1; i++) {
    if (/^(point|dashamlav)$/.test(low(toks[i])) && isNumTok(toks[i - 1]) && /^\d+$/.test(toks[i + 1])) {
      toks.splice(i - 1, 3, toks[i - 1] + "." + toks[i + 1]); i--;
    }
  }
  // element word + number -> id (wall 3 -> w3)
  for (let i = 0; i < toks.length - 1; i++) {
    const p = ELEM[low(toks[i])];
    if (p && /^\d+$/.test(toks[i + 1])) {
      // "window 2" etc. only as an id when not followed by a unit ("khidki 4 by 4" is a size)
      const after = low(toks[i + 2] || "");
      if (p !== "w" && p.length === 1 && UNIT_WORDS.test(after)) continue;
      toks.splice(i, 2, (keepCase ? p.toUpperCase() : p) + toks[i + 1]);
    }
  }
  return toks.join(" ").trim();
}
