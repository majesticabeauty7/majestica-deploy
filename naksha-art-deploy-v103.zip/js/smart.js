// Smart placement + stair geometry + fixture symbols (Naksha Art)
// Plan units are feet, y grows downward. Items use canvas rotate(+rot) / three.js rotation.y = -rot.

export const D2R = Math.PI / 180;

export function polyContains(poly, x, y) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.y > y) !== (b.y > y) && x < ((b.x - a.x) * (y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
  }
  return inside;
}

// local rect [x0,y0,x1,y1] -> world corners
export function rectPoly(cx, cy, rotDeg, r) {
  const c = Math.cos(rotDeg * D2R), s = Math.sin(rotDeg * D2R);
  return [[r[0], r[1]], [r[2], r[1]], [r[2], r[3]], [r[0], r[3]]].map(([x, y]) => ({ x: cx + x * c - y * s, y: cy + x * s + y * c }));
}

// local footprint rects of a furniture item (L shapes have two)
export function itemRects(f, def) {
  const w = f.w || def?.w || 2, d = f.d || def?.d || 2;
  const rects = [[-w / 2, -d / 2, w / 2, d / 2]];
  if (f.leg && f.leg > d) {
    const s = f.legSide || -1;
    const x0 = s < 0 ? -w / 2 : w / 2 - d;
    rects.push([x0, d / 2 - 0.01, x0 + d, -d / 2 + f.leg]);
  }
  return rects;
}
export function itemPolys(f, def) {
  return itemRects(f, def).map((r) => rectPoly(f.x, f.y, f.rot || 0, r));
}

function proj(poly, ax, ay) {
  let mn = Infinity, mx = -Infinity;
  for (const p of poly) { const v = p.x * ax + p.y * ay; if (v < mn) mn = v; if (v > mx) mx = v; }
  return [mn, mx];
}
export function polysOverlap(A, B, gap = 0) {
  for (const P of [A, B]) {
    for (let i = 0; i < P.length; i++) {
      const a = P[i], b = P[(i + 1) % P.length];
      let ax = -(b.y - a.y), ay = b.x - a.x;
      const L = Math.hypot(ax, ay) || 1; ax /= L; ay /= L;
      const p = proj(A, ax, ay), q = proj(B, ax, ay);
      if (p[1] <= q[0] - gap || q[1] <= p[0] - gap) return false;
    }
  }
  return true;
}

function segDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy || 1;
  let t = ((px - ax) * dx + (py - ay) * dy) / L2;
  t = Math.max(0, Math.min(1, t));
  return { d: Math.hypot(px - ax - t * dx, py - ay - t * dy), t };
}

// thickness of the wall lying along a room edge
function edgeThick(walls, p, q) {
  const mx = (p.x + q.x) / 2, my = (p.y + q.y) / 2;
  let best = null, bd = 0.4;
  for (const w of walls) {
    const r = segDist(mx, my, w.x1, w.y1, w.x2, w.y2);
    if (r.d < bd) { bd = r.d; best = w; }
  }
  return best ? (best.thickness || 0.75) : 0.5;
}

/**
 * Find a spot for an item against a wall of a room.
 * ctx: { room, walls, doors, windows, others: [poly...], wallsById }
 * item: { w, d, h, leg }  opts: { corner, far, longest, center }
 */
export function findWallSpot(ctx, item, opts = {}) {
  const poly = ctx.room.poly;
  if (!poly || poly.length < 3) return null;
  const cx = ctx.room.cx, cy = ctx.room.cy;
  // openings in this room: world center + along-wall unit + half width
  const opens = [];
  for (const o of [...(ctx.doors || []).map((d) => ({ ...d, isDoor: true })), ...(ctx.windows || [])]) {
    const w = ctx.wallsById[o.wallId];
    if (!w) continue;
    const x = w.x1 + (w.x2 - w.x1) * o.t, y = w.y1 + (w.y2 - w.y1) * o.t;
    opens.push({ x, y, hw: (o.width || 3) / 2, isDoor: !!o.isDoor });
  }
  const doorObst = [];
  for (const o of opens.filter((o) => o.isDoor)) {
    // swing zone: square of door width on both sides
    const s = o.hw * 2 + 0.3;
    doorObst.push([{ x: o.x - s, y: o.y - s }, { x: o.x + s, y: o.y - s }, { x: o.x + s, y: o.y + s }, { x: o.x - s, y: o.y + s }].map((p) => p));
  }
  const cands = [];
  const n = poly.length;
  for (let i = 0; i < n; i++) {
    const p = poly[i], q = poly[(i + 1) % n];
    const L = Math.hypot(q.x - p.x, q.y - p.y);
    if (L < 1) continue;
    const ux = (q.x - p.x) / L, uy = (q.y - p.y) / L;
    let nx = -uy, ny = ux;
    const mx = (p.x + q.x) / 2, my = (p.y + q.y) / 2;
    if ((cx - mx) * nx + (cy - my) * ny < 0) { nx = -nx; ny = -ny; }
    const th = edgeThick(ctx.walls, p, q);
    const prevTh = edgeThick(ctx.walls, poly[(i - 1 + n) % n], p), nextTh = edgeThick(ctx.walls, q, poly[(i + 2) % n]);
    const a0 = prevTh / 2 + 0.05, a1 = L - nextTh / 2 - 0.05;
    let w = item.w;
    if (opts.fill) w = Math.max(opts.fill[0], Math.min(opts.fill[1], a1 - a0 - (opts.fillGap || 0)));
    if (a1 - a0 < w) continue;
    const rot = Math.atan2(-nx, ny) / D2R;
    // local x axis in world
    const ex = Math.cos(rot * D2R), ey = Math.sin(rot * D2R);
    const steps = [];
    for (let s = a0 + w / 2; s <= a1 - w / 2 + 1e-6; s += 0.5) steps.push(s);
    steps.push(a0 + w / 2, a1 - w / 2, (a0 + a1) / 2);
    for (const s of steps) {
      if (s < a0 + w / 2 - 1e-6 || s > a1 - w / 2 + 1e-6) continue;
      const off = th / 2 + item.d / 2 + 0.03;
      const x = p.x + ux * s + nx * off, y = p.y + uy * s + ny * off;
      const atStart = Math.abs(s - (a0 + w / 2)) < 0.01, atEnd = Math.abs(s - (a1 - w / 2)) < 0.01;
      let legSide = -1;
      if (item.leg) {
        if (!atStart && !atEnd) continue;
        // which local-x side touches the corner
        const cornerX = atStart ? p.x : q.x, cornerY = atStart ? p.y : q.y;
        legSide = ((cornerX - x) * ex + (cornerY - y) * ey) < 0 ? -1 : 1;
      }
      const f = { x, y, rot, w, d: item.d, leg: item.leg || 0, legSide };
      const polys = itemPolys(f);
      // inside room
      let ok = polys.every((P) => P.every((c) => polyContains(poly, c.x, c.y) || segDistToPoly(poly, c) < th / 2 + 0.06));
      if (!ok) continue;
      if (polys.some((P) => (ctx.others || []).some((O) => polysOverlap(P, O, -0.05)))) continue;
      if (!opts.ignoreDoors && polys.some((P) => doorObst.some((O) => polysOverlap(P, O, 0)))) continue;
      // tall things must not cover windows on this edge
      if ((item.h || 0) > 3.2) {
        let blocked = false;
        for (const o of opens) {
          const r = segDist(o.x, o.y, p.x, p.y, q.x, q.y);
          if (r.d > 0.6) continue;
          const os = r.t * L;
          if (Math.abs(os - s) < o.hw + w / 2) blocked = true;
        }
        if (blocked) continue;
      }
      let score = 0;
      let dd = 99;
      for (const o of opens.filter((o) => o.isDoor)) dd = Math.min(dd, Math.hypot(o.x - x, o.y - y));
      if (opts.far) score += dd * 2;
      else score += Math.min(dd, 8);
      if (opts.corner && (atStart || atEnd)) score += 6;
      if (opts.longest) score += L * 1.5;
      if (opts.center) score -= Math.abs(s - L / 2) * 0.8;
      if (opts.near) score -= Math.hypot(x - opts.near.x, y - opts.near.y) * 4;
      // prefer wall facing room centre less for sofa? keep simple
      cands.push({ ...f, score, edge: i, edgeLen: L, s });
    }
  }
  if (!cands.length) return null;
  cands.sort((a, b) => b.score - a.score);
  return cands[0];
}
function segDistToPoly(poly, c) {
  let m = Infinity;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    m = Math.min(m, segDist(c.x, c.y, a.x, a.y, b.x, b.y).d);
  }
  return m;
}

/* ---------------- stairs ---------------- */
// plan a stair: risers so total rise == f2f exactly
export function stairCalc(f2fFt, riserIn = 6.5, treadIn = 10) {
  const risers = Math.max(2, Math.ceil((f2fFt * 12) / Math.max(4, riserIn) - 1e-6));
  return { risers, riser: f2fFt / risers, tread: treadIn / 12 };
}
export function stairBox(type, R, T, W) {
  if (type === "straight") return { bw: W, bl: Math.max(1, R - 1) * T };
  if (type === "U") { const r1 = Math.ceil(R / 2), r2 = R - r1; return { bw: 2 * W + 0.33, bl: Math.max(r1 - 1, r2 - 1) * T + W }; }
  if (type === "L") { const r1 = Math.ceil(R / 2), r2 = R - r1; return { bw: W + Math.max(0, r2 - 1) * T, bl: Math.max(0, r1 - 1) * T + W }; }
  const rad = Math.max(2.5, W + 0.5);
  return { bw: rad * 2, bl: rad * 2 };
}
// geometry in local coords; origin = box centre (s.v === 2) or legacy start-centre
export function stairGeometry(s) {
  const R = s.steps || 16, h = s.riser || 0.5, T = s.tread || 0.83, W = s.width || 3;
  const type = s.type || "straight";
  const { bw, bl } = stairBox(type, R, T, W);
  const treads = [], land = [];
  let ox = -bw / 2, oy = -bl / 2;
  if (s.v !== 2 && type !== "spiral") { ox = -W / 2; oy = 0; }
  if (type === "straight") {
    for (let k = 0; k < R - 1; k++) treads.push({ x0: ox, y0: oy + k * T, x1: ox + W, y1: oy + (k + 1) * T, top: (k + 1) * h });
  } else if (type === "U") {
    const r1 = Math.ceil(R / 2), r2 = R - r1;
    for (let k = 0; k < r1 - 1; k++) treads.push({ x0: ox, y0: oy + k * T, x1: ox + W, y1: oy + (k + 1) * T, top: (k + 1) * h });
    const ly = oy + bl - W;
    land.push({ x0: ox, y0: ly, x1: ox + bw, y1: ly + W, top: r1 * h });
    for (let j = 0; j < r2 - 1; j++) treads.push({ x0: ox + bw - W, y0: ly - (j + 1) * T, x1: ox + bw, y1: ly - j * T, top: (r1 + 1 + j) * h });
  } else if (type === "L") {
    const r1 = Math.ceil(R / 2), r2 = R - r1;
    for (let k = 0; k < r1 - 1; k++) treads.push({ x0: ox, y0: oy + k * T, x1: ox + W, y1: oy + (k + 1) * T, top: (k + 1) * h });
    const ly = oy + (r1 - 1) * T;
    land.push({ x0: ox, y0: ly, x1: ox + W, y1: ly + W, top: r1 * h });
    for (let j = 0; j < r2 - 1; j++) treads.push({ x0: ox + W + j * T, y0: ly, x1: ox + W + (j + 1) * T, y1: ly + W, top: (r1 + 1 + j) * h });
  }
  return { type, treads, land, bw, bl, ox, oy, R, h, T, W, rad: Math.max(2.5, W + 0.5), cx: ox + bw / 2, cy: oy + bl / 2 };
}

/* ---------------- 2D fixture symbols (local frame, back edge at -d/2) ---------------- */
export function drawFixture2d(ctx, f, def, sel) {
  const w = f.w || def.w, d = f.d || def.d, k = f.kind;
  const line = (x1, y1, x2, y2) => { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };
  const rr = (x, y, ww, hh, r) => { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, ww, hh, r); else ctx.rect(x, y, ww, hh); };
  ctx.lineWidth = sel ? 0.1 : 0.045;
  ctx.strokeStyle = sel ? "#e8a54b" : "rgba(20,20,20,0.6)";
  const body = (x0, y0, x1, y1, fill) => { ctx.fillStyle = fill; ctx.beginPath(); ctx.rect(x0, y0, x1 - x0, y1 - y0); ctx.fill(); ctx.stroke(); };
  const base = def.color + "cc";
  const rects = itemRects(f, def);
  if (k === "kitchen" || k === "kitchenL") {
    for (const r of rects) {
      body(r[0], r[1], r[2], r[3], "#d9cdb8");
      ctx.save(); ctx.setLineDash([0.25, 0.18]);
      const horiz = r[2] - r[0] >= r[3] - r[1];
      if (horiz) for (let x = r[0] + 1.5; x < r[2] - 0.3; x += 1.5) line(x, r[1] + 0.15, x, r[3] - 0.15);
      else for (let y = r[1] + 1.5; y < r[3] - 0.3; y += 1.5) line(r[0] + 0.15, y, r[2] - 0.15, y);
      ctx.restore();
    }
    line(-w / 2, d / 2 - 0.12, w / 2, d / 2 - 0.12);
    return;
  }
  if (k === "sofa" || k === "sofaL") {
    for (const r of rects) body(r[0], r[1], r[2], r[3], base);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(-w / 2, -d / 2, w, 0.7);
    if (k === "sofa") { ctx.fillRect(-w / 2, -d / 2, 0.5, d); ctx.fillRect(w / 2 - 0.5, -d / 2, 0.5, d); }
    else if (rects[1]) { const r = rects[1]; const s = f.legSide || -1; ctx.fillRect(s < 0 ? r[0] : r[2] - 0.7, r[1], 0.7, r[3] - r[1]); }
    return;
  }
  for (const r of rects) body(r[0], r[1], r[2], r[3], k === "shower" ? "rgba(150,195,220,0.55)" : base);
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  if (k === "wardrobe") {
    const n = Math.max(2, Math.round(w / 1.5));
    for (let i = 1; i < n; i++) line(-w / 2 + (i * w) / n, -d / 2, -w / 2 + (i * w) / n, d / 2);
    line(-w / 2, d / 2 - 0.15, w / 2, d / 2 - 0.15);
    for (let i = 0; i < n; i++) { const x = -w / 2 + ((i + 0.5) * w) / n; line(x - 0.12, d / 2 - 0.35, x + 0.12, d / 2 - 0.35); }
  } else if (k === "bathtub") {
    rr(-w / 2 + 0.3, -d / 2 + 0.3, w - 0.6, d - 0.6, 0.6); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(-w / 2 + 0.8, 0, 0.12, 0, 7); ctx.stroke();
  } else if (k === "shower") {
    line(-w / 2, -d / 2, w / 2, d / 2); line(w / 2, -d / 2, -w / 2, d / 2);
    ctx.beginPath(); ctx.arc(0, 0, 0.2, 0, 7); ctx.fill(); ctx.stroke();
  } else if (k === "wc") {
    ctx.fillRect(-w / 2 + 0.1, -d / 2, w - 0.2, 0.6); ctx.strokeRect(-w / 2 + 0.1, -d / 2, w - 0.2, 0.6);
    ctx.beginPath(); ctx.ellipse(0, 0.35, w / 2 - 0.15, (d - 0.6) / 2 - 0.05, 0, 0, 7); ctx.fill(); ctx.stroke();
  } else if (k === "basin" || k === "sink") {
    ctx.beginPath(); ctx.ellipse(0, 0.1, w / 2 - 0.25, d / 2 - 0.3, 0, 0, 7); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0.1, 0.08, 0, 7); ctx.stroke();
    line(0, -d / 2 + 0.05, 0, -d / 2 + 0.3);
  } else if (k === "hob") {
    ctx.strokeStyle = "rgba(255,255,255,0.8)";
    for (const sx of [-w / 4, w / 4]) { ctx.beginPath(); ctx.arc(sx, 0, Math.min(0.35, d / 3), 0, 7); ctx.stroke(); }
  } else if (k === "geyser") {
    ctx.beginPath(); ctx.arc(0, 0, Math.min(w, d) / 2 - 0.05, 0, 7); ctx.fill(); ctx.stroke();
  } else if (k === "bed") {
    ctx.fillRect(-w / 2 + 0.3, -d / 2 + 0.2, w / 2 - 0.45, 1.1); ctx.fillRect(0.15, -d / 2 + 0.2, w / 2 - 0.45, 1.1);
    line(-w / 2, -d / 2 + 1.6, w / 2, -d / 2 + 1.6);
  }
}
