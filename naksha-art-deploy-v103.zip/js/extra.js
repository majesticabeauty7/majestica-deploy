/* Room detection, vastu check, colour names — used by app.js */

export function polyArea(pts) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    a += pts[i].x * pts[j].y - pts[j].x * pts[i].y;
  }
  return a / 2;
}

export function polyCentroid(pts) {
  let a = 0, cx = 0, cy = 0;
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    const c = pts[i].x * pts[j].y - pts[j].x * pts[i].y;
    a += c;
    cx += (pts[i].x + pts[j].x) * c;
    cy += (pts[i].y + pts[j].y) * c;
  }
  a *= 0.5;
  if (Math.abs(a) < 1e-9) {
    const sx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
    const sy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
    return { x: sx, y: sy };
  }
  return { x: cx / (6 * a), y: cy / (6 * a) };
}

export function pointInPoly(x, y, pts) {
  let inr = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
    const hit = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-12) + xi;
    if (hit) inr = !inr;
  }
  return inr;
}

function nearlyOnSeg(px, py, x1, y1, x2, y2, tol = 0.2) {
  const dx = x2 - x1, dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  if (l2 < 1e-8) return Math.hypot(px - x1, py - y1) < tol;
  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  if (t < -0.02 || t > 1.02) return false;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy)) < tol;
}

function splitWalls(walls) {
  const pts = [];
  const add = (x, y) => {
    for (const p of pts) if (Math.hypot(p.x - x, p.y - y) < 0.18) return p;
    const p = { x, y };
    pts.push(p);
    return p;
  };
  for (const w of walls) {
    add(w.x1, w.y1);
    add(w.x2, w.y2);
  }
  const segs = [];
  for (const w of walls) {
    const on = [];
    for (const p of pts) {
      if (nearlyOnSeg(p.x, p.y, w.x1, w.y1, w.x2, w.y2, 0.18)) on.push(p);
    }
    const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
    const l2 = dx * dx + dy * dy || 1;
    on.sort((a, b) => ((a.x - w.x1) * dx + (a.y - w.y1) * dy) / l2 - ((b.x - w.x1) * dx + (b.y - w.y1) * dy) / l2);
    for (let i = 0; i < on.length - 1; i++) {
      const a = on[i], b = on[i + 1];
      if (Math.hypot(b.x - a.x, b.y - a.y) > 0.25) segs.push({ a, b, wall: w });
    }
  }
  return { pts, segs };
}

export function detectRooms(walls, prev = []) {
  if (!walls || walls.length < 3) return [];
  const { pts, segs } = splitWalls(walls);
  if (segs.length < 3) return [];

  const idx = new Map(pts.map((p, i) => [p, i]));
  const adj = pts.map(() => []);
  for (const e of segs) {
    const i = idx.get(e.a), j = idx.get(e.b);
    if (i == null || j == null || i === j) continue;
    const angIJ = Math.atan2(e.b.y - e.a.y, e.b.x - e.a.x);
    const angJI = Math.atan2(e.a.y - e.b.y, e.a.x - e.b.x);
    adj[i].push({ to: j, ang: angIJ });
    adj[j].push({ to: i, ang: angJI });
  }
  for (const list of adj) list.sort((a, b) => a.ang - b.ang);

  const used = new Set();
  const faces = [];
  for (let i = 0; i < pts.length; i++) {
    for (const o of adj[i]) {
      const start = i + ">" + o.to;
      if (used.has(start)) continue;
      const poly = [];
      let cur = i, nxt = o.to, guard = 0;
      while (guard++ < 500) {
        const k = cur + ">" + nxt;
        if (used.has(k)) break;
        used.add(k);
        poly.push({ x: pts[cur].x, y: pts[cur].y });
        const outs = adj[nxt];
        const back = outs.findIndex((x) => x.to === cur);
        if (back < 0) break;
        const nx = outs[(back - 1 + outs.length) % outs.length];
        cur = nxt;
        nxt = nx.to;
        if (cur === i && nxt === o.to) break;
      }
      if (poly.length >= 3) faces.push(poly);
    }
  }

  const scored = faces
    .map((p) => ({ p, a: polyArea(p) }))
    .filter((f) => Math.abs(f.a) > 2);
  if (scored.length < 2) {
    // a single closed loop is still a room (no outer leftover)
    if (scored.length === 1 && Math.abs(scored[0].a) > 4) {
      /* keep it */
    } else return [];
  }
  scored.sort((x, y) => Math.abs(y.a) - Math.abs(x.a));
  // drop the outer face when there is more than one
  const inner = scored.length > 1 ? scored.slice(1) : scored;

  // reading order (front/top first, then left to right) so new room numbers are predictable
  const cen = (f) => f._c || (f._c = polyCentroid(f.p));
  inner.sort((x, y) => (Math.round(cen(x).y / 3) - Math.round(cen(y).y / 3)) || (cen(x).x - cen(y).x));
  const rooms = inner.map((f, i) => {
    const area = Math.abs(f.a);
    const c = polyCentroid(f.p);
    return {
      id: "R" + (i + 1),
      name: "",
      poly: f.p,
      area,
      cx: c.x,
      cy: c.y,
      floorColor: "#d9d1c3"
    };
  });

  // preserve names / colours / ids by nearest previous centroid
  const taken = new Set();
  for (const r of rooms) {
    let best = null, bd = 4;
    for (const p of prev) {
      if (taken.has(p.id)) continue;
      const d = Math.hypot((p.cx ?? 0) - r.cx, (p.cy ?? 0) - r.cy);
      if (d < bd) { bd = d; best = p; }
    }
    r.id = null;
    if (best) {
      taken.add(best.id);
      r.id = best.id;
      r.name = best.name || "";
      r.floorColor = best.floorColor || r.floorColor;
    }
  }
  // unique ids
  const usedIds = new Set(rooms.filter((r) => r.id).map((r) => r.id));
  let n = 1;
  for (const r of rooms) {
    if (r.id) continue; // kept from before (ids the user already speaks)
    while (usedIds.has("R" + n)) n++;
    r.id = "R" + n;
    usedIds.add(r.id);
  }
  return rooms;
}

const VASTU_ZONES = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];

export function zoneAt(x, y, cx, cy, northDeg) {
  // 0 = north (up, -Y). Clockwise. Sector i centered on heading i*22.5
  let ang = Math.atan2(x - cx, -(y - cy)); // 0 at north, clockwise positive? atan2(E, N)
  // atan2(dx, -dy): up (-Y) => 0, right (+X) => +pi/2 if we used atan2(x-cx, cy-y)...
  // y-down: north is -Y direction. Vector from center: (x-cx, y-cy). North is (0,-1).
  // heading clockwise from north:
  let h = Math.atan2(x - cx, cy - y); // 0 when y < cy (up), +pi/2 when x > cx (east). Good.
  h = h - (northDeg * Math.PI) / 180;
  while (h < 0) h += Math.PI * 2;
  while (h >= Math.PI * 2) h -= Math.PI * 2;
  // sector 0 (V1 N) is -11.25 .. +11.25
  const i = Math.floor(((h + Math.PI / 16) % (Math.PI * 2)) / (Math.PI / 8)) % 16;
  return { i, id: "V" + (i + 1), dir: VASTU_ZONES[i] };
}

const RULES = {
  kitchen: { good: ["SE","ESE","SSE"], ok: ["E","S","SW"], kind: ["kitchen","rasoi","cook"] },
  toilet: { good: ["NW","WNW","NNW","W"], ok: ["S","SE","WSW"], kind: ["toilet","bathroom","washroom","wc","shauchalaya"] },
  bedroom: { good: ["SW","WSW","SSW","W","S"], ok: ["NW","SE","E","WNW"], kind: ["bedroom","bed","master","shayan"] },
  pooja: { good: ["NE","NNE","ENE","E","N"], ok: ["NW","SE"], kind: ["pooja","puja","mandir","temple","prayer"] }
};

export function classifyRoomName(name) {
  const n = (name || "").toLowerCase().trim();
  if (!n) return null;
  for (const [k, r] of Object.entries(RULES)) {
    if (r.kind.some((w) => n.includes(w))) return k;
  }
  return null;
}

export function vastuForRoom(room, cx, cy, northDeg, lang = "hi") {
  const kind = classifyRoomName(room.name);
  if (!kind) return null;
  const z = zoneAt(room.cx, room.cy, cx, cy, northDeg);
  const rule = RULES[kind];
  let grade = "bad";
  if (rule.good.includes(z.dir)) grade = "good";
  else if (rule.ok.includes(z.dir)) grade = "ok";
  const hi = {
    kitchen: "Kitchen",
    toilet: "Toilet",
    bedroom: "Bedroom",
    pooja: "Pooja",
    good: (k, d) => `${k} ${d} mein sahi hai.`,
    ok: (k, d) => `${k} ${d} mein theek hai, behtar zone ho sakta hai.`,
    bad: {
      kitchen: (d) => `Kitchen ${d} mein Vastu ke anusar sahi nahi. SE (V7) shift karein.`,
      toilet: (d) => `Toilet ${d} mein Vastu ke anusar sahi nahi. NW ki taraf shift karein.`,
      bedroom: (d) => `Bedroom ${d} mein utna shubh nahi. SW (master) behtar hai.`,
      pooja: (d) => `Pooja ${d} mein Vastu ke anusar sahi nahi. NE (V3) rakhein.`
    }
  };
  const en = {
    kitchen: "Kitchen",
    toilet: "Toilet",
    bedroom: "Bedroom",
    pooja: "Pooja",
    good: (k, d) => `${k} in ${d} is well placed.`,
    ok: (k, d) => `${k} in ${d} is acceptable; a better zone is possible.`,
    bad: {
      kitchen: (d) => `Kitchen in ${d} is not ideal. Shift it to SE (V7).`,
      toilet: (d) => `Toilet in ${d} is not ideal. Shift it toward NW.`,
      bedroom: (d) => `Bedroom in ${d} is less auspicious. SW is better for a master bedroom.`,
      pooja: (d) => `Pooja in ${d} is not ideal. Place it in NE (V3).`
    }
  };
  const L = lang === "en" ? en : hi;
  let text;
  if (grade === "good") text = L.good(L[kind], z.dir);
  else if (grade === "ok") text = L.ok(L[kind], z.dir);
  else text = L.bad[kind](z.dir);
  const color = grade === "good" ? "#7d9a6a" : grade === "ok" ? "#c9a227" : "#d2605a";
  return { kind, grade, color, text, zone: z.id, dir: z.dir };
}

export const COLOR_NAMES = {
  grey: "#7a7f86", gray: "#7a7f86", slaty: "#7a7f86", slati: "#7a7f86",
  cream: "#f3ead7", white: "#f0ece4", safed: "#f0ece4",
  black: "#1a1a1a", kala: "#1a1a1a",
  red: "#8b2e2e", lal: "#8b2e2e",
  blue: "#2c4a6e", neela: "#2c4a6e",
  green: "#3d5a3a", hara: "#3d5a3a",
  yellow: "#c9a227", peela: "#c9a227",
  brown: "#6b4a2b", bhura: "#6b4a2b",
  orange: "#c4783a", pink: "#c98aa0",
  beige: "#d9d1c3", ivory: "#efe6d4",
  // Hinglish spellings speech engines produce
  laal: "#8b2e2e", lal: "#8b2e2e", neela: "#2c4a6e", nila: "#2c4a6e", neeli: "#2c4a6e", hari: "#3d5a3a", peeli: "#c9a227",
  kaala: "#1a1a1a", kali: "#1a1a1a", safaid: "#f0ece4", bhoora: "#6b4a2b", gulabi: "#c98aa0",
  narangi: "#c4783a", santri: "#c4783a", aasmani: "#7aa7c9", asmani: "#7aa7c9", sky: "#7aa7c9", maroon: "#6a1f2a",
  silver: "#b8bcc2", golden: "#c9a227", purple: "#6a4a8a", baingani: "#6a4a8a", jamuni: "#6a4a8a"
};

export function parseColorName(s) {
  const t = (s || "").toLowerCase().trim().replace(/\s+(rang|color|colour)$/, "");
  if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(t)) return t;
  return Object.prototype.hasOwnProperty.call(COLOR_NAMES, t) ? COLOR_NAMES[t] : null;
}

export function leftIsInside(wall, rooms) {
  const dx = wall.x2 - wall.x1, dy = wall.y2 - wall.y1;
  const len = Math.hypot(dx, dy) || 1;
  const mx = (wall.x1 + wall.x2) / 2, my = (wall.y1 + wall.y2) / 2;
  const lx = mx + (-dy / len) * 0.4, ly = my + (dx / len) * 0.4;
  return rooms.some((r) => pointInPoly(lx, ly, r.poly));
}
