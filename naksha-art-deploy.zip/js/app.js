import { View3D } from "./view3d.js";
import {
  detectRooms, pointInPoly, polyCentroid, classifyRoomName, vastuForRoom,
  parseColorName, leftIsInside, zoneAt
} from "./extra.js";
import {
  FURNITURE, MEP, TEMPLATES, boqFor, toDxf,
  parseFloorLevel, defaultFloorName, shortFloorName
} from "./more.js";
import {
  initI18n, t, setCurrent, listLocales, currentLocale,
  applyDocumentLocale, speechLang
} from "./i18n/index.js";
import { matchVoiceAction, runAction } from "./commands.js";
import { importDrawing, fileKind } from "./importPlan.js";

const DEMO_HASH = "ac6b8c1d804466625f4e01fc75c6abc47fb55cdceff5218571404a445e04ecbe";
const PX = 24; // pixels per foot at zoom=1
const SNAP_END_PX = 16;
const MIN_WALL = 0.4;



const SIZE = {
  small: { extent: 40, snap: 0.5 },
  medium: { extent: 80, snap: 0.5 },
  large: { extent: 160, snap: 1 }
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  user: null,
  lang: localStorage.getItem("naksha_lang") || "hi",
  project: null,
  tool: "select",
  walls: [],
  doors: [],
  windows: [],
  stairs: [],
  columns: [],
  rooms: [],
  furniture: [],
  mep: [],
  floors: [],
  floorIndex: 0,
  settings: null,
  selection: null,
  view: { zoom: 1, panX: 40, panY: 80 },
  mode: "2d",
  vastuOn: false,
  northDeg: 0,
  angleSnap: 45,
  showCornerAngles: true,
  showWallAngles: true,
  plot: { w: 30, d: 50, front: 5, back: 3, left: 3, right: 3 },
  roofOn: false,
  sunHour: 10,
  sunOn: false,
  speakOn: false,
  furnKind: "bed",
  mepKind: "light",
  undo: [],
  redo: [],
  drawing: null,
  measureStart: null,
  measureRel: false,
  pointers: new Map()
};

let view3d = null;
let dirty = false;

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}


function applyI18n() {
  applyDocumentLocale(currentLocale());
  $$("[data-i]").forEach((el) => {
    el.textContent = t(el.getAttribute("data-i"));
  });
  $$("[data-i-ph]").forEach((el) => {
    el.setAttribute("placeholder", t(el.getAttribute("data-i-ph")));
  });
  const loc = currentLocale();
  const lab = t("language") + (loc ? " \u00b7 " + loc.name : "");
  ["lang-btn", "lang-btn-2", "m-lang"].forEach((id) => {
    const b = document.getElementById(id);
    if (b) b.textContent = lab;
  });
  const mv = $("#m-vastu");
  if (mv) mv.textContent = state.vastuOn ? t("vastuOff") : t("vastuOn");
}

function setLang(lang) {
  const pack = setCurrent(lang);
  state.lang = pack && pack.code ? pack.code : lang;
  localStorage.setItem("naksha_lang", state.lang);
  applyI18n();
  if (state.project) draw2d();
}

function openLangPicker() {
  const rows = listLocales().map((l) => {
    const rtl = l.dir === "rtl" ? " \u00b7 RTL" : "";
    return "<button type=\"button\" class=\"lang-opt " + (l.code === state.lang ? "on" : "") +
      "\" data-code=\"" + escapeHtml(l.code) + "\" dir=\"" + (l.dir || "ltr") + "\">" +
      "<b>" + escapeHtml(l.name) + "</b><span>" + escapeHtml(l.englishName) +
      " \u00b7 " + escapeHtml(l.code) + rtl + "</span></button>";
  }).join("");
  $("#sheet").innerHTML = "<h3>" + t("chooseLang") + "</h3><div class=\"lang-list\">" +
    rows + "</div><p class=\"hint\">" + t("langAdded") + "</p>";
  openSheet();
  $$(".lang-opt").forEach((b) => b.addEventListener("click", () => {
    setLang(b.dataset.code);
    closeSheet();
  }));
}

function setVastu(on) {
  state.vastuOn = !!on;
  applyI18n();
  draw2d();
  persist();
  toast(t(state.vastuOn ? "vastuOn" : "vastuOff"));
}

function speak(text) {
  if (!state.speakOn || !window.speechSynthesis) return;
  try {
    const u = new SpeechSynthesisUtterance(String(text));
    u.lang = speechLang();
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  } catch {}
}

function commandApi() {
  return {
    t, toast, persist, setTool, switchMode, undo, redo, setVastu,
    openNorthSheet, showBoq, exportDxf, vastuReportPdf, backupJson,
    exportPng, exportPdf, addFloor, setSnap, toggleWalk, toggleSun,
    openLangPicker, openImport,
    openRestore: () => $("#restore-file") && $("#restore-file").click(),
    toggleCorners: () => { state.showCornerAngles = !state.showCornerAngles; persist(); draw2d(); toast(t("corners") + (state.showCornerAngles ? " on" : " off")); },
    toggleWallAng: () => { state.showWallAngles = !state.showWallAngles; persist(); draw2d(); toast(t("wallAng") + (state.showWallAngles ? " on" : " off")); },
    toggleRoof: () => { state.roofOn = !state.roofOn; persist(); if (state.mode === "3d") refresh3d(); else switchMode("3d"); toast(t("roof") + (state.roofOn ? " on" : " off")); }
  };
}

function openImport() {
  const el = $("#import-file");
  if (el) el.click();
}

async function onImportFile(file) {
  if (!file) return;
  const kind = fileKind(file.name, file.type);
  if (kind === "dwg") {
    $("#sheet").innerHTML = "<h3>" + t("importDraw") + "</h3><p>" + t("dwgNeed") + "</p>";
    openSheet();
    return;
  }
  toast(t("importWorking"), 2500);
  try {
    const res = await importDrawing(file);
    if (res.error === "dwg") {
      $("#sheet").innerHTML = "<h3>" + t("importDraw") + "</h3><p>" + t("dwgNeed") + "</p>";
      openSheet();
      return;
    }
    if (!res.walls || !res.walls.length) { toast(t("importNone"), 2800); return; }
    applyImported(res);
  } catch (err) {
    console.warn(err);
    toast(t("importNone"), 2800);
  }
}

function applyImported(res) {
  pushUndo();
  state.walls.splice(0, state.walls.length);
  state.doors.splice(0, state.doors.length);
  state.windows.splice(0, state.windows.length);
  const p = wallProps("outer");
  res.walls.forEach((s) => {
    const w = {
      id: nextId("W", state.walls),
      type: "outer",
      x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2,
      thickness: p.thickness, color: p.color, colorIn: p.color, colorOut: p.color,
      height: state.settings.floorHeight
    };
    state.walls.push(w);
  });
  refreshRooms();
  persist();
  closeSheet();
  requestAnimationFrame(() => { fitView(); draw2d(); });
  openImportReview(res);
}

function openImportReview(res) {
  const u = unitLabel();
  const rows = state.walls.map((w) => {
    const len = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
    return "<tr><td>" + w.id + "</td><td>" + fmtLen(len) + "</td><td>" +
      Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2)) + "&deg;</td></tr>";
  }).join("");
  const scaleNote = res && res.scaled ? "<p class=\"hint\">" + t("importScale") + "</p>" : "";
  $("#sheet").innerHTML = "<h3>" + t("importReview") + " (" + state.walls.length + ")</h3>" +
    scaleNote + "<p class=\"hint\">" + t("importNote") + "</p>" +
    "<table class=\"import-list\"><thead><tr><th>ID</th><th>" + t("length") +
    "</th><th>" + t("angle") + "</th></tr></thead><tbody>" + rows + "</tbody></table>" +
    "<div class=\"row\" style=\"margin-top:10px\">" +
    "<button class=\"btn small\" id=\"imp-ok\">" + t("importAccept") + "</button>" +
    "<button class=\"btn danger small\" id=\"imp-cancel\">" + t("importCancel") + "</button></div>";
  openSheet();
  $("#imp-ok").onclick = () => { closeSheet(); toast(t("importOk")); };
  $("#imp-cancel").onclick = () => { undo(); closeSheet(); };
}


function showScreen(id) {
  $$(".screen").forEach((s) => s.classList.toggle("hidden", s.id !== id));
}

function toast(msg, ms = 1800) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), ms);
  speak(msg);
}

function storeKey() {
  return "naksha_projects_" + state.user;
}
function loadProjects() {
  try {
    return JSON.parse(localStorage.getItem(storeKey()) || "[]");
  } catch {
    return [];
  }
}
function saveProjects(list) {
  localStorage.setItem(storeKey(), JSON.stringify(list));
}

function emptyFloor(name = "Ground", level = 0) {
  return {
    id: "F" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
    name,
    level,
    walls: [],
    doors: [],
    windows: [],
    stairs: [],
    columns: [],
    rooms: [],
    furniture: [],
    mep: []
  };
}
function normalizeFloor(f, fallbackName = "Ground", fallbackLevel = 0) {
  const level = f.level != null ? f.level : fallbackLevel;
  return {
    id: f.id || emptyFloor().id,
    name: f.name || fallbackName || defaultFloorName(level),
    level,
    walls: f.walls || [],
    doors: f.doors || [],
    windows: f.windows || [],
    stairs: f.stairs || [],
    columns: f.columns || [],
    rooms: f.rooms || [],
    furniture: f.furniture || [],
    mep: f.mep || []
  };
}
function attachFloor(i) {
  const f = state.floors[i];
  if (!f) return;
  state.floorIndex = i;
  state.walls = f.walls;
  state.doors = f.doors;
  state.windows = f.windows;
  state.stairs = f.stairs;
  state.columns = f.columns;
  state.rooms = f.rooms;
  state.furniture = f.furniture;
  state.mep = f.mep;
  renderFloorBar();
}
function loadData(d) {
  if (d && d.floors && d.floors.length) {
    state.floors = d.floors.map((f, i) => {
      const level = f.level != null ? f.level : i;
      return normalizeFloor(f, f.name || defaultFloorName(level), level);
    });
    sortFloorsKeep(d.floorIndex);
    attachFloor(Math.max(0, Math.min(state.floorIndex, state.floors.length - 1)));
  } else {
    const f = normalizeFloor({ name: "Ground", level: 0, ...(d || {}) }, "Ground", 0);
    f.level = 0;
    state.floors = [f];
    attachFloor(0);
  }
  if (d && d.northDeg != null) state.northDeg = d.northDeg;
  if (d && d.vastuOn != null) state.vastuOn = d.vastuOn;
  if (d && d.plot) state.plot = { ...state.plot, ...d.plot };
  if (d && d.angleSnap != null) state.angleSnap = d.angleSnap;
  if (d && d.showCornerAngles != null) state.showCornerAngles = d.showCornerAngles;
  if (d && d.showWallAngles != null) state.showWallAngles = d.showWallAngles;
  if (d && d.roofOn != null) state.roofOn = d.roofOn;
  if (d && d.sunHour != null) state.sunHour = d.sunHour;
}
function snapshot() {
  return {
    floors: structuredClone(state.floors),
    floorIndex: state.floorIndex,
    northDeg: state.northDeg,
    vastuOn: state.vastuOn,
    plot: structuredClone(state.plot),
    angleSnap: state.angleSnap,
    showCornerAngles: state.showCornerAngles,
    showWallAngles: state.showWallAngles,
    roofOn: state.roofOn,
    sunHour: state.sunHour
  };
}
function restore(s) {
  loadData(s);
  state.selection = null;
  closeSheet();
  refreshRooms();
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function refreshRooms() {
  state.rooms.splice(0, state.rooms.length, ...detectRooms(state.walls, state.rooms.slice()));
}
function planCentre() {
  if (state.walls.length) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const w of state.walls) {
      minX = Math.min(minX, w.x1, w.x2);
      minY = Math.min(minY, w.y1, w.y2);
      maxX = Math.max(maxX, w.x1, w.x2);
      maxY = Math.max(maxY, w.y1, w.y2);
    }
    return { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };
  }
  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  return { x: ext / 2, y: ext / 2 };
}
function fmtArea(sqft) {
  if (state.settings?.units === "m") return (sqft * 0.092903).toFixed(2) + " m²";
  return Math.round(sqft) + " sq.ft";
}
function floorName(i) {
  const f = state.floors[i];
  if (!f) return "";
  return f.name || defaultFloorName(f.level ?? i);
}
function sortFloorsKeep(preferIndex) {
  const cur = preferIndex != null && state.floors[preferIndex]
    ? state.floors[preferIndex]
    : state.floors[state.floorIndex];
  state.floors.sort((a, b) => (a.level ?? 0) - (b.level ?? 0));
  const i = cur ? state.floors.indexOf(cur) : 0;
  state.floorIndex = i >= 0 ? i : 0;
}
function nextFreeLevel(basement) {
  const levels = state.floors.map((f) => f.level ?? 0);
  if (basement) {
    let lv = Math.min(0, ...levels) - 1;
    while (levels.includes(lv)) lv--;
    return lv;
  }
  let lv = Math.max(0, ...levels) + 1;
  while (levels.includes(lv)) lv++;
  return lv;
}
function renderFloorBar() {
  const bar = $("#floor-bar");
  if (!bar) return;
  const chips = state.floors.map((f, i) => {
    const lab = shortFloorName(f.level ?? 0);
    return `<button type="button" data-fi="${i}" class="${i === state.floorIndex ? "on" : ""}" title="${escapeHtml(f.name || defaultFloorName(f.level ?? 0))}">${escapeHtml(lab)}</button>`;
  }).join("");
  bar.innerHTML = chips +
    `<button type="button" id="fb-add" title="${t("addFloor")}">+</button>` +
    `<button type="button" id="fb-base" title="${t("addBasement")}">+B</button>` +
    `<button type="button" id="fb-copy" title="${t("copyFloor")}">⧉</button>`;
  bar.querySelectorAll("[data-fi]").forEach((b) =>
    b.addEventListener("click", () => switchFloor(parseInt(b.dataset.fi, 10)))
  );
  const a = $("#fb-add"); if (a) a.onclick = () => addFloor(false);
  const bb = $("#fb-base"); if (bb) bb.onclick = () => addFloor(false, { basement: true });
  const c = $("#fb-copy"); if (c) c.onclick = () => addFloor(true);
  const on = bar.querySelector("button.on");
  if (on) on.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" });
}
function switchFloor(i) {
  if (i === state.floorIndex || !state.floors[i]) return;
  persist();
  attachFloor(i);
  state.selection = null;
  closeSheet();
  refreshRooms();
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function switchFloorByLevel(level) {
  const i = state.floors.findIndex((f) => f.level === level);
  if (i < 0) return false;
  switchFloor(i);
  return true;
}
function addFloor(copy, opts = {}) {
  pushUndo();
  let level = opts.level;
  if (level == null) level = nextFreeLevel(!!opts.basement);
  else {
    while (state.floors.some((f) => f.level === level)) {
      level += opts.basement || level < 0 ? -1 : 1;
    }
  }
  const name = defaultFloorName(level);
  const src = copy ? structuredClone(state.floors[state.floorIndex]) : null;
  const freshId = emptyFloor().id;
  const f = src
    ? normalizeFloor({ ...src, id: freshId, name, level }, name, level)
    : emptyFloor(name, level);
  f.id = freshId;
  f.name = name;
  f.level = level;
  state.floors.push(f);
  sortFloorsKeep(state.floors.indexOf(f));
  attachFloor(state.floors.indexOf(f));
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  toast(f.name);
}

function pushUndo() {
  state.undo.push(snapshot());
  if (state.undo.length > 60) state.undo.shift();
  state.redo = [];
  dirty = true;
}

function undo() {
  if (!state.undo.length) return;
  state.redo.push(snapshot());
  restore(state.undo.pop());
  persist();
}
function redo() {
  if (!state.redo.length) return;
  state.undo.push(snapshot());
  restore(state.redo.pop());
  persist();
}

function persist() {
  if (!state.user || !state.project) return;
  const rec = {
    ...state.project,
    settings: state.settings,
    data: snapshot(),
    updated: Date.now()
  };
  state.project = rec;
  const all = loadProjects();
  const i = all.findIndex((p) => p.id === rec.id);
  if (i >= 0) all[i] = rec;
  else all.unshift(rec);
  saveProjects(all);
  dirty = false;
}

function nextId(prefix, list) {
  const nums = list.map((o) => parseInt(String(o.id).replace(/^[A-Z]/i, ""), 10)).filter((n) => !isNaN(n));
  return prefix + ((nums.length ? Math.max(...nums) : 0) + 1);
}

function wallLen(w) {
  return Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
}

function inchOrMmToFt(val, units) {
  if (units === "m") return (val / 1000) * 3.28084; // mm to ft
  return val / 12; // inches to ft
}

function ftToDisplay(ft, units) {
  if (units === "m") return +(ft * 0.3048).toFixed(2);
  return +ft.toFixed(2);
}
function displayToFt(n, units) {
  if (units === "m") return n / 0.3048;
  return n;
}
function unitLabel() {
  return state.settings?.units === "m" ? "m" : "ft";
}

/* ---------- auth ---------- */
async function tryLogin() {
  const u = $("#login-user").value.trim();
  const p = $("#login-pass").value;
  const h = await sha256Hex(u + ":" + p);
  if (h !== DEMO_HASH) {
    $("#login-err").textContent = t("loginBad");
    return;
  }
  state.user = u;
  localStorage.setItem("naksha_session", u);
  $("#login-err").textContent = "";
  openHome();
}

function openHome() {
  showScreen("screen-home");
  $("#hello-user").textContent = t("hello") + ", " + state.user;
  renderProjectList();
}

function renderProjectList() {
  const list = loadProjects().sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const box = $("#project-list");
  if (!list.length) {
    box.innerHTML = `<p class="hint">${t("noProjects")}</p>`;
    return;
  }
  box.innerHTML = list
    .map(
      (p) => `<div class="pcard" data-id="${p.id}">
      <div><h3>${escapeHtml(p.name || "Project")}</h3>
      <span>${new Date(p.updated || p.created).toLocaleString()}</span></div>
      <button class="btn ghost small open-p">${t("open")}</button>
      <button class="btn ghost small del-p">${t("del")}</button>
    </div>`
    )
    .join("");
  box.querySelectorAll(".open-p").forEach((b) =>
    b.addEventListener("click", () => openProject(b.closest(".pcard").dataset.id))
  );
  box.querySelectorAll(".del-p").forEach((b) =>
    b.addEventListener("click", () => {
      const id = b.closest(".pcard").dataset.id;
      saveProjects(loadProjects().filter((p) => p.id !== id));
      renderProjectList();
    })
  );
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function defaultSettings() {
  return {
    size: "medium",
    scale: 100,
    units: "ft",
    floorHeight: 10,
    plinth: 2,
    lintel: 7,
    outerT: 9 / 12,
    partT: 4.5 / 12,
    outerC: "#2c3d4f",
    partC: "#c4783a",
    watermark: "Bunty's"
  };
}

function readForm() {
  const units = $("#f-units .on").dataset.v;
  const size = $("#f-size .on").dataset.v;
  let scale = $("#f-scale").value;
  if (scale === "custom") scale = parseFloat($("#f-scale-custom").value) || 100;
  else scale = parseFloat(scale);
  return {
    name: $("#f-name").value.trim() || "Mera ghar",
    settings: {
      size,
      scale,
      units,
      floorHeight: displayToFt(parseFloat($("#f-floor").value) || (units === "m" ? 3.05 : 10), units),
      plinth: displayToFt(parseFloat($("#f-plinth").value) || (units === "m" ? 0.6 : 2), units),
      lintel: displayToFt(parseFloat($("#f-lintel").value) || (units === "m" ? 2.13 : 7), units),
      outerT: inchOrMmToFt(parseFloat($("#f-outer-t").value) || (units === "m" ? 230 : 9), units),
      partT: inchOrMmToFt(parseFloat($("#f-part-t").value) || (units === "m" ? 115 : 4.5), units),
      outerC: $("#f-outer-c").value,
      partC: $("#f-part-c").value,
      watermark: $("#f-mark").value || "Bunty's"
    },
    plot: {
      w: displayToFt(parseFloat($("#f-plotw")?.value) || (units === "m" ? 9.14 : 30), units),
      d: displayToFt(parseFloat($("#f-plotd")?.value) || (units === "m" ? 15.24 : 50), units),
      front: displayToFt(parseFloat($("#f-sbf")?.value) || (units === "m" ? 1.52 : 5), units),
      back: displayToFt(parseFloat($("#f-sbb")?.value) || (units === "m" ? 0.91 : 3), units),
      left: displayToFt(parseFloat($("#f-sbl")?.value) || (units === "m" ? 0.91 : 3), units),
      right: displayToFt(parseFloat($("#f-sbr")?.value) || (units === "m" ? 0.91 : 3), units)
    }
  };
}

function fillFormDefaults() {
  $("#f-name").value = "Mera ghar";
  $$("#f-size button").forEach((b) => b.classList.toggle("on", b.dataset.v === "medium"));
  $("#f-scale").value = "100";
  $("#f-scale-custom").classList.add("hidden");
  $$("#f-units button").forEach((b) => b.classList.toggle("on", b.dataset.v === "ft"));
  $("#f-floor").value = 10;
  $("#f-plinth").value = 2;
  $("#f-lintel").value = 7;
  $("#f-mark").value = "Bunty's";
  $("#f-outer-t").value = 9;
  $("#f-part-t").value = 4.5;
  $("#f-outer-u").textContent = "inch";
  $("#f-part-u").textContent = "inch";
  $("#f-outer-c").value = "#2c3d4f";
  $("#f-part-c").value = "#c4783a";
}

function onUnitsChange() {
  const units = $("#f-units .on").dataset.v;
  if (units === "m") {
    $("#f-floor").value = 3.05;
    $("#f-plinth").value = 0.6;
    $("#f-lintel").value = 2.13;
    $("#f-outer-t").value = 230;
    $("#f-part-t").value = 115;
    $("#f-outer-u").textContent = "mm";
    $("#f-part-u").textContent = "mm";
  } else {
    $("#f-floor").value = 10;
    $("#f-plinth").value = 2;
    $("#f-lintel").value = 7;
    $("#f-outer-t").value = 9;
    $("#f-part-t").value = 4.5;
    $("#f-outer-u").textContent = "inch";
    $("#f-part-u").textContent = "inch";
  }
}

function newProjectFromForm() {
  const { name, settings, plot } = readForm();
  const rec = {
    id: "p" + Date.now().toString(36),
    name,
    settings,
    created: Date.now(),
    updated: Date.now(),
    data: { floors: [emptyFloor("Ground", 0)], floorIndex: 0, northDeg: 0, vastuOn: false, plot }
  };
  const all = loadProjects();
  all.unshift(rec);
  saveProjects(all);
  enterEditor(rec);
}

function openProject(id) {
  const rec = loadProjects().find((p) => p.id === id);
  if (rec) enterEditor(rec);
}

function enterEditor(rec) {
  state.project = rec;
  state.settings = { ...defaultSettings(), ...(rec.settings || {}) };
  const d = rec.data || {};
  state.northDeg = d.northDeg || 0;
  state.vastuOn = !!d.vastuOn;
  loadData(d);
  state.selection = null;
  state.undo = [];
  state.redo = [];
  state.tool = "select";
  state.mode = "2d";
  state.drawing = null;
  state.measureStart = null;
  setTool("select");
  $("#ed-title").textContent = rec.name;
  $("#ed-2d3d").textContent = "3D";
  showScreen("screen-editor");
  closeSheet();
  applyI18n();
  const ext = SIZE[state.settings.size] || SIZE.medium;
  state.view.zoom = 1;
  state.view.panX = 40;
  state.view.panY = 80;
  refreshRooms();
  renderFloorBar();
  requestAnimationFrame(() => {
    fitView();
    draw2d();
    show2d();
  });
  // keep reference
  void ext;
}

function leaveEditor() {
  persist();
  if (view3d) view3d.hide();
  show2d();
  openHome();
}

/* ---------- 2D view math ---------- */
function toWorld(sx, sy) {
  const v = state.view;
  return { x: (sx - v.panX) / (v.zoom * PX), y: (sy - v.panY) / (v.zoom * PX) };
}
function toScreen(x, y) {
  const v = state.view;
  return { x: x * v.zoom * PX + v.panX, y: y * v.zoom * PX + v.panY };
}

function snapSetting() {
  return (SIZE[state.settings?.size] || SIZE.medium).snap;
}

function snapPt(x, y, withEnds = true) {
  const snap = snapSetting();
  let sx = Math.round(x / snap) * snap;
  let sy = Math.round(y / snap) * snap;
  if (withEnds) {
    const r = SNAP_END_PX / (state.view.zoom * PX);
    let best = r;
    for (const w of state.walls) {
      for (const p of [
        { x: w.x1, y: w.y1 },
        { x: w.x2, y: w.y2 }
      ]) {
        const d = Math.hypot(p.x - sx, p.y - sy);
        if (d <= best) {
          best = d;
          sx = p.x;
          sy = p.y;
        }
      }
    }
  }
  return { x: sx, y: sy };
}

function normDeg(d) {
  d = Number(d) % 360;
  if (d < 0) d += 360;
  return d;
}
function worldAngle(x1, y1, x2, y2) {
  // 0 = east / +X, CCW, Y-up (canvas Y is down)
  return normDeg(Math.atan2(-(y2 - y1), (x2 - x1)) * 180 / Math.PI);
}
function pointAtAngle(x, y, deg, len) {
  const a = (deg * Math.PI) / 180;
  return { x: x + Math.cos(a) * len, y: y - Math.sin(a) * len };
}
function snapWorldAngle(deg) {
  const step = Number(state.angleSnap) || 0;
  if (!step) return deg;
  return Math.round(deg / step) * step;
}
function snapAngle(x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  if (len < 1e-6) return { x: x1, y: y1 };
  const deg = snapWorldAngle(worldAngle(x1, y1, x2, y2));
  return pointAtAngle(x1, y1, deg, len);
}
function setWallAngle(id, deg, rec = true) {
  const w = state.walls.find((x) => x.id.toUpperCase() === String(id).toUpperCase());
  if (!w) return false;
  const len = wallLen(w);
  if (!(len > 0)) return false;
  if (rec) pushUndo();
  const p = pointAtAngle(w.x1, w.y1, normDeg(deg), len);
  w.x2 = p.x;
  w.y2 = p.y;
  refreshRooms();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}
function lastWallAngleAt(x, y) {
  let best = null, bd = 0.2;
  for (const w of state.walls) {
    const d1 = Math.hypot(w.x2 - x, w.y2 - y);
    const d0 = Math.hypot(w.x1 - x, w.y1 - y);
    if (d1 < bd) { bd = d1; best = worldAngle(w.x1, w.y1, w.x2, w.y2); }
    else if (d0 < bd) { bd = d0; best = worldAngle(w.x2, w.y2, w.x1, w.y1); }
  }
  return best;
}

function distToSeg(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  if (l2 < 1e-9) return { d: Math.hypot(px - x1, py - y1), t: 0 };
  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  const qx = x1 + t * dx, qy = y1 + t * dy;
  return { d: Math.hypot(px - qx, py - qy), t };
}

function hitWall(x, y) {
  const pad = 10 / (state.view.zoom * PX);
  let best = null, bd = Infinity;
  for (const w of state.walls) {
    const hit = distToSeg(x, y, w.x1, w.y1, w.x2, w.y2);
    const th = (w.thickness || 0.5) / 2 + pad;
    if (hit.d <= th && hit.d < bd) {
      bd = hit.d;
      best = { wall: w, t: hit.t };
    }
  }
  return best;
}

function hitStair(x, y) {
  for (const s of state.stairs) {
    if (Math.hypot(x - s.x, y - s.y) < 3) return s;
  }
  return null;
}
function hitColumn(x, y) {
  for (const c of state.columns || []) {
    const r = Math.max(c.w || 0.75, c.d || 1) / 2 + 0.4;
    if (Math.hypot(x - c.x, y - c.y) < r) return c;
  }
  return null;
}
function hitRoom(x, y) {
  const list = state.rooms || [];
  for (let i = list.length - 1; i >= 0; i--) {
    if (pointInPoly(x, y, list[i].poly)) return list[i];
  }
  return null;
}

function fitView() {
  const c = $("#c2d");
  const w = c.clientWidth || innerWidth;
  const h = c.clientHeight || innerHeight;
  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  const topChrome = 90, botChrome = 140, margin = 20;
  const usableH = Math.max(200, h - topChrome - botChrome);
  const zoom = Math.min((w - margin * 2) / (ext * PX), usableH / (ext * PX));
  state.view.zoom = Math.max(0.15, Math.min(zoom, 1.6));
  const grid = ext * state.view.zoom * PX;
  state.view.panX = (w - grid) / 2;
  state.view.panY = topChrome + Math.max(0, (usableH - grid) / 2);
}

/* ---------- draw 2D ---------- */
function draw2d(target, opts = {}) {
  const canvas = target || $("#c2d");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = Math.min(devicePixelRatio || 1, 2);
  const cssW = canvas.clientWidth || innerWidth;
  const cssH = canvas.clientHeight || innerHeight;
  if (canvas.width !== Math.floor(cssW * dpr) || canvas.height !== Math.floor(cssH * dpr)) {
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);
  ctx.fillStyle = "#f3eee4";
  ctx.fillRect(0, 0, cssW, cssH);

  const v = state.view;
  ctx.save();
  ctx.translate(v.panX, v.panY);
  ctx.scale(v.zoom * PX, v.zoom * PX);

  const ext = (SIZE[state.settings?.size] || SIZE.medium).extent;
  const snap = snapSetting();
  // grid
  ctx.lineWidth = 1 / (v.zoom * PX);
  for (let g = 0; g <= ext + 0.01; g += snap) {
    const major = Math.abs(g % (snap * 10 < 5 ? 5 : 10)) < 1e-6 || g === 0;
    ctx.strokeStyle = major ? "#d4cbb6" : "#e8e1d3";
    ctx.beginPath();
    ctx.moveTo(g, 0);
    ctx.lineTo(g, ext);
    ctx.moveTo(0, g);
    ctx.lineTo(ext, g);
    ctx.stroke();
  }
  ctx.strokeStyle = "#c4b89e";
  ctx.lineWidth = 2 / (v.zoom * PX);
  ctx.strokeRect(0, 0, ext, ext);

  drawPlot(ctx);

  if (state.vastuOn) drawVastu(ctx, ext);

  // rooms (under walls)
  const pc = planCentre();
  for (const r of state.rooms || []) {
    const vck = state.vastuOn ? vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang) : null;
    const sel = state.selection && state.selection.type === "room" && state.selection.id === r.id;
    ctx.beginPath();
    r.poly.forEach((pt, i) => i ? ctx.lineTo(pt.x, pt.y) : ctx.moveTo(pt.x, pt.y));
    ctx.closePath();
    ctx.fillStyle = vck ? vck.color + "55" : (r.floorColor || "#d9d1c3") + "99";
    ctx.fill();
    if (sel) { ctx.strokeStyle = "#e8a54b"; ctx.lineWidth = 0.12; ctx.stroke(); }
  }

  // walls
  for (const w of state.walls) {
    const sel = state.selection && state.selection.type === "wall" && state.selection.id === w.id;
    ctx.strokeStyle = w.colorOut || w.color || "#2c3d4f";
    ctx.lineWidth = w.thickness || 0.75;
    ctx.lineCap = "butt";
    ctx.lineJoin = "miter";
    ctx.beginPath();
    ctx.moveTo(w.x1, w.y1);
    ctx.lineTo(w.x2, w.y2);
    ctx.stroke();
    if (sel) {
      ctx.strokeStyle = "#e8a54b";
      ctx.lineWidth = (w.thickness || 0.75) + 0.2;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.moveTo(w.x1, w.y1);
      ctx.lineTo(w.x2, w.y2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  // doors
  for (const d of state.doors) {
    const w = state.walls.find((x) => x.id === d.wallId);
    if (!w) continue;
    drawDoor(ctx, w, d, state.selection && state.selection.type === "door" && state.selection.id === d.id);
  }

  // windows
  for (const k of state.windows || []) {
    const w = state.walls.find((x) => x.id === k.wallId);
    if (!w) continue;
    drawWindow(ctx, w, k, state.selection && state.selection.type === "window" && state.selection.id === k.id);
  }

  // columns
  for (const c of state.columns || []) drawColumn2d(ctx, c, state.selection && state.selection.type === "column" && state.selection.id === c.id);

  // furniture + MEP
  for (const f of state.furniture || []) drawFurniture2d(ctx, f, state.selection && state.selection.type === "furniture" && state.selection.id === f.id);
  for (const m of state.mep || []) drawMep2d(ctx, m, state.selection && state.selection.type === "mep" && state.selection.id === m.id);

  // stairs
  for (const s of state.stairs) drawStair2d(ctx, s, state.selection && state.selection.type === "stair" && state.selection.id === s.id);

  // labels + dimensions (hide or stagger when zoomed out)
  const inv = 1 / (v.zoom * PX);
  const pxu = v.zoom * PX;
  ctx.save();
  for (const r of state.rooms || []) {
    const minDim = Math.sqrt(Math.abs(r.area) || 1) * pxu;
    if (minDim < 28) continue;
    const vck = state.vastuOn ? vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang) : null;
    const nm = (r.name ? r.name + "  " : "") + r.id;
    const ar = fmtArea(r.area);
    const extra = vck ? "  " + vck.zone : "";
    label(ctx, nm, r.cx, r.cy - 0.45, inv, vck ? vck.color : "#3a3228", true);
    if (minDim >= 48) label(ctx, ar + extra, r.cx, r.cy + 0.55, inv, "#5a5044");
  }
  for (const w of state.walls) {
    const mx = (w.x1 + w.x2) / 2, my = (w.y1 + w.y2) / 2;
    const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
    const len = Math.hypot(dx, dy) || 1;
    const screenLen = len * pxu;
    if (screenLen < 22) continue;
    const nx = -dy / len, ny = dx / len;
    const off = (w.thickness || 0.75) / 2 + 0.7;
    // place id near 1/3, dimension near 2/3 when both shown
    if (screenLen >= 110) {
      const ix = w.x1 + dx * 0.32, iy = w.y1 + dy * 0.32;
      const dxp = w.x1 + dx * 0.68, dyp = w.y1 + dy * 0.68;
      label(ctx, w.id, ix + nx * off, iy + ny * off, inv, "#1a1408");
      const dim = fmtLen(len) + (state.showWallAngles ? "  " + Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2)) + "°" : "");
      label(ctx, dim, dxp - nx * (off + 0.2), dyp - ny * (off + 0.2), inv, "#5a5044", true);
    } else {
      label(ctx, w.id, mx + nx * off, my + ny * off, inv, "#1a1408");
    }
  }
  if (pxu >= 10) {
    for (const d of state.doors) {
      const w = state.walls.find((x) => x.id === d.wallId);
      if (!w) continue;
      const p = pointOnWall(w, d.t ?? 0.5);
      label(ctx, d.id, p.x, p.y - 0.85, inv, "#1d3b5c");
    }
    for (const k of state.windows || []) {
      const w = state.walls.find((x) => x.id === k.wallId);
      if (!w) continue;
      const p = pointOnWall(w, k.t ?? 0.5);
      label(ctx, k.id, p.x, p.y + 0.85, inv, "#2a5a4a");
    }
    for (const c of state.columns || []) label(ctx, c.id, c.x, c.y - 1.0, inv, "#3a2a18");
    for (const s of state.stairs) label(ctx, s.id, s.x, s.y - 1.2, inv, "#3a2a18");
    for (const f of state.furniture || []) label(ctx, f.id, f.x, f.y - (f.d || 2) / 2 - 0.4, inv, "#3a2a18");
    for (const m of state.mep || []) label(ctx, m.id, m.x, m.y - 0.7, inv, "#2a3a4a");
  }
  if (state.showCornerAngles) drawCornerAngles(ctx, inv);
  ctx.restore();

  // live drawing
  if (state.drawing) {
    const d = state.drawing;
    ctx.strokeStyle = d.color || "#2c3d4f";
    ctx.lineWidth = d.thickness || 0.75;
    ctx.setLineDash([0.4, 0.3]);
    ctx.beginPath();
    ctx.moveTo(d.x1, d.y1);
    ctx.lineTo(d.x2, d.y2);
    ctx.stroke();
    ctx.setLineDash([]);
    const len = Math.hypot(d.x2 - d.x1, d.y2 - d.y1);
    const ang = worldAngle(d.x1, d.y1, d.x2, d.y2);
    label(ctx, fmtLen(len) + "  " + Math.round(ang) + "°", (d.x1 + d.x2) / 2, (d.y1 + d.y2) / 2 - 0.6, inv, "#1a1408", true);
  }
  if (state.measureStart) {
    ctx.fillStyle = "#e8a54b";
    ctx.beginPath();
    ctx.arc(state.measureStart.x, state.measureStart.y, 0.25, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // north arrow (screen space)
  drawNorthArrow(ctx, cssW, cssH);

  if (opts.watermark) {
    ctx.fillStyle = "rgba(30,24,16,0.35)";
    ctx.font = "600 18px system-ui, sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(opts.watermark, cssW - 16, cssH - 18);
  }
}

function label(ctx, text, x, y, inv, color, bold) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(inv, inv);
  ctx.fillStyle = color;
  ctx.font = (bold ? "650 " : "600 ") + "12px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.strokeStyle = "rgba(243,238,228,0.85)";
  ctx.lineWidth = 3;
  ctx.strokeText(text, 0, 0);
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

function fmtLen(ft) {
  const u = state.settings?.units || "ft";
  if (u === "m") return (ft * 0.3048).toFixed(2) + " m";
  const whole = Math.floor(ft + 1e-6);
  const inch = Math.round((ft - whole) * 12);
  if (inch === 0) return whole + "'";
  if (inch === 12) return whole + 1 + "'";
  return `${whole}' ${inch}"`;
}

function pointOnWall(w, t) {
  return { x: w.x1 + (w.x2 - w.x1) * t, y: w.y1 + (w.y2 - w.y1) * t };
}

function drawDoor(ctx, w, d, sel) {
  const len = wallLen(w);
  const t0 = (d.t ?? 0.5) - (d.width || 3) / 2 / len;
  const t1 = (d.t ?? 0.5) + (d.width || 3) / 2 / len;
  const a = pointOnWall(w, t0);
  const b = pointOnWall(w, t1);
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const L = Math.hypot(dx, dy) || 1;
  const nx = -dy / L, ny = dx / L;
  const swing = d.width || 3;
  ctx.save();
  // cut mark
  ctx.strokeStyle = "#f3eee4";
  ctx.lineWidth = (w.thickness || 0.75) + 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  // swing arc
  ctx.strokeStyle = sel ? "#e8a54b" : "#1d3b5c";
  ctx.lineWidth = 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(a.x + nx * swing, a.y + ny * swing);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(a.x, a.y, swing, Math.atan2(ny, nx), Math.atan2(b.y - a.y, b.x - a.x), false);
  ctx.stroke();
  ctx.restore();
}

function drawWindow(ctx, w, k, sel) {
  const len = wallLen(w);
  const t0 = (k.t ?? 0.5) - (k.width || 4) / 2 / len;
  const t1 = (k.t ?? 0.5) + (k.width || 4) / 2 / len;
  const a = pointOnWall(w, t0), b = pointOnWall(w, t1);
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const L = Math.hypot(dx, dy) || 1;
  const nx = -dy / L, ny = dx / L;
  const o = 0.28;
  ctx.save();
  ctx.strokeStyle = sel ? "#e8a54b" : "#2a5a4a";
  ctx.lineWidth = 0.08;
  ctx.beginPath();
  ctx.moveTo(a.x + nx * o, a.y + ny * o);
  ctx.lineTo(b.x + nx * o, b.y + ny * o);
  ctx.lineTo(b.x - nx * o, b.y - ny * o);
  ctx.lineTo(a.x - nx * o, a.y - ny * o);
  ctx.closePath();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo((a.x + b.x) / 2 + nx * o, (a.y + b.y) / 2 + ny * o);
  ctx.lineTo((a.x + b.x) / 2 - nx * o, (a.y + b.y) / 2 - ny * o);
  ctx.stroke();
  ctx.restore();
}
function drawColumn2d(ctx, c, sel) {
  const ww = c.w || 0.75, dd = c.d || 1;
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.rotate(((c.rot || 0) * Math.PI) / 180);
  ctx.fillStyle = sel ? "rgba(232,165,75,0.55)" : "#5c5348";
  ctx.strokeStyle = sel ? "#e8a54b" : "#2a241c";
  ctx.lineWidth = 0.07;
  ctx.fillRect(-ww / 2, -dd / 2, ww, dd);
  ctx.strokeRect(-ww / 2, -dd / 2, ww, dd);
  ctx.restore();
}
function drawStair2d(ctx, s, sel) {
  const tread = s.tread || 0.83;
  const steps = s.steps || 16;
  const width = s.width || 3;
  const type = s.type || "straight";
  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.rotate(((s.rot || 0) * Math.PI) / 180);
  ctx.strokeStyle = sel ? "#e8a54b" : "#5a4632";
  ctx.fillStyle = "rgba(196, 168, 120, 0.35)";
  ctx.lineWidth = 0.08;
  const run = (n, ox, oy, horiz) => {
    const L = n * tread;
    if (horiz) {
      ctx.fillRect(ox, oy, L, width);
      ctx.strokeRect(ox, oy, L, width);
      for (let i = 1; i < n; i++) {
        ctx.beginPath();
        ctx.moveTo(ox + i * tread, oy);
        ctx.lineTo(ox + i * tread, oy + width);
        ctx.stroke();
      }
    } else {
      ctx.fillRect(ox, oy, width, L);
      ctx.strokeRect(ox, oy, width, L);
      for (let i = 1; i < n; i++) {
        ctx.beginPath();
        ctx.moveTo(ox, oy + i * tread);
        ctx.lineTo(ox + width, oy + i * tread);
        ctx.stroke();
      }
    }
  };
  if (type === "straight") run(steps, -width / 2, 0, false);
  else if (type === "L") {
    const a = Math.ceil(steps / 2), b = steps - a;
    run(a, -width / 2, 0, false);
    run(b, -width / 2, a * tread, true);
  } else {
    const a = Math.ceil(steps / 3), b = Math.ceil((steps - a) / 2), c = steps - a - b;
    run(a, -width / 2, 0, false);
    run(b, -width / 2, a * tread, true);
    run(c, -width / 2 + b * tread, a * tread - c * tread, false);
  }
  ctx.restore();
}

const VASTU_ZONES = [
  "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"
];

function planCenter(ext) {
  if (state.walls.length) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const w of state.walls) {
      minX = Math.min(minX, w.x1, w.x2);
      minY = Math.min(minY, w.y1, w.y2);
      maxX = Math.max(maxX, w.x1, w.x2);
      maxY = Math.max(maxY, w.y1, w.y2);
    }
    return { x: (minX + maxX) / 2, y: (minY + maxY) / 2, r: Math.max(maxX - minX, maxY - minY) / 2 + 4 };
  }
  return { x: ext / 2, y: ext / 2, r: ext * 0.42 };
}

function drawVastu(ctx, ext) {
  const c = planCenter(ext);
  const north = (state.northDeg * Math.PI) / 180;
  const inv = 1 / (state.view.zoom * PX);
  const rpx = c.r * state.view.zoom * PX;
  // 16 sectors. V1 starts at North, clockwise. In canvas, north (0) is -Y.
  for (let i = 0; i < 16; i++) {
    const a0 = -Math.PI / 2 + north + (i - 0.5) * (Math.PI / 8);
    const a1 = a0 + Math.PI / 8;
    ctx.beginPath();
    ctx.moveTo(c.x, c.y);
    ctx.arc(c.x, c.y, c.r, a0, a1);
    ctx.closePath();
    ctx.fillStyle = i % 2 === 0 ? "rgba(232,165,75,0.10)" : "rgba(44,61,79,0.08)";
    ctx.fill();
    ctx.strokeStyle = "rgba(90,80,68,0.45)";
    ctx.lineWidth = 0.04;
    ctx.stroke();
    const mid = (a0 + a1) / 2;
    if (rpx >= 90) {
      const lx = c.x + Math.cos(mid) * c.r * 0.62;
      const ly = c.y + Math.sin(mid) * c.r * 0.62;
      const aStart = normDeg(i * 22.5 - 11.25);
      const aEnd = normDeg((i + 1) * 22.5 - 11.25);
      const rng = `${Math.round(aStart)}–${Math.round(aEnd)}°`;
      const txt = rpx >= 150 ? `V${i + 1} ${VASTU_ZONES[i]}  ${rng}` : (rpx >= 120 ? `V${i + 1} ${rng}` : `V${i + 1}`);
      label(ctx, txt, lx, ly, inv, "#4a3e2a", true);
    }
  }
  // 360° compass ring, 0 at north, clockwise, rotates with northDeg
  const r0 = c.r;
  const r1 = c.r * 1.08;
  const r2 = c.r * 1.16;
  ctx.beginPath();
  ctx.arc(c.x, c.y, r1, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(90,70,40,0.7)";
  ctx.lineWidth = 0.06;
  ctx.stroke();
  for (let deg = 0; deg < 360; deg += 5) {
    const a = -Math.PI / 2 + north + (deg * Math.PI) / 180;
    const major = deg % 10 === 0;
    const inner = major ? r0 * 1.02 : r0 * 1.045;
    const outer = major ? r2 : r1;
    ctx.beginPath();
    ctx.moveTo(c.x + Math.cos(a) * inner, c.y + Math.sin(a) * inner);
    ctx.lineTo(c.x + Math.cos(a) * outer, c.y + Math.sin(a) * outer);
    ctx.strokeStyle = major ? "rgba(60,45,25,0.85)" : "rgba(90,70,40,0.55)";
    ctx.lineWidth = major ? 0.05 : 0.03;
    ctx.stroke();
    if (major && rpx >= 100) {
      const lx = c.x + Math.cos(a) * r2 * 1.08;
      const ly = c.y + Math.sin(a) * r2 * 1.08;
      const num = deg === 0 ? "0 / 360" : String(deg);
      label(ctx, num, lx, ly, inv, "#3a2e1c", true);
    }
  }
  const dirs = [[0, "N", "#c0392b"], [90, "E", "#1a1408"], [180, "S", "#1a1408"], [270, "W", "#1a1408"]];
  for (const [deg, nm, col] of dirs) {
    const a = -Math.PI / 2 + north + (deg * Math.PI) / 180;
    const lx = c.x + Math.cos(a) * r0 * 0.88;
    const ly = c.y + Math.sin(a) * r0 * 0.88;
    if (rpx >= 80) label(ctx, nm, lx, ly, inv, col, true);
  }
  ctx.beginPath();
  ctx.arc(c.x, c.y, 0.5, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(232,165,75,0.5)";
  ctx.fill();
}

function drawPlot(ctx) {
  const p = state.plot;
  if (!p || !(p.w > 0) || !(p.d > 0)) return;
  ctx.save();
  ctx.strokeStyle = "rgba(80,60,30,0.55)";
  ctx.setLineDash([0.6, 0.35]);
  ctx.lineWidth = 0.08;
  ctx.strokeRect(0, 0, p.w, p.d);
  ctx.setLineDash([]);
  const f = p.front || 0, b = p.back || 0, l = p.left || 0, r = p.right || 0;
  if (f + b < p.d - 0.2 && l + r < p.w - 0.2) {
    ctx.strokeStyle = "rgba(160,60,40,0.4)";
    ctx.setLineDash([0.35, 0.25]);
    ctx.lineWidth = 0.05;
    ctx.strokeRect(l, f, p.w - l - r, p.d - f - b);
    ctx.setLineDash([]);
  }
  ctx.restore();
}

function drawFurniture2d(ctx, f, sel) {
  const kind = FURNITURE[f.kind] || FURNITURE.bed;
  const w = f.w || kind.w, d = f.d || kind.d;
  ctx.save();
  ctx.translate(f.x, f.y);
  ctx.rotate(-((f.rot || 0) * Math.PI) / 180);
  ctx.fillStyle = kind.color + (sel ? "ee" : "cc");
  ctx.strokeStyle = sel ? "#e8a54b" : "rgba(0,0,0,0.35)";
  ctx.lineWidth = sel ? 0.12 : 0.05;
  ctx.beginPath();
  ctx.rect(-w / 2, -d / 2, w, d);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawMep2d(ctx, m, sel) {
  const kind = MEP[m.kind] || MEP.light;
  ctx.save();
  ctx.fillStyle = kind.color;
  ctx.strokeStyle = sel ? "#e8a54b" : "rgba(0,0,0,0.4)";
  ctx.lineWidth = sel ? 0.12 : 0.05;
  ctx.beginPath();
  if (kind.kind === "p") ctx.rect(m.x - 0.35, m.y - 0.35, 0.7, 0.7);
  else ctx.arc(m.x, m.y, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawCornerAngles(ctx, inv) {
  const eps = 0.18;
  const nodes = [];
  const add = (x, y, wall, fromStart) => {
    let n = nodes.find((p) => Math.hypot(p.x - x, p.y - y) < eps);
    if (!n) { n = { x, y, arms: [] }; nodes.push(n); }
    const ox = fromStart ? wall.x2 : wall.x1;
    const oy = fromStart ? wall.y2 : wall.y1;
    n.arms.push({ wall, ang: Math.atan2(oy - y, ox - x) });
  };
  for (const w of state.walls) {
    add(w.x1, w.y1, w, true);
    add(w.x2, w.y2, w, false);
  }
  ctx.save();
  for (const n of nodes) {
    if (n.arms.length < 2) continue;
    const arms = n.arms.slice().sort((a, b) => a.ang - b.ang);
    for (let i = 0; i < arms.length; i++) {
      const a0 = arms[i].ang;
      const a1 = arms[(i + 1) % arms.length].ang;
      let delta = a1 - a0;
      if (delta <= 0) delta += Math.PI * 2;
      const deg = delta * 180 / Math.PI;
      if (deg < 2 || deg > 179.5) continue;
      const rad = 1.15;
      ctx.beginPath();
      ctx.arc(n.x, n.y, rad, a0, a0 + delta);
      ctx.strokeStyle = "rgba(160,80,30,0.7)";
      ctx.lineWidth = 0.06;
      ctx.stroke();
      const mid = a0 + delta / 2;
      label(ctx, Math.round(deg) + "°", n.x + Math.cos(mid) * (rad + 0.45), n.y + Math.sin(mid) * (rad + 0.45), inv, "#7a4a18", true);
    }
  }
  ctx.restore();
}

function drawNorthArrow(ctx, w, h) {
  const x = w - 36, y = 36;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((state.northDeg * Math.PI) / 180);
  ctx.fillStyle = "#1a1408";
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(7, 12);
  ctx.lineTo(0, 7);
  ctx.lineTo(-7, 12);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#c0392b";
  ctx.beginPath();
  ctx.moveTo(0, -16);
  ctx.lineTo(5, 0);
  ctx.lineTo(-5, 0);
  ctx.closePath();
  ctx.fill();
  ctx.font = "700 11px system-ui";
  ctx.textAlign = "center";
  ctx.fillStyle = "#1a1408";
  ctx.fillText("N", 0, -20);
  ctx.restore();
}

/* ---------- tools / input ---------- */
function setTool(tool) {
  state.tool = tool;
  state.drawing = null;
  if (tool !== "measure") state.measureStart = null;
  $$("#tools [data-tool]").forEach((b) => b.classList.toggle("on", b.dataset.tool === tool));
  if (tool === "measure") toast(t("measureHint"), 2200);
  draw2d();
}

function canvasPos(ev, canvas) {
  const r = canvas.getBoundingClientRect();
  return { x: ev.clientX - r.left, y: ev.clientY - r.top };
}

function wallProps(type) {
  const s = state.settings;
  if (type === "partition") return { thickness: s.partT, color: s.partC, type: "partition" };
  return { thickness: s.outerT, color: s.outerC, type: "outer" };
}

function addWall(x1, y1, x2, y2, type) {
  const len = Math.hypot(x2 - x1, y2 - y1);
  if (len < MIN_WALL) return null;
  pushUndo();
  const p = wallProps(type);
  const w = {
    id: nextId("W", state.walls),
    type: p.type,
    x1, y1, x2, y2,
    thickness: p.thickness,
    color: p.color,
    colorIn: p.color,
    colorOut: p.color,
    height: state.settings.floorHeight
  };
  state.walls.push(w);
  refreshRooms();
  persist();
  return w;
}

function setWallLength(id, ft, rec = true) {
  const w = state.walls.find((x) => x.id.toUpperCase() === id.toUpperCase());
  if (!w || !(ft > 0)) return false;
  if (rec) pushUndo();
  const dx = w.x2 - w.x1, dy = w.y2 - w.y1;
  const len = Math.hypot(dx, dy) || 1;
  w.x2 = w.x1 + (dx / len) * ft;
  w.y2 = w.y1 + (dy / len) * ft;
  refreshRooms();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}

function deleteWall(id) {
  const w = state.walls.find((x) => x.id.toUpperCase() === id.toUpperCase());
  if (!w) return false;
  pushUndo();
  state.walls = state.walls.filter((x) => x.id !== w.id);
  state.doors = state.doors.filter((d) => d.wallId !== w.id);
  state.windows = state.windows.filter((d) => d.wallId !== w.id);
  if (state.floors[state.floorIndex]) {
    state.floors[state.floorIndex].walls = state.walls;
    state.floors[state.floorIndex].doors = state.doors;
    state.floors[state.floorIndex].windows = state.windows;
  }
  refreshRooms();
  if (state.selection && state.selection.id === w.id) state.selection = null;
  closeSheet();
  persist();
  draw2d();
  if (state.mode === "3d") refresh3d();
  return true;
}

function bindCanvas() {
  const c = $("#c2d");
  const stage = $("#stage");
  let lastTap = 0;
  let pan0 = null;
  let pinch0 = null;
  let swipe0 = null;
  let moved = false;

  const getTouches = () => [...state.pointers.values()];

  stage.addEventListener("pointerdown", (ev) => {
    stage.setPointerCapture?.(ev.pointerId);
    const p = canvasPos(ev, c);
    state.pointers.set(ev.pointerId, { x: p.x, y: p.y, t: Date.now() });
    const pts = getTouches();
    moved = false;
    if (pts.length === 2) {
      state.drawing = null;
      const [a, b] = pts;
      pinch0 = {
        dist: Math.hypot(a.x - b.x, a.y - b.y),
        mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        zoom: state.view.zoom,
        panX: state.view.panX,
        panY: state.view.panY
      };
      swipe0 = { y: (a.y + b.y) / 2, dist: pinch0.dist, t: Date.now() };
      return;
    }
    if (state.mode === "3d") return;
    if (state.tool === "select" || ev.shiftKey) {
      pan0 = { x: p.x, y: p.y, panX: state.view.panX, panY: state.view.panY };
    } else if (state.tool === "outer" || state.tool === "partition") {
      const wpt = snapPt(...Object.values(toWorld(p.x, p.y)));
      const pr = wallProps(state.tool);
      state.drawing = { x1: wpt.x, y1: wpt.y, x2: wpt.x, y2: wpt.y, ...pr };
      draw2d();
    }
  });

  stage.addEventListener("pointermove", (ev) => {
    if (!state.pointers.has(ev.pointerId)) return;
    const p = canvasPos(ev, c);
    state.pointers.set(ev.pointerId, { x: p.x, y: p.y, t: Date.now() });
    const pts = getTouches();
    if (pts.length === 2 && pinch0) {
      const [a, b] = pts;
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const factor = dist / (pinch0.dist || 1);
      const z = Math.max(0.2, Math.min(6, pinch0.zoom * factor));
      const world = {
        x: (pinch0.mid.x - pinch0.panX) / (pinch0.zoom * PX),
        y: (pinch0.mid.y - pinch0.panY) / (pinch0.zoom * PX)
      };
      state.view.zoom = z;
      state.view.panX = mid.x - world.x * z * PX;
      state.view.panY = mid.y - world.y * z * PX;
      if (state.mode === "2d") draw2d();
      return;
    }
    if (state.mode === "3d") return;
    if (state.drawing && pts.length === 1) {
      moved = true;
      let pt = toWorld(p.x, p.y);
      pt = snapAngle(state.drawing.x1, state.drawing.y1, pt.x, pt.y);
      pt = snapPt(pt.x, pt.y);
      // keep angle after endpoint snap roughly
      const snapped = snapAngle(state.drawing.x1, state.drawing.y1, pt.x, pt.y);
      // if endpoint snap is close, prefer endpoint even if angle slightly off
      const raw = toWorld(p.x, p.y);
      const end = snapPt(raw.x, raw.y, true);
      const r = SNAP_END_PX / (state.view.zoom * PX);
      if (Math.hypot(end.x - raw.x, end.y - raw.y) < r * 0.9 && (end.x !== state.drawing.x1 || end.y !== state.drawing.y1)) {
        state.drawing.x2 = end.x;
        state.drawing.y2 = end.y;
      } else {
        state.drawing.x2 = snapped.x;
        state.drawing.y2 = snapped.y;
      }
      draw2d();
      return;
    }
    if (pan0 && pts.length === 1) {
      const dx = p.x - pan0.x, dy = p.y - pan0.y;
      if (Math.hypot(dx, dy) > 4) moved = true;
      state.view.panX = pan0.panX + dx;
      state.view.panY = pan0.panY + dy;
      draw2d();
    }
  });

  const endPtr = (ev) => {
    const had = state.pointers.has(ev.pointerId);
    const p = canvasPos(ev, c);
    const ptsBefore = getTouches();
    state.pointers.delete(ev.pointerId);

    // two-finger swipe up / down
    if (swipe0 && ptsBefore.length >= 2 && state.pointers.size < 2) {
      const [a, b] = ptsBefore;
      const midY = (a.y + b.y) / 2;
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      const dy = midY - swipe0.y;
      const dDist = Math.abs(dist - swipe0.dist);
      if (dDist < 50) {
        if (dy < -70) switchMode("3d");
        else if (dy > 70) switchMode("2d");
      }
      pinch0 = null;
      swipe0 = null;
      pan0 = null;
      state.drawing = null;
      return;
    }

    if (state.pointers.size === 0) {
      pinch0 = null;
      swipe0 = null;
    }
    if (!had || state.mode === "3d") {
      pan0 = null;
      return;
    }

    if (state.drawing) {
      const d = state.drawing;
      state.drawing = null;
      const w = addWall(d.x1, d.y1, d.x2, d.y2, d.type);
      if (w) {
        state.selection = { type: "wall", id: w.id };
        openWallSheet(w);
      }
      draw2d();
      pan0 = null;
      return;
    }

    if (moved) {
      pan0 = null;
      return;
    }

    // tap
    const world = toWorld(p.x, p.y);
    if (state.tool === "measure") {
      onMeasureTap(world);
    } else if (state.tool === "door") {
      const hit = hitWall(world.x, world.y);
      if (!hit) toast(t("wallNeed"));
      else placeDoor(hit.wall, hit.t);
    } else if (state.tool === "window") {
      const hit = hitWall(world.x, world.y);
      if (!hit) toast(t("wallNeed"));
      else placeWindow(hit.wall, hit.t);
    } else if (state.tool === "column") {
      placeColumn(snapPt(world.x, world.y, false));
    } else if (state.tool === "stair") {
      placeStair(snapPt(world.x, world.y, false));
    } else if (state.tool === "furniture") {
      const hit = hitFurniture(world.x, world.y);
      if (hit) { state.selection = { type: "furniture", id: hit.id }; openFurnitureSheet(hit); draw2d(); }
      else placeFurniture(snapPt(world.x, world.y, false));
    } else if (state.tool === "mep") {
      const hit = hitMep(world.x, world.y);
      if (hit) { state.selection = { type: "mep", id: hit.id }; openMepSheet(hit); draw2d(); }
      else placeMep(snapPt(world.x, world.y, false));
    } else {
      const fu = hitFurniture(world.x, world.y);
      if (fu) {
        state.selection = { type: "furniture", id: fu.id };
        openFurnitureSheet(fu);
        draw2d();
        pan0 = null;
        return;
      }
      const me = hitMep(world.x, world.y);
      if (me) {
        state.selection = { type: "mep", id: me.id };
        openMepSheet(me);
        draw2d();
        pan0 = null;
        return;
      }
      const col = hitColumn(world.x, world.y);
      if (col) {
        state.selection = { type: "column", id: col.id };
        openColumnSheet(col);
        draw2d();
        pan0 = null;
        return;
      }
      const st = hitStair(world.x, world.y);
      if (st) {
        state.selection = { type: "stair", id: st.id };
        openStairSheet(st);
        draw2d();
        pan0 = null;
        return;
      }
      const hit = hitWall(world.x, world.y);
      if (hit) {
        const door = state.doors.find((d) => d.wallId === hit.wall.id && Math.abs((d.t ?? 0.5) - hit.t) * wallLen(hit.wall) < (d.width || 3) / 2 + 0.3);
        const win = state.windows.find((d) => d.wallId === hit.wall.id && Math.abs((d.t ?? 0.5) - hit.t) * wallLen(hit.wall) < (d.width || 4) / 2 + 0.3);
        if (door && (!win || Math.abs((door.t ?? 0.5) - hit.t) <= Math.abs((win.t ?? 0.5) - hit.t))) {
          state.selection = { type: "door", id: door.id };
          openDoorSheet(door);
        } else if (win) {
          state.selection = { type: "window", id: win.id };
          openWindowSheet(win);
        } else {
          state.selection = { type: "wall", id: hit.wall.id };
          openWallSheet(hit.wall);
        }
      } else {
        const rm = hitRoom(world.x, world.y);
        if (rm) {
          state.selection = { type: "room", id: rm.id };
          openRoomSheet(rm);
        } else {
          state.selection = null;
          closeSheet();
        }
      }
      draw2d();
    }
    pan0 = null;
    lastTap = Date.now();
    void lastTap;
  };

  stage.addEventListener("pointerup", endPtr);
  stage.addEventListener("pointercancel", endPtr);
  stage.addEventListener("lostpointercapture", () => {});

  stage.addEventListener(
    "wheel",
    (ev) => {
      if (state.mode !== "2d") return;
      ev.preventDefault();
      const p = canvasPos(ev, c);
      const world = toWorld(p.x, p.y);
      const z = Math.max(0.2, Math.min(6, state.view.zoom * (ev.deltaY > 0 ? 0.9 : 1.1)));
      state.view.zoom = z;
      state.view.panX = p.x - world.x * z * PX;
      state.view.panY = p.y - world.y * z * PX;
      draw2d();
    },
    { passive: false }
  );

  addEventListener("resize", () => {
    if (state.mode === "2d") draw2d();
    else if (view3d) view3d.resize();
  });
}

function onMeasureTap(world) {
  if (!state.measureStart) {
    state.measureStart = snapPt(world.x, world.y);
    draw2d();
    openMeasureSheet();
    return;
  }
}

function dirVec(heading) {
  // heading 0 = N, 90 = E, clockwise; northDeg rotates the compass
  const a = ((heading + state.northDeg) * Math.PI) / 180 - Math.PI / 2;
  return { x: Math.cos(a), y: Math.sin(a) };
}

function openMeasureSheet() {
  const u = unitLabel();
  const rel0 = !!state.measureRel;
  $("#sheet").innerHTML = `
    <h3>${t("tMeasure")}</h3>
    <label>${t("length")} (${u})</label>
    <input id="ms-len" type="number" step="0.1" value="${u === "m" ? 3 : 10}">
    <label>${t("angle")} (°)</label>
    <input id="ms-ang" type="number" step="1" min="0" max="360" value="0" placeholder="0–360">
    <div class="seg" id="ms-mode">
      <button type="button" data-v="abs" class="${rel0?"":"on"}">${t("absolute")}</button>
      <button type="button" data-v="rel" class="${rel0?"on":""}">${t("relative")}</button>
    </div>
    <label>${t("dir")}</label>
    <div class="seg" id="ms-dir" style="flex-wrap:wrap">
      ${["N","NE","E","SE","S","SW","W","NW"].map((d,i)=>`<button type="button" data-h="${i*45}" class="${d==="E"?"on":""}">${d}</button>`).join("")}
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ms-ok">${t("apply")}</button>
      <button class="btn ghost small" id="ms-cancel">Cancel</button>
    </div>`;
  openSheet();
  $$("#ms-dir button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ms-dir button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      const h = parseFloat(b.dataset.h);
      // compass heading 0=N to world angle 0=E CCW: world = 90 - heading - north? 
      // dirVec already used heading; also fill angle field as world degrees of that dir
      const v = dirVec(h);
      $("#ms-ang").value = String(Math.round(worldAngle(0, 0, v.x, v.y)));
    })
  );
  $$("#ms-mode button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ms-mode button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      state.measureRel = b.dataset.v === "rel";
    })
  );
  $("#ms-ok").onclick = () => {
    const len = displayToFt(parseFloat($("#ms-len").value) || 0, state.settings.units);
    const s = state.measureStart;
    const rel = $("#ms-mode .on")?.dataset.v === "rel";
    state.measureRel = rel;
    let ang = $("#ms-ang").value;
    let deg;
    if (ang !== "" && !isNaN(parseFloat(ang))) {
      deg = parseFloat(ang);
      if (rel) {
        const base = lastWallAngleAt(s.x, s.y) ?? 0;
        deg = base + deg;
      }
    } else {
      const h = parseFloat($("#ms-dir .on")?.dataset.h || "90");
      const v = dirVec(h);
      deg = worldAngle(0, 0, v.x, v.y);
    }
    if (s && len > MIN_WALL) {
      const p = pointAtAngle(s.x, s.y, deg, len);
      const w = addWall(s.x, s.y, p.x, p.y, "outer");
      if (w) {
        state.selection = { type: "wall", id: w.id };
        openWallSheet(w);
      }
    }
    state.measureStart = null;
    draw2d();
  };
  $("#ms-cancel").onclick = () => {
    state.measureStart = null;
    closeSheet();
    draw2d();
  };
}

function openSheet() {
  $("#sheet").classList.add("open");
}
function closeSheet() {
  $("#sheet").classList.remove("open");
}

function openWallSheet(w) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${w.id}</h3>
    <div class="row">
      <div><label>${t("length")} (${u})</label><input id="ws-len" type="number" step="0.1" value="${ftToDisplay(wallLen(w), state.settings.units)}"></div>
      <div><label>${t("height")} (${u})</label><input id="ws-h" type="number" step="0.1" value="${ftToDisplay(w.height || state.settings.floorHeight, state.settings.units)}"></div>
    </div>
    <label>${t("angle")} (°)</label>
    <input id="ws-ang" type="number" step="1" value="${Math.round(worldAngle(w.x1, w.y1, w.x2, w.y2))}">
    <label>${t("type")}</label>
    <div class="seg" id="ws-type">
      <button type="button" data-v="outer" class="${w.type==="partition"?"":"on"}">${t("tOuter")}</button>
      <button type="button" data-v="partition" class="${w.type==="partition"?"on":""}">${t("tPart")}</button>
    </div>
    <div class="row">
      <div><label>${t("colorIn")}</label><input id="ws-cin" type="color" value="${w.colorIn || w.color || "#2c3d4f"}"></div>
      <div><label>${t("colorOut")}</label><input id="ws-cout" type="color" value="${w.colorOut || w.color || "#2c3d4f"}"></div>
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ws-ok">${t("apply")}</button>
      <button class="btn danger small" id="ws-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#ws-type button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ws-type button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $("#ws-ok").onclick = () => {
    const wall = state.walls.find((x) => x.id === w.id);
    if (!wall) return;
    pushUndo();
    setWallLength(wall.id, displayToFt(parseFloat($("#ws-len").value) || 0, state.settings.units), false);
    const ang = parseFloat($("#ws-ang")?.value);
    if (!isNaN(ang)) setWallAngle(wall.id, ang, false);
    const w2 = state.walls.find((x) => x.id === w.id);
    if (w2) {
      w2.height = displayToFt(parseFloat($("#ws-h").value) || 0, state.settings.units) || w2.height;
      const typ = $("#ws-type .on")?.dataset.v || w2.type;
      if (typ !== w2.type) {
        w2.type = typ;
        const p = wallProps(typ);
        w2.thickness = p.thickness;
        w2.color = p.color;
      }
      w2.colorIn = $("#ws-cin").value;
      w2.colorOut = $("#ws-cout").value;
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
    }
  };
  $("#ws-del").onclick = () => deleteWall(w.id);
}

function placeDoor(wall, t) {
  pushUndo();
  const width = state.settings.units === "m" ? 0.9 / 0.3048 : 3;
  const d = {
    id: nextId("D", state.doors),
    wallId: wall.id,
    t: Math.max(0.1, Math.min(0.9, t)),
    width,
    height: state.settings.lintel
  };
  // keep door fully on wall
  const half = width / 2 / wallLen(wall);
  d.t = Math.max(half + 0.01, Math.min(1 - half - 0.01, d.t));
  state.doors.push(d);
  state.selection = { type: "door", id: d.id };
  persist();
  openDoorSheet(d);
  draw2d();
}

function openDoorSheet(d) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${d.id}</h3>
    <label>${t("width")} (${u})</label>
    <input id="ds-w" type="number" step="0.1" value="${ftToDisplay(d.width, state.settings.units)}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ds-ok">${t("apply")}</button>
      <button class="btn danger small" id="ds-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#ds-ok").onclick = () => {
    const door = state.doors.find((x) => x.id === d.id);
    if (!door) return;
    pushUndo();
    door.width = displayToFt(parseFloat($("#ds-w").value) || 0, state.settings.units) || door.width;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ds-del").onclick = () => {
    pushUndo();
    state.doors = state.doors.filter((x) => x.id !== d.id);
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

function placeStair(pt) {
  pushUndo();
  const units = state.settings.units;
  const s = {
    id: nextId("S", state.stairs),
    type: "straight",
    x: pt.x,
    y: pt.y,
    riser: units === "m" ? 0.15 / 0.3048 : 0.5,
    tread: units === "m" ? 0.25 / 0.3048 : 10 / 12,
    steps: Math.max(2, Math.round(state.settings.floorHeight / (units === "m" ? 0.15 / 0.3048 : 0.5))),
    width: units === "m" ? 1 / 0.3048 : 3,
    rot: 0
  };
  state.stairs.push(s);
  state.selection = { type: "stair", id: s.id };
  persist();
  openStairSheet(s);
  draw2d();
}

function openStairSheet(s) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${s.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="ss-type">
      <button type="button" data-v="straight" class="${s.type==="straight"?"on":""}">${t("straight")}</button>
      <button type="button" data-v="L" class="${s.type==="L"?"on":""}">${t("L")}</button>
      <button type="button" data-v="U" class="${s.type==="U"?"on":""}">${t("U")}</button>
      <button type="button" data-v="spiral" class="${s.type==="spiral"?"on":""}">${t("spiral")}</button>
    </div>
    <div class="row">
      <div><label>${t("riser")} (${u})</label><input id="ss-r" type="number" step="0.01" value="${ftToDisplay(s.riser, state.settings.units)}"></div>
      <div><label>${t("tread")} (${u})</label><input id="ss-t" type="number" step="0.01" value="${ftToDisplay(s.tread, state.settings.units)}"></div>
    </div>
    <div class="row">
      <div><label>${t("steps")}</label><input id="ss-n" type="number" step="1" value="${s.steps}"></div>
      <div><label>${t("width")} (${u})</label><input id="ss-w" type="number" step="0.1" value="${ftToDisplay(s.width, state.settings.units)}"></div>
    </div>
    <label>${t("rot")} (°)</label>
    <input id="ss-rot" type="number" step="45" value="${s.rot || 0}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ss-ok">${t("apply")}</button>
      <button class="btn danger small" id="ss-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#ss-type button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#ss-type button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $("#ss-ok").onclick = () => {
    const st = state.stairs.find((x) => x.id === s.id);
    if (!st) return;
    pushUndo();
    st.type = $("#ss-type .on")?.dataset.v || st.type;
    st.riser = displayToFt(parseFloat($("#ss-r").value) || 0, state.settings.units) || st.riser;
    st.tread = displayToFt(parseFloat($("#ss-t").value) || 0, state.settings.units) || st.tread;
    st.steps = parseInt($("#ss-n").value, 10) || st.steps;
    st.width = displayToFt(parseFloat($("#ss-w").value) || 0, state.settings.units) || st.width;
    st.rot = parseFloat($("#ss-rot").value) || 0;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ss-del").onclick = () => {
    pushUndo();
    state.stairs = state.stairs.filter((x) => x.id !== s.id);
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

function placeWindow(wall, t) {
  pushUndo();
  const width = state.settings.units === "m" ? 1.2 / 0.3048 : 4;
  const k = {
    id: nextId("K", state.windows),
    wallId: wall.id,
    t: Math.max(0.1, Math.min(0.9, t)),
    width,
    height: state.settings.units === "m" ? 1.2 / 0.3048 : 4,
    sill: state.settings.units === "m" ? 0.9 / 0.3048 : 3
  };
  const half = k.width / 2 / wallLen(wall);
  k.t = Math.max(half + 0.01, Math.min(1 - half - 0.01, k.t));
  state.windows.push(k);
  state.selection = { type: "window", id: k.id };
  persist();
  openWindowSheet(k);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openWindowSheet(k) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${k.id}</h3>
    <div class="row">
      <div><label>${t("width")} (${u})</label><input id="ks-w" type="number" step="0.1" value="${ftToDisplay(k.width, state.settings.units)}"></div>
      <div><label>${t("height")} (${u})</label><input id="ks-h" type="number" step="0.1" value="${ftToDisplay(k.height, state.settings.units)}"></div>
    </div>
    <label>${t("sill")} (${u})</label>
    <input id="ks-s" type="number" step="0.1" value="${ftToDisplay(k.sill, state.settings.units)}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="ks-ok">${t("apply")}</button>
      <button class="btn danger small" id="ks-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#ks-ok").onclick = () => {
    const win = state.windows.find((x) => x.id === k.id);
    if (!win) return;
    pushUndo();
    win.width = displayToFt(parseFloat($("#ks-w").value) || 0, state.settings.units) || win.width;
    win.height = displayToFt(parseFloat($("#ks-h").value) || 0, state.settings.units) || win.height;
    win.sill = displayToFt(parseFloat($("#ks-s").value) || 0, state.settings.units) || win.sill;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#ks-del").onclick = () => {
    pushUndo();
    state.windows = state.windows.filter((x) => x.id !== k.id);
    if (state.floors[state.floorIndex]) state.floors[state.floorIndex].windows = state.windows;
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}
function placeColumn(pt) {
  pushUndo();
  const c = {
    id: nextId("C", state.columns),
    x: pt.x, y: pt.y,
    w: 9 / 12, d: 12 / 12,
    rot: 0,
    height: state.settings.floorHeight
  };
  state.columns.push(c);
  state.selection = { type: "column", id: c.id };
  persist();
  openColumnSheet(c);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openColumnSheet(c) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${c.id}</h3>
    <div class="row">
      <div><label>${t("colSize")} W (${u})</label><input id="cs-w" type="number" step="0.01" value="${ftToDisplay(c.w, state.settings.units)}"></div>
      <div><label>D (${u})</label><input id="cs-d" type="number" step="0.01" value="${ftToDisplay(c.d, state.settings.units)}"></div>
    </div>
    <div class="row">
      <div><label>${t("height")} (${u})</label><input id="cs-h" type="number" step="0.1" value="${ftToDisplay(c.height || state.settings.floorHeight, state.settings.units)}"></div>
      <div><label>${t("rot")} (°)</label><input id="cs-r" type="number" step="15" value="${c.rot || 0}"></div>
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="cs-ok">${t("apply")}</button>
      <button class="btn danger small" id="cs-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $("#cs-ok").onclick = () => {
    const col = state.columns.find((x) => x.id === c.id);
    if (!col) return;
    pushUndo();
    col.w = displayToFt(parseFloat($("#cs-w").value) || 0, state.settings.units) || col.w;
    col.d = displayToFt(parseFloat($("#cs-d").value) || 0, state.settings.units) || col.d;
    col.height = displayToFt(parseFloat($("#cs-h").value) || 0, state.settings.units) || col.height;
    col.rot = parseFloat($("#cs-r").value) || 0;
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
  $("#cs-del").onclick = () => {
    pushUndo();
    state.columns = state.columns.filter((x) => x.id !== c.id);
    if (state.floors[state.floorIndex]) state.floors[state.floorIndex].columns = state.columns;
    state.selection = null;
    closeSheet();
    persist();
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}
function openRoomSheet(r) {
  const pc = planCentre();
  const vck = vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang);
  $("#sheet").innerHTML = `
    <h3>${r.id}</h3>
    <label>${t("roomName")}</label>
    <input id="rs-n" type="text" value="${escapeHtml(r.name || "")}">
    <p class="hint">${t("area")}: ${fmtArea(r.area)}${vck ? " · " + vck.zone + " (" + vck.dir + ")" : ""}</p>
    ${vck ? `<p class="hint" style="color:${vck.color}">${escapeHtml(vck.text)}</p>` : ""}
    <label>${t("floorCol")}</label>
    <input id="rs-c" type="color" value="${r.floorColor || "#d9d1c3"}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="rs-ok">${t("apply")}</button>
    </div>`;
  openSheet();
  $("#rs-ok").onclick = () => {
    const rm = state.rooms.find((x) => x.id === r.id);
    if (!rm) return;
    pushUndo();
    rm.name = $("#rs-n").value.trim();
    rm.floorColor = $("#rs-c").value;
    persist();
    openRoomSheet(rm);
    draw2d();
    if (state.mode === "3d") refresh3d();
  };
}

/* ---------- 3D toggle ---------- */
function show2d() {
  $("#c2d").classList.remove("hidden");
  if (view3d) {
    view3d.walk = false;
    view3d.controls.enabled = true;
    view3d.hide();
  }
  state.mode = "2d";
  $("#ed-2d3d").textContent = "3D";
  $("#walk-bar")?.classList.add("hidden");
  $("#sun-bar")?.classList.add("hidden");
  state.sunOn = false;
  draw2d();
}

function refresh3d() {
  if (!view3d) view3d = new View3D($("#c3d"));
  view3d.build({
    floors: state.floors,
    floorIndex: state.floorIndex,
    settings: state.settings,
    vastuOn: state.vastuOn,
    northDeg: state.northDeg,
    lang: state.lang,
    roofOn: state.roofOn,
    sunHour: state.sunHour,
    sunOn: state.sunOn
  });
}

function show3d() {
  persist();
  refresh3d();
  $("#c2d").classList.add("hidden");
  view3d.show();
  state.mode = "3d";
  $("#ed-2d3d").textContent = "2D";
}

function switchMode(m) {
  if (m === "3d") show3d();
  else show2d();
}

function handleFloorCommand(s) {
  if (/^(naya|new)\s*(floor|manzil)/.test(s) || /^add\s*(floor|manzil)$/.test(s)) {
    addFloor(false);
    return true;
  }
  if (/(floor|manzil)\s*copy/.test(s) || /^copy\s*(floor|manzil)$/.test(s)) {
    addFloor(true);
    return true;
  }
  if (/^(naya|new|add)?\s*(basement|tala|talaghar)\s*(banao|banaye|add|karo)?$/.test(s)
      || /^(basement|tala)\s*(banao|banaye|add)$/.test(s)) {
    addFloor(false, { basement: true });
    return true;
  }
  const level = parseFloorLevel(s);
  if (level == null) return false;
  if (!/(floor|manzil|basement|tala|ground|storey|story|\bb\d+)/.test(s) && !/^(g|gf)$/.test(s)) return false;
  const make = /(banao|banaye|add|banaao|create)/.test(s);
  const i = state.floors.findIndex((f) => f.level === level);
  if (i >= 0) {
    switchFloor(i);
    toast(floorName(i));
    return true;
  }
  if (make || /(floor|manzil|basement|tala)/.test(s)) {
    addFloor(false, { level, basement: level < 0 });
    return true;
  }
  toast("Floor nahi mila");
  return true;
}

function hitFurniture(x, y) {
  let best = null, bd = Infinity;
  for (const f of state.furniture || []) {
    const kind = FURNITURE[f.kind] || FURNITURE.bed;
    const hw = (f.w || kind.w) / 2, hd = (f.d || kind.d) / 2;
    const d = Math.hypot(x - f.x, y - f.y);
    if (d < Math.max(hw, hd) + 0.3 && d < bd) { bd = d; best = f; }
  }
  return best;
}
function hitMep(x, y) {
  return (state.mep || []).find((m) => Math.hypot(x - m.x, y - m.y) < 0.7) || null;
}
function placeFurniture(pt) {
  pushUndo();
  const kind = state.furnKind || "bed";
  const def = FURNITURE[kind] || FURNITURE.bed;
  const f = { id: nextId("F", state.furniture), kind, x: pt.x, y: pt.y, w: def.w, d: def.d, rot: 0 };
  state.furniture.push(f);
  state.selection = { type: "furniture", id: f.id };
  persist();
  openFurnitureSheet(f);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function placeMep(pt) {
  pushUndo();
  const kind = state.mepKind || "light";
  const def = MEP[kind] || MEP.light;
  const prefix = def.kind === "p" ? "P" : "E";
  const pool = state.mep.filter((x) => x.id[0] === prefix);
  const m = { id: nextId(prefix, pool.length ? pool : [{ id: prefix + "0" }]), kind, x: pt.x, y: pt.y };
  // unique among all mep
  if (state.mep.some((x) => x.id === m.id)) m.id = nextId(prefix, state.mep);
  state.mep.push(m);
  state.selection = { type: "mep", id: m.id };
  persist();
  openMepSheet(m);
  draw2d();
  if (state.mode === "3d") refresh3d();
}
function openFurnitureSheet(f) {
  const u = unitLabel();
  $("#sheet").innerHTML = `
    <h3>${f.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="fu-kind" style="flex-wrap:wrap">
      ${Object.keys(FURNITURE).map((k) => `<button type="button" data-v="${k}" class="${f.kind===k?"on":""}">${FURNITURE[k].name}</button>`).join("")}
    </div>
    <div class="row">
      <div><label>${t("width")} (${u})</label><input id="fu-w" type="number" step="0.1" value="${ftToDisplay(f.w, state.settings.units)}"></div>
      <div><label>D (${u})</label><input id="fu-d" type="number" step="0.1" value="${ftToDisplay(f.d, state.settings.units)}"></div>
    </div>
    <label>${t("rot")} (°)</label>
    <input id="fu-rot" type="number" step="15" value="${f.rot || 0}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="fu-ok">${t("apply")}</button>
      <button class="btn danger small" id="fu-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#fu-kind button").forEach((b) => b.addEventListener("click", () => {
    $$("#fu-kind button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    state.furnKind = b.dataset.v;
  }));
  $("#fu-ok").onclick = () => {
    const it = state.furniture.find((x) => x.id === f.id);
    if (!it) return;
    pushUndo();
    it.kind = $("#fu-kind .on")?.dataset.v || it.kind;
    state.furnKind = it.kind;
    it.w = displayToFt(parseFloat($("#fu-w").value) || 0, state.settings.units) || it.w;
    it.d = displayToFt(parseFloat($("#fu-d").value) || 0, state.settings.units) || it.d;
    it.rot = parseFloat($("#fu-rot").value) || 0;
    persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
  $("#fu-del").onclick = () => {
    pushUndo();
    const i = state.furniture.findIndex((x) => x.id === f.id);
    if (i >= 0) state.furniture.splice(i, 1);
    state.selection = null; closeSheet(); persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
}
function openMepSheet(m) {
  $("#sheet").innerHTML = `
    <h3>${m.id}</h3>
    <label>${t("type")}</label>
    <div class="seg" id="me-kind" style="flex-wrap:wrap">
      ${Object.keys(MEP).map((k) => `<button type="button" data-v="${k}" class="${m.kind===k?"on":""}">${MEP[k].name}</button>`).join("")}
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn small" id="me-ok">${t("apply")}</button>
      <button class="btn danger small" id="me-del">${t("delete")}</button>
    </div>`;
  openSheet();
  $$("#me-kind button").forEach((b) => b.addEventListener("click", () => {
    $$("#me-kind button").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    state.mepKind = b.dataset.v;
  }));
  $("#me-ok").onclick = () => {
    const it = state.mep.find((x) => x.id === m.id);
    if (!it) return;
    pushUndo();
    it.kind = $("#me-kind .on")?.dataset.v || it.kind;
    state.mepKind = it.kind;
    persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
  $("#me-del").onclick = () => {
    pushUndo();
    const i = state.mep.findIndex((x) => x.id === m.id);
    if (i >= 0) state.mep.splice(i, 1);
    state.selection = null; closeSheet(); persist(); draw2d(); if (state.mode === "3d") refresh3d();
  };
}

function openNorthSheet() {
  $("#sheet").innerHTML = `
    <h3>${t("setNorth")}</h3>
    <label>${t("angle")} (°)</label>
    <input id="nd-val" type="number" step="1" min="0" max="360" value="${Math.round(state.northDeg || 0)}">
    <div class="dial-wrap"><canvas id="north-dial" width="180" height="180"></canvas></div>
    <div class="row"><button class="btn small" id="nd-ok">${t("apply")}</button></div>`;
  openSheet();
  const c = $("#north-dial");
  const drawDial = () => {
    const ctx = c.getContext("2d");
    const w = c.width, h = c.height, r = 74, cx = w / 2, cy = h / 2;
    const n = normDeg(parseFloat($("#nd-val").value) || 0);
    ctx.clearRect(0, 0, w, h);
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = "#efe8d8"; ctx.fill();
    ctx.strokeStyle = "#5a4a32"; ctx.lineWidth = 3; ctx.stroke();
    for (let d = 0; d < 360; d += 10) {
      const a = -Math.PI / 2 + (d * Math.PI) / 180;
      const inner = d % 30 === 0 ? r - 12 : r - 7;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
      ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      ctx.strokeStyle = "#3a2e1c"; ctx.lineWidth = d % 30 === 0 ? 2 : 1; ctx.stroke();
    }
    // needle at northDeg clockwise from up
    const a = -Math.PI / 2 + (n * Math.PI) / 180;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * (r - 8), cy + Math.sin(a) * (r - 8));
    ctx.lineTo(cx, cy);
    ctx.strokeStyle = "#c0392b"; ctx.lineWidth = 3; ctx.stroke();
    ctx.fillStyle = "#c0392b"; ctx.font = "700 14px system-ui"; ctx.textAlign = "center";
    ctx.fillText("N", cx + Math.cos(a) * (r - 22), cy + Math.sin(a) * (r - 22) + 5);
    ctx.fillStyle = "#1a1408"; ctx.fillText(Math.round(n) + "°", cx, cy + r + 16);
  };
  drawDial();
  const setFromEv = (ev) => {
    const r = c.getBoundingClientRect();
    const x = ev.clientX - r.left - r.width / 2;
    const y = ev.clientY - r.top - r.height / 2;
    let deg = Math.atan2(x, -y) * 180 / Math.PI;
    if (deg < 0) deg += 360;
    $("#nd-val").value = String(Math.round(deg));
    drawDial();
  };
  c.addEventListener("pointerdown", (e) => { c.setPointerCapture?.(e.pointerId); setFromEv(e); });
  c.addEventListener("pointermove", (e) => { if (e.buttons) setFromEv(e); });
  $("#nd-val").addEventListener("input", drawDial);
  $("#nd-ok").onclick = () => {
    pushUndo();
    state.northDeg = normDeg(parseFloat($("#nd-val").value) || 0);
    persist();
    closeSheet();
    draw2d();
    toast("North " + Math.round(state.northDeg) + "°");
  };
}

function showBoq() {
  const q = boqFor(state.floors, state.settings);
  const u = state.settings?.units === "m";
  const L = (ft) => u ? (ft * 0.3048).toFixed(2) + " m" : Math.round(ft) + " ft";
  const A = (ft) => u ? (ft * 0.0929).toFixed(1) + " m²" : Math.round(ft) + " sq.ft";
  const V = (ft) => u ? (ft * 0.0283).toFixed(2) + " m³" : Math.round(ft) + " cu.ft";
  $("#sheet").innerHTML = `
    <h3>${t("boq")}</h3>
    <div class="boq"><table>
      <tr><td>Floors</td><td>${q.floors}</td></tr>
      <tr><td>Outer wall</td><td>${L(q.outerLen)}</td></tr>
      <tr><td>Partition</td><td>${L(q.partLen)}</td></tr>
      <tr><td>Net wall area</td><td>${A(q.wallArea)}</td></tr>
      <tr><td>Openings</td><td>${A(q.openArea)}</td></tr>
      <tr><td>Bricks (approx.)</td><td>${q.bricks.toLocaleString()}</td></tr>
      <tr><td>Cement</td><td>${q.cementBags} bags</td></tr>
      <tr><td>Sand</td><td>${V(q.sandCuft)}</td></tr>
      <tr><td>Concrete (lintel + stair)</td><td>${V(q.concreteCuft)}</td></tr>
      <tr><td>Steel (approx.)</td><td>${q.steelKg} kg</td></tr>
    </table></div>
    <p class="hint">Yeh andaz hai, site ke hisaab se badal sakta hai.</p>`;
  openSheet();
}

function exportDxf() {
  const txt = toDxf(state.floors);
  const blob = new Blob([txt], { type: "application/dxf" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = (state.project?.name || "naksha") + ".dxf";
  a.click();
  toast("DXF");
}

function vastuReportPdf() {
  const jsPDF = window.jspdf?.jsPDF;
  if (!jsPDF) { toast("PDF library missing"); return; }
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const mark = state.settings?.watermark || "Bunty's";
  doc.setFontSize(16);
  doc.text("Vastu report — " + (state.project?.name || ""), 15, 18);
  doc.setFontSize(10);
  doc.text("North " + Math.round(state.northDeg || 0) + "°    " + mark, 15, 25);
  let y = 34;
  const pc = planCentre();
  for (const f of state.floors) {
    doc.setFont(undefined, "bold");
    doc.text((f.name || defaultFloorName(f.level || 0)), 15, y); y += 6;
    doc.setFont(undefined, "normal");
    const rooms = f.rooms || [];
    if (!rooms.length) { doc.text("—", 18, y); y += 6; }
    for (const r of rooms) {
      const vck = vastuForRoom(r, pc.x, pc.y, state.northDeg, state.lang);
      const line = `${r.id}  ${r.name || ""}  ${fmtArea(r.area)}  ${vck ? vck.zone + "  " + (vck.note || vck.status || "") : ""}`;
      const lines = doc.splitTextToSize(line, 180);
      doc.text(lines, 18, y);
      y += lines.length * 5 + 1;
      if (y > 280) { doc.addPage(); y = 18; }
    }
    y += 3;
  }
  doc.setTextColor(180);
  doc.setFontSize(22);
  doc.text(mark, 105, 150, { align: "center", angle: 20 });
  doc.save((state.project?.name || "naksha") + "-vastu.pdf");
  toast("Vastu report");
}

function backupJson() {
  const payload = {
    name: state.project?.name,
    settings: state.settings,
    data: snapshot(),
    saved: Date.now()
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = (state.project?.name || "naksha") + ".json";
  a.click();
  toast("Backup");
}

function restoreJson(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(reader.result);
      pushUndo();
      if (obj.settings) state.settings = { ...state.settings, ...obj.settings };
      const d = obj.data || obj;
      loadData(d);
      refreshRooms();
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(t("restore"));
    } catch (e) {
      toast("JSON padha nahi gaya");
    }
  };
  reader.readAsText(file);
}

function applyTemplate(key) {
  const tpl = TEMPLATES[key];
  if (!tpl) return;
  const { name, settings, plot: formPlot } = readForm();
  const plot = tpl.plot || formPlot;
  const floor = emptyFloor("Ground", 0);
  const pOuter = { thickness: settings.outerT, color: settings.outerC };
  const pPart = { thickness: settings.partT, color: settings.partC };
  (tpl.walls || []).forEach((w, i) => {
    const p = (w.type === "partition") ? pPart : pOuter;
    floor.walls.push({
      id: "W" + (i + 1), type: w.type || "outer",
      x1: w.x1, y1: w.y1, x2: w.x2, y2: w.y2,
      thickness: p.thickness, color: p.color, colorIn: p.color, colorOut: p.color,
      height: settings.floorHeight
    });
  });
  (tpl.doors || []).forEach((d, i) => {
    const wall = floor.walls[d.wall];
    if (!wall) return;
    floor.doors.push({ id: "D" + (i + 1), wallId: wall.id, t: d.t, width: d.width, height: settings.lintel });
  });
  floor.rooms = detectRooms(floor.walls, []);
  for (const hint of tpl.rooms || []) {
    const hit = floor.rooms.find((r) => pointInPoly(hint.cx, hint.cy, r.poly));
    if (hit) hit.name = hint.name;
  }
  const rec = {
    id: "p" + Date.now().toString(36),
    name: (name || "Mera ghar") + " — " + tpl.name,
    settings, created: Date.now(), updated: Date.now(),
    data: { floors: [floor], floorIndex: 0, northDeg: 0, vastuOn: false, plot }
  };
  const all = loadProjects();
  all.unshift(rec);
  saveProjects(all);
  enterEditor(rec);
}

function setSnap(v) {
  state.angleSnap = Number(v) || 0;
  $$("#snap-bar [data-snap]").forEach((b) => b.classList.toggle("on", Number(b.dataset.snap) === state.angleSnap));
  if (state.project) persist();
}

function toggleSun(on) {
  state.sunOn = on ?? !state.sunOn;
  $("#sun-bar")?.classList.toggle("hidden", !state.sunOn);
  if (state.mode === "3d") refresh3d();
  else if (state.sunOn) switchMode("3d");
}

function toggleWalk(on) {
  const walk = on ?? (view3d && view3d.walk);
  if (state.mode !== "3d") switchMode("3d");
  if (!view3d) return;
  const next = typeof on === "boolean" ? on : !view3d.walk;
  view3d.setWalk(next, {
    floors: state.floors, floorIndex: state.floorIndex, settings: state.settings
  });
  $("#walk-bar")?.classList.toggle("hidden", !next);
}

/* ---------- commands + voice ---------- */
function parseLenToFt(num, unit) {
  const n = parseFloat(num);
  if (!n) return 0;
  const u = (unit || "").toLowerCase();
  if (u.startsWith("m")) return n / 0.3048;
  if (u.startsWith("in")) return n / 12;
  return n; // feet default
}

function runCommand(text) {
  const raw = (text || "").trim();
  if (!raw) return;
  const s = raw.toLowerCase().replace(/[।.]/g, " ").replace(/\s+/g, " ").trim();

  const action = matchVoiceAction(raw);
  if (action && runAction(action, commandApi())) {
    const inp = $("#cmd");
    if (inp) inp.value = "";
    return;
  }

  if (/^(3d|three d)\s*(dikhao|dikhao|show)?$/.test(s) || /^show\s*3d$/.test(s)) {
    switchMode("3d");
    toast("3D");
    return;
  }
  if (/^(2d)\s*(dikhao|dikhao|show)?$/.test(s) || /^show\s*2d$/.test(s)) {
    switchMode("2d");
    toast("2D");
    return;
  }
  if (/^undo$/.test(s) || /^peeche\s*(karo)?$/.test(s)) {
    undo();
    toast("Undo");
    return;
  }
  if (/^redo$/.test(s)) {
    redo();
    toast("Redo");
    return;
  }
  if (/vastu\s*(dikhao|dikhao|show|on)/.test(s) || /^show\s*vastu$/.test(s)) {
    state.vastuOn = true;
    applyI18n();
    draw2d();
    persist();
    toast(t("vastuOn"));
    return;
  }
  if (/vastu\s*(hatao|hataao|hide|off|band)/.test(s) || /^hide\s*vastu$/.test(s)) {
    state.vastuOn = false;
    applyI18n();
    draw2d();
    persist();
    toast(t("vastuOff"));
    return;
  }

  let m = s.match(/^w\s*(\d+)\s*ko\s*([\d.]+)\s*(feet|foot|ft|meter|meters|metre|metres|m|inch|inches|in)?\s*karo$/i)
    || s.match(/^set\s*w\s*(\d+)\s*(to|ko)?\s*([\d.]+)\s*(feet|foot|ft|meter|meters|metre|metres|m|inch|inches|in)?$/i);
  if (m) {
    const id = "W" + m[1];
    const num = m[2] !== undefined && isNaN(parseFloat(m[2])) ? m[3] : m[2] || m[3];
    const unit = m[m.length - 1];
    // normalize groups
    const num2 = s.match(/([\d.]+)/)[1];
    const unit2 = (s.match(/(feet|foot|ft|meter|meters|metre|metres|m|inch|inches|in)/) || [])[1];
    if (setWallLength(id, parseLenToFt(num2, unit2))) {
      toast(id + " = " + fmtLen(parseLenToFt(num2, unit2)));
      const w = state.walls.find((x) => x.id === id);
      if (w) {
        state.selection = { type: "wall", id };
        openWallSheet(w);
      }
    } else toast(id + " nahi mila");
    void m; void num; void unit;
    return;
  }

  m = s.match(/^(w\s*\d+)\s*delete\s*karo$/) || s.match(/^delete\s*(w\s*\d+)$/) || s.match(/^(w\s*\d+)\s*(hatao|mitao|delete)$/);
  if (m) {
    const id = "W" + m[1].replace(/\D/g, "");
    if (deleteWall(id)) toast(id + " delete");
    else toast(id + " nahi mila");
    return;
  }

  // R1 ka naam Bedroom
  m = s.match(/^r\s*(\d+)\s*(ka\s*)?(naam|name)\s*(hai)?\s*(.+)$/) ||
      s.match(/^r\s*(\d+)\s*ko\s*(.+?)\s*(naam\s*)?(do|karo)?$/);
  if (m) {
    const id = "R" + m[1];
    const rm = state.rooms.find((x) => x.id.toUpperCase() === id);
    const rawM = raw.match(/r\s*\d+\s*(?:ka\s*)?(?:naam|name)\s*(?:hai)?\s*(.+)/i)
      || raw.match(/r\s*\d+\s*ko\s*(.+?)(?:\s*naam)?\s*(?:do|karo)?$/i);
    let name = (rawM && rawM[1] || "").trim();
    name = name.replace(/\s*(naam\s*)?(do|karo|hai)$/i, "").trim();
    if (rm && name) {
      pushUndo();
      rm.name = name;
      persist();
      state.selection = { type: "room", id: rm.id };
      openRoomSheet(rm);
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(rm.id + " = " + rm.name);
    } else toast(id + " nahi mila");
    return;
  }

  // W1 ka rang grey  / W1 andar se cream / W1 bahar se grey
  m = s.match(/^w\s*(\d+)\s*(andar|inside|bahar|outside|bahar)?\s*(se|ka|ki)?\s*(rang|color|colour)\s*(.+)$/) ||
      s.match(/^w\s*(\d+)\s*(ka|ki)\s*(rang|color|colour)\s*(.+)$/);
  if (m) {
    const id = "W" + m[1];
    const w = state.walls.find((x) => x.id.toUpperCase() === id);
    const side = (m[2] || "").toLowerCase();
    const colTok = (m[5] || m[4] || "").replace(/karo|kardo|set/g, "").trim();
    const hex = parseColorName(colTok);
    if (w && hex) {
      pushUndo();
      if (side === "andar" || side === "inside") w.colorIn = hex;
      else if (side === "bahar" || side === "outside") w.colorOut = hex;
      else { w.colorIn = hex; w.colorOut = hex; w.color = hex; }
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(id + " rang set");
    } else toast(hex ? id + " nahi mila" : "Rang samajh nahi aaya");
    return;
  }

  // R1 ke floor ka rang white
  m = s.match(/^r\s*(\d+)\s*(ke|ka|ki)?\s*(floor|fars|farsh)?\s*(ka|ki)?\s*(rang|color|colour)\s*(.+)$/);
  if (m) {
    const id = "R" + m[1];
    const rm = state.rooms.find((x) => x.id.toUpperCase() === id);
    const hex = parseColorName((m[6] || "").replace(/karo|kardo/g, "").trim());
    if (rm && hex) {
      pushUndo();
      rm.floorColor = hex;
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(id + " floor rang set");
    } else toast(id + " / rang nahi mila");
    return;
  }

  // window width / delete: K1 ko 4 feet chauda karo, K1 delete karo
  m = s.match(/^k\s*(\d+)\s*ko\s*([\d.]+)\s*(feet|foot|ft|meter|meters|m|inch|in)?\s*(chauda|wide|width)?\s*karo$/);
  if (m) {
    const id = "K" + m[1];
    const win = state.windows.find((x) => x.id.toUpperCase() === id);
    const ft = parseLenToFt(m[2], m[3]);
    if (win && ft > 0) {
      pushUndo();
      win.width = ft;
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(id + " = " + fmtLen(ft));
    } else toast(id + " nahi mila");
    return;
  }
  m = s.match(/^(k\s*\d+)\s*(delete\s*karo|hatao|mitao|delete)$/) || s.match(/^delete\s*(k\s*\d+)$/);
  if (m) {
    const id = "K" + (m[1] || m[2]).replace(/\D/g, "");
    const win = state.windows.find((x) => x.id.toUpperCase() === id);
    if (win) {
      pushUndo();
      state.windows = state.windows.filter((x) => x.id !== win.id);
      if (state.floors[state.floorIndex]) state.floors[state.floorIndex].windows = state.windows;
      closeSheet();
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(id + " delete");
    } else toast(id + " nahi mila");
    return;
  }

  // W4 mein 4 by 4 khidki
  m = s.match(/^w\s*(\d+)\s*(mein|me|par|pe)\s*([\d.]+)\s*(by|x|×)\s*([\d.]+)\s*(feet|ft|m)?\s*(khidki|window)$/);
  if (m) {
    const wall = state.walls.find((x) => x.id.toUpperCase() === "W" + m[1]);
    if (wall) {
      placeWindow(wall, 0.5);
      const k = state.windows[state.windows.length - 1];
      k.width = parseLenToFt(m[3], m[6]);
      k.height = parseLenToFt(m[5], m[6]);
      persist();
      draw2d();
      if (state.mode === "3d") refresh3d();
      toast(k.id + " " + wall.id + " par");
    } else toast("W" + m[1] + " nahi mila");
    return;
  }

  // wall angle: W3 ko 30 degree ghumao / W3 ka angle 120 degree
  m = s.match(/^w\s*(\d+)\s*(ko|ka|ki)?\s*([\d.]+)\s*(degree|deg|°)\s*(ghumao|rotate|ghumao)?$/)
    || s.match(/^w\s*(\d+)\s*(ko|ka|ki)?\s*(angle|kon|degree)\s*([\d.]+)\s*(degree|deg|°)?/);
  if (m) {
    const id = "W" + m[1];
    const nums = s.match(/[\d.]+/g) || [];
    const wall = state.walls.find((x) => x.id.toUpperCase() === id);
    const n = parseFloat(nums[nums.length - 1]);
    if (wall && !isNaN(n)) {
      if (/ghumao|rotate/.test(s)) setWallAngle(id, worldAngle(wall.x1, wall.y1, wall.x2, wall.y2) + n);
      else setWallAngle(id, n);
      state.selection = { type: "wall", id };
      openWallSheet(state.walls.find((x) => x.id === id) || wall);
      toast(id + " = " + Math.round(worldAngle(wall.x1, wall.y1, wall.x2, wall.y2)) + "°");
    } else toast(id + " nahi mila");
    return;
  }
  // 10 feet 45 degree par wall
  m = s.match(/^([\d.]+)\s*(feet|foot|ft|meter|metres|m|inch|in)?\s*([\d.]+)\s*(degree|deg|°)\s*(par|pe|at)?\s*(wall|deewar)?/);
  if (m) {
    const len = parseLenToFt(m[1], m[2]);
    const deg = parseFloat(m[3]);
    const start = state.measureStart || (state.walls.slice(-1)[0] ? { x: state.walls.slice(-1)[0].x2, y: state.walls.slice(-1)[0].y2 } : { x: 10, y: 10 });
    const p = pointAtAngle(start.x, start.y, deg, len);
    const w = addWall(start.x, start.y, p.x, p.y, "outer");
    if (w) { state.selection = { type: "wall", id: w.id }; openWallSheet(w); toast(w.id); }
    return;
  }
  m = s.match(/^(north|uttar)\s*([\d.]+)\s*(degree|deg|°)?/) || s.match(/^set\s*north\s*([\d.]+)/);
  if (m) {
    const n = parseFloat(m[2] || m[1]);
    if (!isNaN(n)) {
      pushUndo();
      state.northDeg = normDeg(n);
      persist();
      draw2d();
      toast("North " + Math.round(state.northDeg) + "°");
    }
    return;
  }

  // floors — unlimited + basements
  if (handleFloorCommand(s)) return;
  toast(t("unknown") + ": " + raw);
}

let recog = null;
function setupVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  $("#mic").addEventListener("click", () => {
    if (!SR) {
      toast(t("noSpeech"), 2500);
      $("#cmd").focus();
      return;
    }
    if (recog) {
      try { recog.stop(); } catch {}
      recog = null;
      $("#mic").classList.remove("on");
      return;
    }
    recog = new SR();
    recog.lang = speechLang();
    recog.interimResults = false;
    recog.continuous = false;
    $("#mic").classList.add("on");
    toast(t("listening"), 2500);
    recog.onresult = (e) => {
      const text = e.results[0][0].transcript;
      $("#cmd").value = text;
      runCommand(text);
    };
    recog.onend = () => {
      $("#mic").classList.remove("on");
      recog = null;
    };
    recog.onerror = () => {
      $("#mic").classList.remove("on");
      recog = null;
      toast(t("noSpeech"));
    };
    try { recog.start(); } catch { toast(t("noSpeech")); }
  });
}

/* ---------- export ---------- */
async function exportPng() {
  const src = $("#c2d");
  const was3d = state.mode === "3d";
  if (was3d) show2d();
  // render to a slightly larger offscreen canvas with watermark
  const out = document.createElement("canvas");
  const w = Math.max(src.clientWidth, 900);
  const h = Math.max(src.clientHeight, 1200);
  out.width = w * 2;
  out.height = h * 2;
  out.style.width = w + "px";
  out.style.height = h + "px";
  // temporarily draw using same view on offscreen — easier: copy current after redraw with watermark
  draw2d();
  const mark = state.settings?.watermark || "Bunty's";
  const tmp = document.createElement("canvas");
  tmp.width = src.width;
  tmp.height = src.height;
  tmp.style.width = src.style.width;
  tmp.style.height = (src.clientHeight || 1) + "px";
  // Use the on-screen canvas size
  const exportCanvas = document.createElement("canvas");
  exportCanvas.width = src.width;
  exportCanvas.height = src.height;
  const ectx = exportCanvas.getContext("2d");
  ectx.drawImage(src, 0, 0);
  // watermark in pixel space
  ectx.fillStyle = "rgba(30,24,16,0.38)";
  ectx.font = `600 ${Math.max(18, exportCanvas.width / 40)}px system-ui, sans-serif`;
  ectx.textAlign = "right";
  ectx.textBaseline = "bottom";
  ectx.fillText(mark, exportCanvas.width - 20, exportCanvas.height - 16);

  const blob = await new Promise((res) => exportCanvas.toBlob(res, "image/png"));
  if (!blob) return;
  const file = new File([blob], (state.project?.name || "naksha") + ".png", { type: "image/png" });
  try {
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: state.project?.name || "Naksha", text: mark });
      toast(t("copied"));
      return;
    }
  } catch (err) {
    if (err && err.name === "AbortError") return;
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = file.name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast(t("copied"));
}

async function exportPdf(paper) {
  const JSPDF = window.jspdf?.jsPDF;
  if (!JSPDF) { toast("PDF library nahi mili"); return; }
  const was3d = state.mode === "3d";
  if (was3d) show2d();
  const scale = state.settings?.scale || 100;
  const doc = new JSPDF({ orientation: "landscape", unit: "mm", format: paper === "a3" ? "a3" : "a4" });
  const pw = doc.internal.pageSize.getWidth();
  const ph = doc.internal.pageSize.getHeight();
  const margin = 12;
  const titleH = 24;
  const boxW = pw - margin * 2;
  const boxH = ph - margin * 2 - titleH;

  // world bounds
  let minX = 0, minY = 0, maxX = 20, maxY = 20;
  if (state.walls.length) {
    minX = minY = Infinity; maxX = maxY = -Infinity;
    for (const w of state.walls) {
      minX = Math.min(minX, w.x1, w.x2);
      minY = Math.min(minY, w.y1, w.y2);
      maxX = Math.max(maxX, w.x1, w.x2);
      maxY = Math.max(maxY, w.y1, w.y2);
    }
    minX -= 2; minY -= 2; maxX += 2; maxY += 2;
  }
  const worldW = Math.max(1, maxX - minX);
  const worldH = Math.max(1, maxY - minY);
  const mmPerFt = 304.8 / scale;
  let usedScale = scale;
  let drawW = worldW * mmPerFt, drawH = worldH * mmPerFt;
  if (drawW > boxW || drawH > boxH) {
    const fit = Math.max(worldW / boxW, worldH / boxH) * 304.8;
    usedScale = Math.ceil(fit / 5) * 5;
    drawW = worldW * (304.8 / usedScale);
    drawH = worldH * (304.8 / usedScale);
  }

  const src = $("#c2d");
  const cnv = document.createElement("canvas");
  const dpr = 2;
  const pxW = Math.max(800, Math.round(drawW * 8));
  const pxH = Math.max(600, Math.round(drawH * 8));
  cnv.width = pxW * dpr / 2 * 2; // keep simple
  cnv.height = pxH;
  // temporarily pan/zoom to fit bounds, draw, restore
  const saved = { ...state.view };
  const cssW = pxW, cssH = pxH;
  cnv.style.width = cssW + "px";
  cnv.style.height = cssH + "px";
  const zoom = Math.min(cssW / (worldW * PX), cssH / (worldH * PX));
  state.view.zoom = zoom;
  state.view.panX = -minX * zoom * PX;
  state.view.panY = -minY * zoom * PX;
  // draw2d uses clientWidth — override by passing canvas with width already set
  // Monkey: set properties via a temp attach? draw2d uses clientWidth which is 0 if not in DOM.
  // Use opts path: we'll draw manually onto cnv by temporarily appending.
  cnv.style.position = "fixed";
  cnv.style.left = "-9999px";
  document.body.appendChild(cnv);
  draw2d(cnv, { watermark: "" });
  document.body.removeChild(cnv);
  state.view = saved;
  draw2d();

  const img = cnv.toDataURL("image/png");
  const x0 = margin + (boxW - drawW) / 2;
  const y0 = margin;
  doc.setDrawColor(180);
  doc.rect(margin, margin, boxW, boxH);
  try { doc.addImage(img, "PNG", x0, y0, drawW, drawH); } catch (e) { console.warn(e); }

  const mark = state.settings?.watermark || "Bunty's";
  doc.setFontSize(28);
  doc.setTextColor(180, 170, 155);
  doc.text(mark, pw / 2, ph / 2, { align: "center", angle: 20 });

  const ty = ph - margin - 18;
  doc.setFillColor(245, 240, 230);
  doc.rect(margin, ph - margin - titleH, boxW, titleH, "F");
  doc.setDrawColor(80);
  doc.rect(margin, ph - margin - titleH, boxW, titleH);
  doc.setTextColor(30, 24, 16);
  doc.setFontSize(11);
  const proj = state.project?.name || "Naksha";
  const fl = floorName(state.floorIndex);
  const scTxt = usedScale === scale ? `1:${scale}` : `1:${usedScale} (fit, set 1:${scale})`;
  const date = new Date().toLocaleDateString("en-IN");
  doc.text(`${proj}  ·  ${fl}  ·  Scale ${scTxt}  ·  ${date}  ·  ${mark}`, margin + 4, ty);
  doc.setFontSize(8);
  doc.text("Naksha", pw - margin - 4, ty + 6, { align: "right" });

  const fname = (proj + "-" + fl + ".pdf").replace(/\s+/g, "_");
  doc.save(fname);
  toast(t("copied"));
}

/* ---------- boot ---------- */
function bindUI() {
  $("#login-btn").addEventListener("click", tryLogin);
  if(/[?&]demo=1/.test(location.search)){state.user="naksha_1dba71";localStorage.setItem("naksha_session",state.user);}
  const db=$("#demo-btn"); if(db) db.addEventListener("click",()=>{state.user="naksha_1dba71";localStorage.setItem("naksha_session",state.user);$("#login-err").textContent="";openHome();});
  $("#login-pass").addEventListener("keydown", (e) => {
    if (e.key === "Enter") tryLogin();
  });
  $("#login-user").addEventListener("keydown", (e) => {
    if (e.key === "Enter") $("#login-pass").focus();
  });
  $("#lang-btn").addEventListener("click", openLangPicker);
  $("#lang-btn-2").addEventListener("click", openLangPicker);
  $("#logout-btn").addEventListener("click", () => {
    persist();
    localStorage.removeItem("naksha_session");
    state.user = "naksha_1dba71";
    localStorage.setItem("naksha_session", state.user);
    openHome();
  });
  $("#new-btn").addEventListener("click", () => {
    fillFormDefaults();
    showScreen("screen-form");
    applyI18n();
  });
  $("#form-back").addEventListener("click", () => openHome());
  $("#form-go").addEventListener("click", newProjectFromForm);
  $$("#f-size").forEach(() => {});
  $$("#f-size button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#f-size button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
    })
  );
  $$("#f-units button").forEach((b) =>
    b.addEventListener("click", () => {
      $$("#f-units button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      onUnitsChange();
    })
  );
  $("#f-scale").addEventListener("change", () => {
    $("#f-scale-custom").classList.toggle("hidden", $("#f-scale").value !== "custom");
  });

  $("#ed-back").addEventListener("click", leaveEditor);
  $("#ed-2d3d").addEventListener("click", () => switchMode(state.mode === "2d" ? "3d" : "2d"));
  $("#ed-undo").addEventListener("click", undo);
  $("#ed-redo").addEventListener("click", redo);
  $("#ed-menu").addEventListener("click", (e) => {
    e.stopPropagation();
    $("#menu").classList.toggle("open");
  });
  document.addEventListener("click", (e) => {
    if (!$("#menu").contains(e.target) && e.target !== $("#ed-menu")) $("#menu").classList.remove("open");
  });
  $("#m-vastu").addEventListener("click", () => {
    state.vastuOn = !state.vastuOn;
    applyI18n();
    if (state.mode === "3d") show2d();
    draw2d();
    persist();
    $("#menu").classList.remove("open");
  });
  $("#m-north").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    openNorthSheet();
  });
  $("#m-export").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    exportPng();
  });
  $("#m-pdf-a4").addEventListener("click", () => { $("#menu").classList.remove("open"); exportPdf("a4"); });
  $("#m-pdf-a3").addEventListener("click", () => { $("#menu").classList.remove("open"); exportPdf("a3"); });
  $("#m-floor-add").addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(false); });
  $("#m-floor-copy").addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(true); });
  const mBase = $("#m-basement");
  if (mBase) mBase.addEventListener("click", () => { $("#menu").classList.remove("open"); addFloor(false, { basement: true }); });
  const bindMenu = (id, fn) => { const el = $(id); if (el) el.addEventListener("click", () => { $("#menu").classList.remove("open"); fn(); }); };
  bindMenu("#m-corners", () => { state.showCornerAngles = !state.showCornerAngles; persist(); draw2d(); toast(t("corners") + (state.showCornerAngles ? " on" : " off")); });
  bindMenu("#m-wallang", () => { state.showWallAngles = !state.showWallAngles; persist(); draw2d(); toast(t("wallAng") + (state.showWallAngles ? " on" : " off")); });
  bindMenu("#m-boq", () => showBoq());
  bindMenu("#m-dxf", () => exportDxf());
  bindMenu("#m-vreport", () => vastuReportPdf());
  bindMenu("#m-backup", () => backupJson());
  bindMenu("#m-restore", () => $("#restore-file")?.click());
  bindMenu("#m-roof", () => { state.roofOn = !state.roofOn; persist(); if (state.mode === "3d") refresh3d(); else switchMode("3d"); toast(t("roof") + (state.roofOn ? " on" : " off")); });
  bindMenu("#m-walk", () => toggleWalk());
  bindMenu("#m-sun", () => toggleSun(true));
  $("#restore-file")?.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) restoreJson(f);
    e.target.value = "";
  });
  $$("#snap-bar [data-snap]").forEach((b) => b.addEventListener("click", () => setSnap(b.dataset.snap)));
  setSnap(state.angleSnap);
  $$(".tmpl").forEach((b) => b.addEventListener("click", () => applyTemplate(b.dataset.tmpl)));
  $("#walk-exit")?.addEventListener("click", () => toggleWalk(false));
  $$("#walk-bar [data-w]").forEach((b) => b.addEventListener("click", () => {
    if (!view3d) return;
    const k = b.dataset.w;
    if (k === "l" || k === "r") view3d.lookWalk(k);
    else view3d.moveWalk(k);
  }));
  $("#sun-hour")?.addEventListener("input", (e) => {
    state.sunHour = parseFloat(e.target.value) || 10;
    const h = Math.floor(state.sunHour), m = Math.round((state.sunHour - h) * 60);
    const lab = $("#sun-lab"); if (lab) lab.textContent = String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
    if (state.mode === "3d") refresh3d();
  });
  $("#m-save").addEventListener("click", () => {
    persist();
    toast(t("saved"));
    $("#menu").classList.remove("open");
  });
  $("#m-lang").addEventListener("click", () => {
    $("#menu").classList.remove("open");
    openLangPicker();
  });
  const mImp = $("#m-import");
  if (mImp) mImp.addEventListener("click", () => { $("#menu").classList.remove("open"); openImport(); });
  const imp = $("#import-file");
  if (imp) imp.addEventListener("change", (e) => {
    const f = e.target.files && e.target.files[0];
    if (f) onImportFile(f);
    e.target.value = "";
  });

  $$("#tools [data-tool]").forEach((b) => b.addEventListener("click", () => setTool(b.dataset.tool)));
  $("#cmd-go").addEventListener("click", () => {
    runCommand($("#cmd").value);
  });
  $("#cmd").addEventListener("keydown", (e) => {
    if (e.key === "Enter") runCommand($("#cmd").value);
  });

  setupVoice();
  bindCanvas();

  addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
      e.preventDefault();
      if (e.shiftKey) redo();
      else undo();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
      e.preventDefault();
      redo();
    }
  });
}

async function boot() {
  const pref = localStorage.getItem("naksha_lang") || "hi";
  await initI18n(pref);
  state.lang = (currentLocale() && currentLocale().code) || pref;
  applyI18n();
  bindUI();
  if ("serviceWorker" in navigator) {
    try { await navigator.serviceWorker.register("./sw.js"); } catch {}
  }
  state.user = localStorage.getItem("naksha_session") || "naksha_1dba71";
  localStorage.setItem("naksha_session", state.user);
  openHome();
}

window.Naksha = { state, addWall, draw2d, switchMode, persist, setTool, runCommand, placeWindow, placeColumn, refreshRooms, addFloor, switchFloor, exportPdf, applyTemplate, showBoq, setSnap, openImport, openLangPicker, setVastu };
boot();
