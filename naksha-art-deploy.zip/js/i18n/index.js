/* Locale loader. Ship any world language as js/i18n/<bcp-47>.js and list it here.
   Adding a language = one new file + one code in LOCALES. */
export const LOCALES = ["en", "hi"];

const packs = new Map();
let current = null;
const fontLinks = [];

export async function initI18n(preferred) {
  packs.clear();
  for (const code of LOCALES) {
    try {
      const mod = await import("./" + code + ".js");
      const pack = mod.default;
      if (pack && pack.code) packs.set(pack.code, pack);
    } catch (err) {
      console.warn("locale failed", code, err);
    }
  }
  const want = preferred || "en";
  current = packs.get(want) || packs.get(want.split("-")[0]) || packs.get("en") || [...packs.values()][0];
  return current;
}

export function listLocales() {
  return [...packs.values()].map((p) => ({
    code: p.code,
    name: p.name,
    englishName: p.englishName,
    dir: p.dir || "ltr",
    speech: p.speech || p.code
  }));
}

export function currentLocale() {
  return current;
}

export function t(key) {
  if (!current) return key;
  const s = current.strings || {};
  if (s[key] != null) return s[key];
  const en = packs.get("en");
  if (en && en.strings && en.strings[key] != null) return en.strings[key];
  return key;
}

export function allPhrases() {
  // current locale first, then every other pack (so a command said in another
  // shipped language still matches after the user switches)
  const out = [];
  const seen = new Set();
  const add = (pack) => {
    if (!pack?.phrases) return;
    for (const [id, list] of Object.entries(pack.phrases)) {
      for (const p of list || []) {
        const n = normPhrase(p);
        if (!n || seen.has(id + "|" + n)) continue;
        seen.add(id + "|" + n);
        out.push({ id, phrase: n, locale: pack.code });
      }
    }
  };
  if (current) add(current);
  for (const p of packs.values()) if (p !== current) add(p);
  return out;
}

export function normPhrase(s) {
  return String(s || "")
    .toLowerCase()
    .normalize("NFKC")
    .replace(/[।.!?؟,，、]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function applyDocumentLocale(pack = current) {
  if (!pack || typeof document === "undefined") return;
  const html = document.documentElement;
  html.lang = pack.code;
  html.dir = pack.dir === "rtl" ? "rtl" : "ltr";
  html.classList.toggle("rtl", pack.dir === "rtl");
  loadLocaleFonts(pack);
}

function loadLocaleFonts(pack) {
  if (typeof document === "undefined") return;
  fontLinks.forEach((el) => el.remove());
  fontLinks.length = 0;
  for (const href of pack.fonts || []) {
    if (!href) continue;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    document.head.appendChild(link);
    fontLinks.push(link);
  }
}

export function setCurrent(code) {
  const pack = packs.get(code) || packs.get(String(code).split("-")[0]);
  if (!pack) return current;
  current = pack;
  applyDocumentLocale(pack);
  return current;
}

export function speechLang() {
  return (current && current.speech) || (current && current.code) || "en-US";
}
