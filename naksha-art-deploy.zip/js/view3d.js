import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

const FT = 1; // world units are feet

export class View3D {
  constructor(canvas) {
    this.canvas = canvas;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x1c2228);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 800);
    this.camera.position.set(18, 22, 28);
    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true;
    this.controls.target.set(10, 0, 10);
    this.group = new THREE.Group();
    this.scene.add(this.group);

    const hemi = new THREE.HemisphereLight(0xe8e0d0, 0x3a3530, 1.05);
    this.scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xfff3d8, 1.1);
    dir.position.set(20, 40, 12);
    this.sun = dir;
    this.scene.add(dir);
    this.walk = false;
    this._walkYaw = 0;
    this._walkEye = 5.2;
    const fill = new THREE.DirectionalLight(0x88a0b8, 0.35);
    fill.position.set(-20, 10, -10);
    this.scene.add(fill);

    this.ground = new THREE.Mesh(
      new THREE.PlaneGeometry(400, 400),
      new THREE.MeshStandardMaterial({ color: 0x3e4540, roughness: 1 })
    );
    this.ground.rotation.x = -Math.PI / 2;
    this.scene.add(this.ground);

    const grid = new THREE.GridHelper(200, 200, 0x555e55, 0x454c46);
    grid.position.y = 0.01;
    this.scene.add(grid);

    this.human = makeHuman();
    this.scene.add(this.human);

    this._running = false;
    this._raf = 0;
    this._onResize = () => this.resize();
  }

  resize() {
    const p = this.canvas.parentElement || this.canvas;
    const w = p.clientWidth || 1;
    const h = p.clientHeight || 1;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  show() {
    this.canvas.classList.remove("hidden");
    this.resize();
    this._running = true;
    cancelAnimationFrame(this._raf);
    const loop = () => {
      if (!this._running) return;
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
      this._raf = requestAnimationFrame(loop);
    };
    loop();
    addEventListener("resize", this._onResize);
  }

  hide() {
    this._running = false;
    cancelAnimationFrame(this._raf);
    this.canvas.classList.add("hidden");
    removeEventListener("resize", this._onResize);
  }

  build(data) {
    this.group.clear();
    const floorH = data.settings?.floorHeight ?? 10;
    const plinth = data.settings?.plinth ?? 2;
    const story = floorH + 0.85;
    const floors = (data.floors && data.floors.length)
      ? data.floors
      : [{ walls: data.walls || [], doors: data.doors || [], windows: data.windows || [], stairs: data.stairs || [], columns: data.columns || [], rooms: data.rooms || [] }];

    let union = null;
    let maxLevel = 0, minLevel = 0;
    let topFloor = floors[0];
    floors.forEach((f, i) => {
      const level = f.level != null ? f.level : i;
      if (level > maxLevel) { maxLevel = level; topFloor = f; }
      if (level < minLevel) minLevel = level;
      const y0 = plinth + level * story;
      const b = buildStorey(this.group, f, floorH, y0, data);
      if (b) union = union ? mergeB(union, b) : b;
    });

    const b = union || { minX: 0, minY: 0, maxY: 16, cx: 8, cy: 8, w: 16, h: 16 };
    if (data.roofOn && topFloor) {
      addRoof(this.group, topFloor, floorH, plinth + maxLevel * story, data);
    }
    this.setSun(data.sunHour ?? 10, data.northDeg ?? 0, data.sunOn);
    const stackH = plinth + (maxLevel + 1) * story;
    const minY = plinth + minLevel * story;
    this.human.position.set(b.cx, Math.max(0, plinth), b.maxY + 2.8);
    if (!this.walk) {
      this.controls.target.set(b.cx, (minY + stackH) * 0.4, b.cy);
      const dist = Math.max(20, Math.max(b.w, b.h, stackH - minY) * 1.5 + 16);
      this.camera.position.set(b.minX - dist * 0.25, minY + dist * 0.62, b.cy + dist * 0.75);
      this.controls.update();
    }
  }

  setSun(hour, northDeg, on) {
    if (!this.sun) return;
    const h = hour ?? 10;
    const t = Math.max(0, Math.min(1, (h - 6) / 12));
    const az = t * Math.PI;
    const alt = Math.sin(t * Math.PI) * 0.85 + 0.08;
    const r = 80;
    let x = Math.cos(az) * r * Math.cos(alt);
    let z = Math.sin(az) * r * Math.cos(alt);
    const y = r * Math.sin(alt);
    const th = ((northDeg || 0) * Math.PI) / 180;
    const x2 = x * Math.cos(th) - z * Math.sin(th);
    const z2 = x * Math.sin(th) + z * Math.cos(th);
    this.sun.position.set(x2, y, z2);
    this.sun.intensity = on === false ? 0.35 : 1.15;
    this.sun.visible = true;
  }

  setWalk(on, data) {
    this.walk = !!on;
    this.controls.enabled = !this.walk;
    if (!this.walk) return;
    const floors = data.floors || [];
    const f = floors[data.floorIndex] || floors[0] || {};
    const level = f.level != null ? f.level : (data.floorIndex || 0);
    const story = (data.settings?.floorHeight ?? 10) + 0.85;
    const y0 = (data.settings?.plinth ?? 2) + level * story;
    this._walkEye = y0 + 5.2;
    this._walkYaw = 0;
    let cx = 10, cy = 10;
    const w = (f.walls || [])[0];
    if (w) { cx = (w.x1 + w.x2) / 2; cy = (w.y1 + w.y2) / 2; }
    if (f.rooms && f.rooms[0]) { cx = f.rooms[0].cx; cy = f.rooms[0].cy; }
    this.camera.position.set(cx, this._walkEye, cy);
    this.camera.lookAt(cx, this._walkEye, cy + 4);
    this.controls.target.set(cx, this._walkEye, cy + 4);
  }
  moveWalk(dir) {
    if (!this.walk) return;
    const speed = 1.4;
    const yaw = this._walkYaw || 0;
    const fx = Math.sin(yaw), fz = Math.cos(yaw);
    if (dir === "f") { this.camera.position.x += fx * speed; this.camera.position.z += fz * speed; }
    if (dir === "b") { this.camera.position.x -= fx * speed; this.camera.position.z -= fz * speed; }
    this.camera.lookAt(
      this.camera.position.x + Math.sin(yaw),
      this._walkEye,
      this.camera.position.z + Math.cos(yaw)
    );
  }
  lookWalk(dir) {
    if (!this.walk) return;
    this._walkYaw = (this._walkYaw || 0) + (dir === "l" ? -0.28 : 0.28);
    const yaw = this._walkYaw;
    this.camera.lookAt(
      this.camera.position.x + Math.sin(yaw),
      this._walkEye,
      this.camera.position.z + Math.cos(yaw)
    );
  }
}

function mergeB(a, b) {
  const minX = Math.min(a.minX, b.minX), minY = Math.min(a.minY, b.minY);
  const maxX = Math.max(a.maxX, b.maxX), maxY = Math.max(a.maxY, b.maxY);
  return { minX, minY, maxX, maxY, w: maxX - minX, h: maxY - minY, cx: (minX + maxX) / 2, cy: (minY + maxY) / 2 };
}

function buildStorey(group, f, floorH, y0, data) {
  const walls = f.walls || [];
  const doors = f.doors || [];
  const windows = f.windows || [];
  const stairs = f.stairs || [];
  const columns = f.columns || [];
  const rooms = f.rooms || [];
  if (!walls.length && !columns.length) return null;
  const b = walls.length ? boundsOf(walls) : boundsOf(columns.map((c) => ({ x1: c.x, y1: c.y, x2: c.x, y2: c.y })));
  const pad = 2;
  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(b.w + pad * 2, 0.25, b.h + pad * 2),
    new THREE.MeshStandardMaterial({ color: 0x8a8680, roughness: 0.9 })
  );
  slab.position.set(b.cx, y0 - 0.12, b.cy);
  group.add(slab);

  for (const r of rooms) addRoomFloor(group, r, y0, data);
  for (const w of walls) {
    addWallWithOpenings(
      group, w,
      doors.filter((d) => d.wallId === w.id),
      windows.filter((k) => k.wallId === w.id),
      rooms, floorH, y0
    );
  }
  for (const s of stairs) addStair(group, s, floorH, y0);
  for (const c of columns) addColumn(group, c, floorH, y0);
  for (const fu of f.furniture || []) addFurniture(group, fu, y0);
  for (const m of f.mep || []) addMep(group, m, y0, floorH);
  return b;
}

function addRoomFloor(group, r, y0, data) {
  if (!r.poly || r.poly.length < 3) return;
  const shape = new THREE.Shape();
  r.poly.forEach((p, i) => i ? shape.lineTo(p.x, p.y) : shape.moveTo(p.x, p.y));
  shape.closePath();
  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  let col = r.floorColor || "#d9d1c3";
  if (data.vastuOn) {
    // tint is applied by caller via room.floorColor; keep room colour unless vastu overlay
    // (vastu fill is already in 2D; 3D uses floor colour so the paint choice stays visible)
  }
  const mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.95, metalness: 0 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = y0 + 0.02;
  group.add(mesh);
}

function addColumn(group, c, floorH, y0) {
  const h = c.height || floorH;
  const mat = new THREE.MeshStandardMaterial({ color: 0x6a645c, roughness: 0.8 });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(c.w || 0.75, h, c.d || 1), mat);
  mesh.position.set(c.x, y0 + h / 2, c.y);
  mesh.rotation.y = -((c.rot || 0) * Math.PI) / 180;
  group.add(mesh);
}

function wallFaceMats(wall, rooms) {
  const out = new THREE.Color(wall.colorOut || wall.color || "#2c3d4f");
  const inn = new THREE.Color(wall.colorIn || wall.color || "#2c3d4f");
  const mOut = new THREE.MeshStandardMaterial({ color: out, roughness: 0.85, metalness: 0.02 });
  const mIn = new THREE.MeshStandardMaterial({ color: inn, roughness: 0.85, metalness: 0.02 });
  const edge = mOut;
  // +Z is left of start→end. If left is inside a room, +Z gets inside colour.
  const leftIn = leftInside(wall, rooms);
  const pz = leftIn ? mIn : mOut;
  const nz = leftIn ? mOut : mIn;
  return [edge, edge, mOut, mOut, pz, nz];
}

function leftInside(wall, rooms) {
  if (!rooms || !rooms.length) return false;
  const dx = wall.x2 - wall.x1, dy = wall.y2 - wall.y1;
  const len = Math.hypot(dx, dy) || 1;
  const mx = (wall.x1 + wall.x2) / 2, my = (wall.y1 + wall.y2) / 2;
  const lx = mx + (-dy / len) * 0.4, ly = my + (dx / len) * 0.4;
  return rooms.some((r) => r.poly && pointInPoly3(lx, ly, r.poly));
}

function pointInPoly3(x, y, pts) {
  let inr = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
    const hit = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-12) + xi;
    if (hit) inr = !inr;
  }
  return inr;
}

function boundsOf(walls) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const w of walls) {
    minX = Math.min(minX, w.x1, w.x2);
    minY = Math.min(minY, w.y1, w.y2);
    maxX = Math.max(maxX, w.x1, w.x2);
    maxY = Math.max(maxY, w.y1, w.y2);
  }
  return { minX, minY, maxX, maxY, w: maxX - minX, h: maxY - minY, cx: (minX + maxX) / 2, cy: (minY + maxY) / 2 };
}

function addWallWithOpenings(group, wall, doors, windows, rooms, floorH, y0) {
  const dx = wall.x2 - wall.x1, dy = wall.y2 - wall.y1;
  const len = Math.hypot(dx, dy);
  if (len < 0.05) return;
  const rotY = -Math.atan2(dy, dx);
  const th = wall.thickness || 0.75;
  const h = wall.height || floorH;
  const mats = wallFaceMats(wall, rooms);
  const holes = [];
  for (const d of doors || []) {
    const mid = (d.t ?? 0.5) * len;
    const half = (d.width || 3) / 2;
    holes.push({ a: Math.max(0, mid - half), b: Math.min(len, mid + half), z0: 0, z1: Math.min(d.height || 7, h) });
  }
  for (const k of windows || []) {
    const mid = (k.t ?? 0.5) * len;
    const half = (k.width || 4) / 2;
    const z0 = Math.max(0, k.sill || 3);
    const z1 = Math.min(h, z0 + (k.height || 4));
    holes.push({ a: Math.max(0, mid - half), b: Math.min(len, mid + half), z0, z1 });
  }
  const clean = holes.filter((x) => x.b > x.a + 0.05 && x.z1 > x.z0 + 0.05).sort((a, b) => a.a - b.a);

  const cuts = [0];
  for (const ho of clean) { cuts.push(ho.a, ho.b); }
  cuts.push(len);
  const xs = [...new Set(cuts.map((v) => Math.round(v * 1000) / 1000))].sort((a, b) => a - b);

  const ux = dx / len, uy = dy / len;
  function addBox(a, b, yb, yt) {
    const sl = b - a, hh = yt - yb;
    if (sl < 0.03 || hh < 0.06) return;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(sl, hh, th), mats);
    const mid = a + sl / 2;
    mesh.position.set(wall.x1 + ux * mid, y0 + yb + hh / 2, wall.y1 + uy * mid);
    mesh.rotation.y = rotY;
    group.add(mesh);
  }
  for (let i = 0; i < xs.length - 1; i++) {
    const a = xs[i], b = xs[i + 1];
    const here = clean.filter((ho) => ho.a < b - 0.01 && ho.b > a + 0.01);
    if (!here.length) {
      addBox(a, b, 0, h);
      continue;
    }
    const bands = here.map((ho) => [ho.z0, ho.z1]).sort((p, q) => p[0] - q[0]);
    let y = 0;
    for (const [z0, z1] of bands) {
      if (z0 > y + 0.05) addBox(a, b, y, z0);
      y = Math.max(y, z1);
    }
    if (h > y + 0.05) addBox(a, b, y, h);
  }
}

function addStair(group, s, floorH, plinth) {
  const riser = s.riser || 0.5;
  const tread = s.tread || 0.83;
  const steps = s.steps || Math.max(2, Math.round(floorH / riser));
  const width = s.width || 3;
  const type = s.type || "straight";
  const mat = new THREE.MeshStandardMaterial({ color: 0x9a8b76, roughness: 0.8 });
  const rot = ((s.rot || 0) * Math.PI) / 180;
  const root = new THREE.Group();
  root.position.set(s.x, plinth, s.y);
  root.rotation.y = -rot;

  const makeRun = (n, ox, oz, dirX, dirZ) => {
    for (let i = 0; i < n; i++) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, riser * 0.92, tread), mat);
      const along = i * tread + tread / 2;
      mesh.position.set(ox + dirX * along, riser * (i + 0.5), oz + dirZ * along);
      root.add(mesh);
    }
  };

  if (type === "straight") {
    makeRun(steps, 0, 0, 0, 1);
  } else if (type === "L") {
    const a = Math.ceil(steps / 2), b = steps - a;
    makeRun(a, 0, 0, 0, 1);
    const oz = a * tread;
    const yOff = a * riser;
    for (let i = 0; i < b; i++) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(tread, riser * 0.92, width), mat);
      mesh.position.set(i * tread + tread / 2, yOff + riser * (i + 0.5), oz + width / 2 - tread / 2);
      root.add(mesh);
    }
  } else if (type === "spiral") {
    const radius = Math.max(1.5, width * 0.7);
    for (let i = 0; i < steps; i++) {
      const ang = i * (Math.PI / 6);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(width * 0.55, riser * 0.92, tread), mat);
      mesh.position.set(Math.sin(ang) * radius, riser * (i + 0.5), Math.cos(ang) * radius);
      mesh.rotation.y = -ang;
      root.add(mesh);
    }
  } else {
    // U
    const a = Math.ceil(steps / 3), b = Math.ceil((steps - a) / 2), c = steps - a - b;
    makeRun(a, 0, 0, 0, 1);
    const oz = a * tread;
    const yOff = a * riser;
    for (let i = 0; i < b; i++) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(tread, riser * 0.92, width), mat);
      mesh.position.set(i * tread + tread / 2, yOff + riser * (i + 0.5), oz + width / 2 - tread / 2);
      root.add(mesh);
    }
    const ox = b * tread;
    const yOff2 = yOff + b * riser;
    for (let i = 0; i < c; i++) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, riser * 0.92, tread), mat);
      mesh.position.set(ox + width / 2 - tread / 2, yOff2 + riser * (i + 0.5), oz - i * tread - tread / 2);
      root.add(mesh);
    }
  }
  group.add(root);
}

function addFurniture(group, f, y0) {
  const pal = { bed: 0x6b4a2b, sofa: 0x3d5a7a, dining: 0x8a7348, kitchen: 0x7a6a58, wc: 0xd0d4d8, basin: 0xe8e4dc, wardrobe: 0x5c4030, chair: 0x4a4038 };
  const w = f.w || 6, d = f.d || 6, h = f.kind === "wardrobe" ? 7 : 2.2;
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({ color: pal[f.kind] || 0x6b4a2b, roughness: 0.8 })
  );
  mesh.position.set(f.x, y0 + h / 2, f.y);
  mesh.rotation.y = -((f.rot || 0) * Math.PI) / 180;
  group.add(mesh);
}
function addMep(group, m, y0, floorH) {
  const isP = /drain|water|shower/.test(m.kind || "");
  const y = isP ? y0 + 0.15 : y0 + (floorH || 10) - 0.15;
  const col = isP ? 0x3a6a9a : 0xe8c547;
  const mesh = new THREE.Mesh(
    isP ? new THREE.BoxGeometry(0.4, 0.2, 0.4) : new THREE.SphereGeometry(0.25, 10, 8),
    new THREE.MeshStandardMaterial({ color: col, emissive: isP ? 0x000000 : 0x665210, roughness: 0.5 })
  );
  mesh.position.set(m.x, y, m.y);
  group.add(mesh);
}
function addRoof(group, f, floorH, y0, data) {
  const walls = f.walls || [];
  if (!walls.length) return;
  const b = boundsOf(walls);
  const y = y0 + floorH + 0.15;
  const slab = new THREE.Mesh(
    new THREE.BoxGeometry(b.w + 1.2, 0.35, b.h + 1.2),
    new THREE.MeshStandardMaterial({ color: 0x8a8680, roughness: 0.9 })
  );
  slab.position.set(b.cx, y, b.cy);
  group.add(slab);
  const paraH = 2.5;
  const mat = new THREE.MeshStandardMaterial({ color: 0x9a9590, roughness: 0.85 });
  const thick = 0.4;
  const edges = [
    [b.cx, b.minY - 0.4, b.w + 1.2, thick],
    [b.cx, b.maxY + 0.4, b.w + 1.2, thick],
    [b.minX - 0.4, b.cy, thick, b.h + 1.2],
    [b.maxX + 0.4, b.cy, thick, b.h + 1.2]
  ];
  for (const [x, z, sx, sz] of edges) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(sx, paraH, sz), mat);
    m.position.set(x, y + paraH / 2, z);
    group.add(m);
  }
}

function makeHuman() {
  // ~5'8" = 5.667 ft
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xc4a882, roughness: 0.7 });
  const cloth = new THREE.MeshStandardMaterial({ color: 0x3d5a7a, roughness: 0.8 });
  const pants = new THREE.MeshStandardMaterial({ color: 0x2c3340, roughness: 0.85 });
  const add = (geo, mat, x, y, z) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  // body centered so feet at y=0
  // Standing height ~5.67 ft (5'8")
  add(new THREE.BoxGeometry(0.16, 2.45, 0.16), pants, -0.12, 2.45 / 2, 0);
  add(new THREE.BoxGeometry(0.16, 2.45, 0.16), pants, 0.12, 2.45 / 2, 0);
  add(new THREE.BoxGeometry(0.42, 0.45, 0.28), pants, 0, 2.45 + 0.22, 0);
  add(new THREE.BoxGeometry(0.50, 2.05, 0.30), cloth, 0, 2.90 + 2.05 / 2, 0);
  add(new THREE.SphereGeometry(0.32, 12, 10), skin, 0, 4.95 + 0.36, 0);
  add(new THREE.BoxGeometry(0.14, 1.85, 0.14), skin, -0.36, 2.95 + 1.85 / 2, 0);
  add(new THREE.BoxGeometry(0.14, 1.85, 0.14), skin, 0.36, 2.95 + 1.85 / 2, 0);
  return g;
}
