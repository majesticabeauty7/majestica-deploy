/* Templates, furniture, MEP, BOQ, DXF, floor names — used by app.js */

export const FURNITURE = {
  bed: { name: "Bed", w: 6, d: 6.5, h: 2, color: "#6b4a2b" },
  sofa: { name: "Sofa", w: 6, d: 3, h: 2.5, color: "#3d5a7a" },
  dining: { name: "Dining", w: 5, d: 3, h: 2.5, color: "#8a7348" },
  kitchen: { name: "Kitchen", w: 8, d: 2, h: 2.8, color: "#7a6a58" },
  wc: { name: "WC", w: 1.8, d: 2.2, h: 1.4, color: "#d0d4d8" },
  basin: { name: "Basin", w: 2, d: 1.5, h: 2.6, color: "#e8e4dc" },
  wardrobe: { name: "Wardrobe", w: 4, d: 2, h: 7, color: "#5c4030" },
  chair: { name: "Chair", w: 1.6, d: 1.6, h: 3, color: "#4a4038" }
};

export const MEP = {
  light: { name: "Light", kind: "e", color: "#e8c547" },
  fan: { name: "Fan", kind: "e", color: "#6a8aaa" },
  ac: { name: "AC", kind: "e", color: "#7aa0b8" },
  switch: { name: "Switch", kind: "e", color: "#c9a227" },
  socket: { name: "Socket", kind: "e", color: "#c9a227" },
  drain: { name: "Drain", kind: "p", color: "#5a7a4a" },
  water: { name: "Water", kind: "p", color: "#3a6a9a" },
  shower: { name: "Shower", kind: "p", color: "#4a8aaa" }
};

const ORDS = {
  ground: 0, gf: 0,
  first: 1, "1st": 1, pehli: 1, pehla: 1, pehle: 1,
  second: 2, "2nd": 2, dusri: 2, dusra: 2, doosri: 2, doosra: 2, doosre: 2,
  third: 3, "3rd": 3, tisri: 3, teesri: 3, teesra: 3, tisra: 3, teesre: 3,
  fourth: 4, "4th": 4, chauthi: 4, chautha: 4, chauthe: 4,
  fifth: 5, "5th": 5, panchvi: 5, panchwen: 5, panchwa: 5,
  sixth: 6, "6th": 6, chhathi: 6, chhatha: 6,
  seventh: 7, "7th": 7, satvin: 7, satwi: 7,
  eighth: 8, "8th": 8, aathvin: 8,
  ninth: 9, "9th": 9, nauvin: 9,
  tenth: 10, "10th": 10, dasvin: 10
};

function ordinalIn(t) {
  for (const [k, v] of Object.entries(ORDS)) {
    if (k.length < 3 && t !== k) continue;
    if (t === k) return v;
    const re = new RegExp("(^|[^a-z0-9])" + k + "([^a-z]|$)", "i");
    if (re.test(t)) return v;
  }
  return null;
}

export function parseFloorLevel(s) {
  const t = (s || "").toLowerCase().replace(/[।.]/g, " ").replace(/\s+/g, " ").trim();
  if (!t) return null;
  const isBase = /\b(basement|cellar|talaghar|tala)\b/.test(t) || /\bb\d+\b/.test(t);
  const bm = t.match(/\bb(?:asement)?\s*[-]?\s*(\d+)\b/) || t.match(/\btala(?:ghar)?\s*(\d+)\b/);
  if (isBase) {
    if (bm) return -Math.max(1, parseInt(bm[1], 10));
    const ord = ordinalIn(t);
    if (ord && ord > 0) return -ord;
    return -1;
  }
  if (/\b(ground|gf)\b/.test(t) || /(?:^|\s)g(?:\s|$)/.test(t)) return 0;
  for (const [k, v] of Object.entries(ORDS)) {
    const re = new RegExp("(^|[^a-z0-9])" + k.replace(/[0-9]/g, (d) => d) + "([^a-z]|$)", "i");
    if (re.test(t) && (/\b(floor|manzil|storey|story)\b/.test(t) || ORDS[t] != null || t === k)) return v;
  }
  // "3 floor", "floor 3", "3rd floor", "teesri manzil"
  for (const [k, v] of Object.entries(ORDS)) {
    if (k.length < 3) continue;
    if (t.includes(k) && /\b(floor|manzil|storey|story)\b/.test(t)) return v;
  }
  const m = t.match(/\b(?:floor|manzil|storey|story)\s*(\d+)\b/) || t.match(/\b(\d+)\s*(?:floor|manzil|storey|story)\b/);
  if (m) return parseInt(m[1], 10);
  if (/^(g|gf|ground)$/.test(t)) return 0;
  return null;
}

export function defaultFloorName(level) {
  if (level === 0) return "Ground";
  if (level < 0) return "B" + Math.abs(level);
  return "Floor " + level;
}

export function shortFloorName(level) {
  if (level === 0) return "G";
  if (level < 0) return "B" + Math.abs(level);
  return String(level);
}

function W(x1, y1, x2, y2, type = "outer") {
  return { x1, y1, x2, y2, type };
}

export const TEMPLATES = {
  "1bhk": {
    name: "1BHK",
    plot: { w: 20, d: 30, front: 3, back: 3, left: 2, right: 2 },
    walls: [
      W(5, 5, 25, 5), W(25, 5, 25, 35), W(25, 35, 5, 35), W(5, 35, 5, 5),
      W(5, 20, 16, 20, "partition"), W(16, 5, 16, 20, "partition"),
      W(16, 27, 25, 27, "partition"), W(16, 20, 16, 27, "partition")
    ],
    doors: [{ wall: 0, t: 0.35, width: 3 }, { wall: 4, t: 0.6, width: 2.75 }, { wall: 6, t: 0.45, width: 2.5 }],
    rooms: [
      { cx: 10.5, cy: 12.5, name: "Bedroom" },
      { cx: 20.5, cy: 23.5, name: "Kitchen" },
      { cx: 15, cy: 28, name: "Living" }
    ]
  },
  "2bhk": {
    name: "2BHK",
    plot: { w: 30, d: 40, front: 5, back: 3, left: 3, right: 3 },
    walls: [
      W(6, 6, 30, 6), W(30, 6, 30, 40), W(30, 40, 6, 40), W(6, 40, 6, 6),
      W(6, 22, 18, 22, "partition"), W(18, 6, 18, 22, "partition"),
      W(18, 28, 30, 28, "partition"), W(18, 22, 18, 40, "partition"),
      W(6, 32, 18, 32, "partition")
    ],
    doors: [
      { wall: 0, t: 0.4, width: 3.5 }, { wall: 4, t: 0.55, width: 2.75 },
      { wall: 6, t: 0.4, width: 2.75 }, { wall: 8, t: 0.4, width: 2.5 }
    ],
    rooms: [
      { cx: 12, cy: 14, name: "Bedroom" },
      { cx: 12, cy: 36, name: "Bedroom" },
      { cx: 24, cy: 17, name: "Living" },
      { cx: 24, cy: 34, name: "Kitchen" }
    ]
  },
  "3bhk": {
    name: "3BHK",
    plot: { w: 30, d: 50, front: 5, back: 4, left: 3, right: 3 },
    walls: [
      W(5, 5, 32, 5), W(32, 5, 32, 48), W(32, 48, 5, 48), W(5, 48, 5, 5),
      W(5, 20, 18, 20, "partition"), W(18, 5, 18, 20, "partition"),
      W(18, 32, 32, 32, "partition"), W(18, 20, 18, 48, "partition"),
      W(5, 34, 18, 34, "partition"),
      W(24, 32, 24, 48, "partition")
    ],
    doors: [
      { wall: 0, t: 0.45, width: 3.5 }, { wall: 4, t: 0.5, width: 2.75 },
      { wall: 6, t: 0.35, width: 2.75 }, { wall: 8, t: 0.4, width: 2.5 }, { wall: 9, t: 0.35, width: 2.5 }
    ],
    rooms: [
      { cx: 11.5, cy: 12.5, name: "Master Bedroom" },
      { cx: 11.5, cy: 41, name: "Bedroom" },
      { cx: 25, cy: 18, name: "Living" },
      { cx: 21, cy: 40, name: "Kitchen" },
      { cx: 28, cy: 40, name: "Bedroom" }
    ]
  },
  shop: {
    name: "Dukaan",
    plot: { w: 15, d: 30, front: 0, back: 3, left: 0, right: 0 },
    walls: [
      W(4, 4, 18, 4), W(18, 4, 18, 28), W(18, 28, 4, 28), W(4, 28, 4, 4),
      W(4, 22, 18, 22, "partition")
    ],
    doors: [{ wall: 0, t: 0.5, width: 5 }, { wall: 4, t: 0.5, width: 2.75 }],
    rooms: [
      { cx: 11, cy: 13, name: "Shop" },
      { cx: 11, cy: 25, name: "Store" }
    ]
  }
};

export function boqFor(floors, settings) {
  const fh = settings?.floorHeight || 10;
  let wallLen = 0, wallArea = 0, wallVol = 0, openArea = 0, plaster = 0, stairVol = 0;
  let outerLen = 0, partLen = 0;
  for (const f of floors || []) {
    for (const w of f.walls || []) {
      const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
      const h = w.height || fh;
      const th = w.thickness || 0.75;
      wallLen += L;
      wallArea += L * h;
      wallVol += L * h * th;
      plaster += L * h * 2;
      if (w.type === "partition") partLen += L;
      else outerLen += L;
    }
    for (const d of f.doors || []) openArea += (d.width || 3) * (d.height || 7);
    for (const k of f.windows || []) openArea += (k.width || 4) * (k.height || 4);
    for (const s of f.stairs || []) {
      const riser = s.riser || 0.5, tread = s.tread || 0.83, steps = s.steps || 16, width = s.width || 3;
      stairVol += steps * tread * width * riser;
    }
  }
  const netWall = Math.max(0, wallArea - openArea);
  const avgTh = wallArea ? wallVol / wallArea : 0.75;
  const brickN = Math.round(netWall * 10 * (avgTh / 0.75));
  const cementBags = +(netWall * 0.18 + plaster * 0.11 + stairVol * 0.4).toFixed(1);
  const sandCuft = +((netWall * 0.18 + plaster * 0.11) * 5 + stairVol * 2).toFixed(1);
  const concreteCuft = +(openArea * 0.75 * 0.75 + stairVol).toFixed(1);
  const steelKg = +(concreteCuft * 1.2).toFixed(0);
  return {
    floors: (floors || []).length,
    outerLen, partLen, wallLen, wallArea: netWall, openArea, plaster,
    bricks: brickN, cementBags, sandCuft, concreteCuft, steelKg, stairVol
  };
}

export function toDxf(floors) {
  let ents = "";
  const ent = (type, body) => {
    ents += `0\n${type}\n8\nNAKSHA\n${body}`;
  };
  (floors || []).forEach((f, fi) => {
    const z = (f.level ?? fi) * 11;
    for (const w of f.walls || []) {
      ent("LINE", `10\n${w.x1}\n20\n${-w.y1}\n30\n${z}\n11\n${w.x2}\n21\n${-w.y2}\n31\n${z}\n`);
    }
    for (const c of f.columns || []) {
      const r = Math.max(c.w || 0.75, c.d || 1) / 2;
      ent("CIRCLE", `10\n${c.x}\n20\n${-c.y}\n30\n${z}\n40\n${r}\n`);
    }
  });
  return `0\nSECTION\n2\nHEADER\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n${ents}0\nENDSEC\n0\nEOF\n`;
}
