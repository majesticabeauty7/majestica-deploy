/* Every app action has an id. Voice phrases live in each locale file under `phrases`.
 * Parameterized commands (W1 ko 12 feet, third floor par jao, …) stay in app.js. */
import { allPhrases, normPhrase } from "./i18n/index.js";

export function matchVoiceAction(text) {
  const n = normPhrase(text);
  if (!n) return null;
  const list = allPhrases();
  // exact first, then starts-with / equals ignoring filler words
  for (const p of list) {
    if (p.phrase === n) return p.id;
  }
  for (const p of list) {
    if (n === p.phrase + " karo" || n === p.phrase + " karein" || n === "please " + p.phrase) return p.id;
  }
  // Allow a trailing filler ("karo", "please") but do not prefix-match,
  // so "north 15 degree" is not stolen by the phrase "north".
  const fillers = [" karo", " karein", " kardo", " please", " now"];
  for (const p of list) {
    for (const f of fillers) {
      if (n === p.phrase + f) return p.id;
    }
  }
  return null;
}

export function runAction(id, api) {
  const fn = ACTIONS[id];
  if (!fn) return false;
  fn(api);
  return true;
}

const ACTIONS = {
  show3d: (api) => { api.switchMode("3d"); api.toast("3D"); },
  show2d: (api) => { api.switchMode("2d"); api.toast("2D"); },
  undo: (api) => { api.undo(); api.toast("Undo"); },
  redo: (api) => { api.redo(); api.toast("Redo"); },
  vastuOn: (api) => api.setVastu(true),
  vastuOff: (api) => api.setVastu(false),
  setNorth: (api) => api.openNorthSheet(),
  corners: (api) => api.toggleCorners(),
  wallAng: (api) => api.toggleWallAng(),
  boq: (api) => api.showBoq(),
  dxf: (api) => api.exportDxf(),
  vReport: (api) => api.vastuReportPdf(),
  backup: (api) => api.backupJson(),
  restore: (api) => api.openRestore(),
  roof: (api) => api.toggleRoof(),
  walk: (api) => api.toggleWalk(true),
  walkOff: (api) => api.toggleWalk(false),
  sun: (api) => api.toggleSun(true),
  exportPng: (api) => api.exportPng(),
  pdfA4: (api) => api.exportPdf("a4"),
  pdfA3: (api) => api.exportPdf("a3"),
  addFloor: (api) => api.addFloor(false),
  copyFloor: (api) => api.addFloor(true),
  addBasement: (api) => api.addFloor(false, { basement: true }),
  save: (api) => { api.persist(); api.toast(api.t("saved")); },
  language: (api) => api.openLangPicker(),
  select: (api) => api.setTool("select"),
  outer: (api) => api.setTool("outer"),
  partition: (api) => api.setTool("partition"),
  measure: (api) => api.setTool("measure"),
  door: (api) => api.setTool("door"),
  window: (api) => api.setTool("window"),
  column: (api) => api.setTool("column"),
  stair: (api) => api.setTool("stair"),
  furniture: (api) => api.setTool("furniture"),
  mep: (api) => api.setTool("mep"),
  importDraw: (api) => api.openImport(),
  snapOff: (api) => api.setSnap(0),
  snap15: (api) => api.setSnap(15),
  snap45: (api) => api.setSnap(45),
  snap90: (api) => api.setSnap(90)
};

export { ACTIONS };
