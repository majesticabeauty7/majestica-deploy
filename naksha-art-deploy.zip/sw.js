const CACHE = "naksha-v9";
const ASSETS = [
  "./",
  "./index.html",
  "./css/style.css",
  "./js/app.js",
  "./js/view3d.js",
  "./js/extra.js",
  "./js/more.js",
  "./js/i18n/hi.js",
  "./js/i18n/en.js",
  "./js/i18n/index.js",
  "./js/importPlan.js",
  "./js/commands.js",
  "./vendor/jspdf.umd.min.js",
  "./vendor/three.module.min.js",
  "./vendor/addons/controls/OrbitControls.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/apple-touch-icon.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (/DEMO_CREDENTIALS/i.test(url.pathname)) {
    e.respondWith(new Response("Not found", { status: 404 }));
    return;
  }
  if (e.request.method !== "GET") return;
  e.respondWith(
    fetch(e.request).then((res) => {
      if (res.ok && url.origin === location.origin) {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
      }
      return res;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || caches.match("./index.html")))
  );
});
