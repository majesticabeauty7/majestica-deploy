#!/usr/bin/env bash
# STAGE 2 - upgrade the salon app = re-run bootstrap with the new bundle (same as every earlier release).
#   bash stage2-app-upgrade.sh <INSTALL_SH_URL>      (asks for the bundle passphrase, hidden)
# bootstrap: keeps .env/secrets/FIELD_ENC_KEY, adds VAPID+CRON_SECRET, npm ci, prisma db push (additive), db:upgrade,
# clean build, restarts "majestica", rewrites the nginx snippet (Permissions-Policy camera=(self) geolocation=(self)).
# Demo data is NOT re-seeded (.seeded marker). Full log: /var/log/majestica-bootstrap.log
. "$(dirname "$0")/common.sh"
URL="${1:?usage: stage2-app-upgrade.sh <INSTALL_SH_URL>}"
ls -d /var/backups/majestica-predeploy-* >/dev/null 2>&1 || die "run stage1-backup.sh first"
curl -fsSL "$URL" -o /root/majestica-install.sh || die "cannot download installer (temporary link expired?)"
bash -n /root/majestica-install.sh || die "installer is not a valid script"
bash /root/majestica-install.sh
say "verify"
systemctl is-active --quiet majestica && ok "majestica active" || die "majestica not active: journalctl -u majestica -n 50"
h() { curl -s -o /dev/null -w '%{http_code}' --max-time 10 "https://$APPHOST$1"; }
pp="$(curl -sI --max-time 10 https://$APPHOST/login | tr -d '\r' | sed -n 's/^Permissions-Policy: //Ip')"
[[ "$pp" == *"camera=(self)"* && "$pp" == *"geolocation=(self)"* ]] && ok "Permissions-Policy: $pp" || warn "Permissions-Policy is '$pp' (expected camera=(self) geolocation=(self))"
[[ "$(h /login)" == 200 ]] && ok "/login 200" || warn "/login $(h /login)"
[[ "$(h /staff-app)" =~ ^(200|30[78])$ ]] && ok "/staff-app $(h /staff-app)" || warn "/staff-app $(h /staff-app)"
curl -fsS --max-time 10 "https://$APPHOST/.well-known/assetlinks.json" | grep -q com.majesticadigital.staff && ok "assetlinks.json serves com.majesticadigital.staff" || warn "assetlinks.json not served"
for k in VAPID_PUBLIC_KEY VAPID_PRIVATE_KEY CRON_SECRET FIELD_ENC_KEY; do grep -q "^$k=." /opt/majestica/.env && ok ".env has $k" || warn ".env missing $k"; done
journalctl -u majestica --since "-3 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
rm -f /root/majestica-install.sh
