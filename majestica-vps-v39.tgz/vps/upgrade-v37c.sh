#!/usr/bin/env bash
# ONE-COMMAND combined upgrade v3.7c (app) + v3.7b/v3.7c (website). No reboot unless --reboot.
#  App v3.7c: country code next to every mobile field (E.164 storage, old 10-digit numbers become +91, login with or without +91),
#             SMS only for +91 numbers (others: email), USD billing for salons outside India ($69 Multi Store, extra branch $17),
#             extra branch ₹1,249, new login brand panel, Country / State on free demos, Terms checkbox,
#             data-retention reminder emails + auto-delete job (daily systemd timer; deletion is a DRY RUN unless --enable-auto-delete).
#  Website:   v3.7b (FAQ page, Bulk SMS & Email product, tagline, social icons, Terms with Payment Terms, Privacy, Refund page)
#             + v3.7c (country code + Country / State on /request, ₹ INR / $ USD price switch, USD + data policy text).
#  Steps: 1 backup  2 app  3 email (--skip-smtp keeps .env)  4 data-retention timer  5 website + content  6 optional demo reset  7 verify
#  Options: --skip-smtp --skip-site --keep-pass --ecdh <PUB> <CT> --enable-auto-delete --no-demo-notify --reboot
#           --reset-demo <email-or-mobile> (repeatable)  --reset-demo-list
. "$(dirname "$0")/common.sh"
umask 077
HERE="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_URL="__INSTALLER_URL__"; INSTALLER_SHA="__INSTALLER_SHA__"
SITE_URL="__SITE_URL__"; SITE_SHA="__SITE_SHA__"
EK="${EK:-$HERE/ek.pem}"; KEEP=/root/.majestica-bundle-pass; ENVF=/opt/majestica/.env
ECDH_PUB=""; ECDH_CT=""; SKIP_SITE=0; SKIP_SMTP=0; KEEP_PASS=0; RESETS=(); RESET_LIST=0; AUTODEL=0; DEMO_NOTIFY=1; REBOOT=0
while [[ $# -gt 0 ]]; do case "$1" in
  --ecdh) ECDH_PUB="${2:?}"; ECDH_CT="${3:?}"; shift 3;;
  --skip-site) SKIP_SITE=1; shift;; --skip-smtp) SKIP_SMTP=1; shift;; --keep-pass) KEEP_PASS=1; shift;;
  --enable-auto-delete) AUTODEL=1; shift;; --no-demo-notify) DEMO_NOTIFY=0; shift;; --reboot) REBOOT=1; shift;;
  --reset-demo) RESETS+=("${2:?email or mobile}"); shift 2;; --reset-demo-list) RESET_LIST=1; shift;;
  *) die "unknown option $1";; esac; done
[[ "$INSTALLER_URL" != __* && "$SITE_URL" != __* ]] || die "this upgrade script was not stamped with the release links"
setenv() { # setenv KEY VALUE  (only adds / replaces that one line; everything else in .env is kept)
  if grep -q "^$1=" "$ENVF"; then sed -i "s|^$1=.*|$1=$2|" "$ENVF"; else printf '%s=%s\n' "$1" "$2" >>"$ENVF"; fi; }

say "1/7 backup (database + app + website)"
bash "$HERE/stage1-backup.sh"
LIVE="$SITE_DIR/content/site.json"; TS="$(date +%F-%H%M%S)"; BK="/var/backups/majestica-site-content-before-v37c-$TS.tgz"
install -d -m 700 /var/backups; [[ -d $SITE_DIR/content ]] && tar -czf "$BK" -C "$SITE_DIR" content && ok "website content: $BK"

say "2/7 app v3.7c"
PF=""; TMPF=""
cleanup() { [[ -n "$TMPF" && -f "$TMPF" ]] && { shred -u "$TMPF" 2>/dev/null || rm -f "$TMPF"; }; rm -f /root/majestica-install-v37c.sh; }
trap cleanup EXIT
if [[ -s $KEEP ]]; then PF=$KEEP; ok "bundle passphrase: $KEEP (kept from an earlier upgrade)"
elif [[ -n "$ECDH_PUB" ]]; then
  [[ -s $EK ]] || die "no $EK on this server"
  W="$(mktemp -d)"; TMPF="$W/bp"
  { printf -- '-----BEGIN PUBLIC KEY-----\n'; printf '%s' "$ECDH_PUB" | fold -w 64; printf '\n-----END PUBLIC KEY-----\n'; } >"$W/peer.pem"
  S="$(openssl pkeyutl -derive -inkey "$EK" -peerkey "$W/peer.pem" 2>/dev/null | od -An -tx1 | tr -d ' \n')"
  [[ ${#S} -eq 64 ]] || die "ECDH failed"
  printf '%s' "$ECDH_CT" | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:$S" -out "$TMPF" 2>/dev/null || die "could not unlock the passphrase"
  unset S; PF=$TMPF; ok "bundle passphrase unlocked with the server key (never shown)"
else warn "no stored passphrase: bootstrap will ask for it (hidden)"; fi
curl -fsSL --retry 3 "$INSTALLER_URL" -o /root/majestica-install-v37c.sh || die "cannot download the installer (link expired?)"
[[ "$(sha256sum /root/majestica-install-v37c.sh | cut -d' ' -f1)" == "$INSTALLER_SHA" ]] || die "installer checksum mismatch"
ok "installer checksum OK"
if [[ -n "$PF" ]]; then BUNDLE_PASS_FILE="$PF" bash /root/majestica-install-v37c.sh; else bash /root/majestica-install-v37c.sh; fi
systemctl is-active --quiet majestica || die "majestica not active after the upgrade: journalctl -u majestica -n 50  (rollback: bash $HERE/rollback.sh app <backup folder from step 1>)"
[[ -f /opt/majestica/src/server/services/dataRetention.ts && -f /opt/majestica/src/lib/intlPhone.ts ]] && ok "app v3.7c code installed" || warn "v3.7c files not found in /opt/majestica"
q() { runuser -u postgres -- psql -d majestica -tAc "$1" 2>/dev/null || echo x; }
n="$(q 'SELECT count(*) FROM information_schema.columns WHERE table_name=$$Tenant$$ AND column_name IN ($$billingCurrency$$,$$retentionHold$$,$$dataExportedAt$$,$$signupCountry$$,$$signupState$$)')"
[[ "$n" == 5 ]] && ok "database: v3.7c Tenant columns present (additive)" || warn "database v3.7c Tenant columns: $n/5"
[[ "$(q 'SELECT to_regclass($$"DataRetentionLog"$$) IS NOT NULL')" == t ]] && ok "database: DataRetentionLog table" || warn "DataRetentionLog table missing"
[[ "$(q 'SELECT to_regclass($$"UserSlot"$$) IS NOT NULL')" == t ]] && ok "database: UserSlot table (fixed user slots for NEW salons; existing salons unchanged)" || warn "UserSlot table missing"
old="$(q 'SELECT count(*) FROM "User" WHERE phone ~ $$^[6-9][0-9]{9}$$')"
[[ "$old" == 0 ]] && ok "mobile numbers stored with country code (+91...)" || warn "$old user mobile(s) still without +91 (db:upgrade v37c step)"
if [[ $KEEP_PASS -eq 1 && -n "$TMPF" && -s "$TMPF" ]]; then install -m 600 -o root -g root "$TMPF" $KEEP; ok "passphrase kept root-only in $KEEP"; fi
cleanup; TMPF=""

if [[ $SKIP_SMTP -eq 0 ]]; then say "3/7 email"; bash "$HERE/stage2d-app-v36-smtp.sh" || warn "email not switched on yet - re-run: bash $HERE/stage2d-app-v36-smtp.sh"; else say "3/7 email skipped (existing .env kept)"; fi

say "4/7 data-retention emails + auto-delete (daily timer)"
grep -q '^CRON_SECRET=.' "$ENVF" || die ".env has no CRON_SECRET"
[[ $DEMO_NOTIFY -eq 1 ]] && ! grep -q '^DEMO_NOTIFY_EMAIL=' "$ENVF" && setenv DEMO_NOTIFY_EMAIL "$LE_EMAIL" && ok "new free demo emails go to $LE_EMAIL (DEMO_NOTIFY_EMAIL)"
if [[ $AUTODEL -eq 1 ]]; then setenv RETENTION_DELETE on; ok "auto-delete ON (8 months after a free period ends without a package)"
else grep -q '^RETENTION_DELETE=on' "$ENVF" && ok "auto-delete stays ON" || ok "auto-delete is a DRY RUN (logged only). Turn on later: bash $HERE/upgrade-v37c.sh ... --enable-auto-delete"; fi
chmod 600 "$ENVF"; systemctl restart majestica
for _ in $(seq 1 60); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3000/login && break; sleep 1; done
cat >/usr/local/sbin/majestica-retention-tick <<'TICK'
#!/usr/bin/env bash
# daily: data-retention reminder emails + auto-delete (see /opt/majestica/src/server/services/dataRetention.ts)
set -euo pipefail
S="$(grep -m1 '^CRON_SECRET=' /opt/majestica/.env | cut -d= -f2-)"
curl -fsS --max-time 300 -X POST -H "x-cron-secret: $S" "http://127.0.0.1:3000/api/internal/retention-tick${1:+?$1}"; echo
TICK
chmod 700 /usr/local/sbin/majestica-retention-tick
cat >/etc/systemd/system/majestica-retention.service <<'UNIT'
[Unit]
Description=Majestica data-retention emails and auto-delete (daily)
After=majestica.service
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/majestica-retention-tick
UNIT
cat >/etc/systemd/system/majestica-retention.timer <<'UNIT'
[Unit]
Description=Daily Majestica data-retention run (10:30 IST)
[Timer]
OnCalendar=*-*-* 05:00:00 UTC
Persistent=true
RandomizedDelaySec=300
[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload && systemctl enable --now majestica-retention.timer >/dev/null 2>&1 && ok "timer majestica-retention.timer (daily 10:30 IST)" || warn "timer not enabled"
echo "    dry run now (sends nothing, deletes nothing):"
/usr/local/sbin/majestica-retention-tick dryRun=1 | head -c 1500 || warn "dry run failed (see journalctl -u majestica)"; echo

if [[ $SKIP_SITE -eq 0 ]]; then
  say "5/7 website + content (live admin edits are kept; content is updated in place)"
  bash "$HERE/stage3-site-install.sh" "$SITE_URL" "$SITE_SHA"
  for m in migrate-content-v37.mjs migrate-content-v37-legal.mjs migrate-content-v37c.mjs; do
    [[ -f $SITE_DIR/deploy/$m ]] || die "$m missing in the bundle"
    node "$SITE_DIR/deploy/$m" "$LIVE" || die "content update $m failed - restore: tar -xzf $BK -C $SITE_DIR && systemctl restart majestica-site"
  done
  node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' "$LIVE" || die "site.json not valid - restore: tar -xzf $BK -C $SITE_DIR"
  chown -R www-data:www-data "$SITE_DIR/content"; chmod 644 "$LIVE"
  systemctl restart majestica-site
  for _ in $(seq 1 30); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/ && break; sleep 1; done
  PAGES="/ /products /salon-software /products/salon-management-software /products/bulk-sms-email-marketing /faq /terms /privacy /refund-policy /about /contact /request"
  for u in $PAGES; do curl -s -o /dev/null --max-time 10 http://127.0.0.1:3200$u; done; sleep 4
else say "5/7 website skipped"; fi

if [[ $RESET_LIST -eq 1 ]]; then say "free-demo self-signup salons"; bash "$HERE/reset-demo-signup.sh" --list || warn "could not list"; fi
if [[ ${#RESETS[@]} -gt 0 ]]; then say "6/7 remove practice demo account(s)"
  for id in "${RESETS[@]}"; do bash "$HERE/reset-demo-signup.sh" "$id" --yes || warn "not removed: $id"; done
else say "6/7 no demo account to remove"; fi

say "7/7 verify"
for p in /login /staff-app /forgot-code /free-demo /forgot-password /signup /platform; do printf '    https://%s%-17s %s\n' "$APPHOST" "$p" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST$p)"; done
curl -fsS --max-time 10 https://$APPHOST/brand/md-round-logo-full.png -o /dev/null && ok "new login brand panel assets" || warn "brand assets not served"
if [[ $SKIP_SITE -eq 0 ]]; then
  for u in $PAGES /products/bulk-sms-promotion /refund; do printf '    %-42s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' --max-time 10 http://127.0.0.1:3200$u)"; done
  H="$(curl -fsS --max-time 10 http://127.0.0.1:3200/ || true)"
  grep -q 'href="/faq"' <<<"$H" && ok "FAQ in navigation" || warn "FAQ link not found"
  grep -q 'data-cur' <<<"$H" && ok "₹ INR / \$ USD price switch" || warn "currency switch not found"
  curl -fsS --max-time 10 http://127.0.0.1:3200/terms | grep -q 'Data Transfer Fee' && ok "Terms with USD + data retention (4.9)" || warn "terms not updated yet (refresh in a few minutes)"
  curl -fsS --max-time 10 http://127.0.0.1:3200/salon-software | grep -q '\$69' && ok "USD prices on price cards" || warn "USD price not found"
  [[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APEX/request)" == 200 ]] && ok "https://$APEX/request 200" || warn "https://$APEX/request not 200"
  echo "    Rollback website content: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"
fi
journalctl -u majestica --since "-5 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
echo "    Fixed user slots: NEW salons get Admin, 2 Managers, 2 Receptionists, Accountant (empty until the owner assigns them)."
echo "    Existing salons are unchanged. To add slots to one on request: bash $HERE/add-user-slots.sh --tenant <salon-slug>   (dry run; add --yes)"
if [[ $REBOOT -eq 1 ]]; then say "rebooting in 10 seconds (Ctrl+C to cancel)"; sleep 10; systemctl reboot; fi
say "done"
