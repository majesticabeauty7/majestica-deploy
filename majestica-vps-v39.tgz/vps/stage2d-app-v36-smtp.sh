#!/usr/bin/env bash
# STAGE 2d (v3.6) - email for the app: no-reply@majesticadigital.com over Hostinger SMTP (smtp.hostinger.com:465, SSL).
#   Asks for the mailbox password ONCE (hidden, never printed, never in the shell history), stores it base64-encoded as
#   SMTP_PASS_B64 in /opt/majestica/.env (chmod 600, owner majestica), checks the SMTP login WITHOUT sending anything,
#   and only then switches MAIL_MODE=smtp and restarts the app. If the login fails, MAIL_MODE stays as it was (the free demo
#   keeps working with the old fallback). Re-run any time to change the password. The website does not send email: no site change.
. "$(dirname "$0")/common.sh"
umask 077
APP_DIR=/opt/majestica; ENVF=$APP_DIR/.env; TS="$(date +%F-%H%M)"
SMTP_HOST_V="${SMTP_HOST_V:-smtp.hostinger.com}"; SMTP_PORT_V="${SMTP_PORT_V:-465}"; SMTP_USER_V="${SMTP_USER_V:-no-reply@majesticadigital.com}"
MAIL_FROM_V="Majestica Digital <${SMTP_USER_V}>"
[[ -f $ENVF ]] || die "no $ENVF - is the app installed?"
[[ -f $APP_DIR/scripts/smtp-check.mjs ]] || die "the app is older than v3.6 (no scripts/smtp-check.mjs) - run the v3.6 upgrade first"
{ : </dev/tty; } 2>/dev/null || die "needs a terminal to ask for the mailbox password"
install -d -m 700 /var/backups; cp -a $ENVF /var/backups/majestica-app-env-before-v36-$TS; chmod 600 /var/backups/majestica-app-env-before-v36-$TS
say "SMTP settings: ${SMTP_USER_V} via ${SMTP_HOST_V}:${SMTP_PORT_V} (SSL)"

setkv() { # setkv KEY VALUE  -> replaces / adds one line in .env (value written as-is; callers pass only safe characters)
  local k="$1" v="$2" tmp; tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"; chmod 600 "$tmp"
  grep -v "^${k}=" "$ENVF" >"$tmp" || true; printf '%s=%s\n' "$k" "$v" >>"$tmp"
  chown majestica:majestica "$tmp"; mv -f "$tmp" "$ENVF"
}
check() { # runs the app's SMTP login check as the app user; prints only OK / FAILED + reason (no secrets)
  ( cd $APP_DIR && runuser -u majestica -- env HOME=/home/majestica bash -c 'set -a; . ./.env; set +a; MAIL_MODE=smtp node scripts/smtp-check.mjs "$@"' _ "$@" )
}

ok_login=0
for try in 1 2 3; do
  printf '    Paste no-reply mailbox password from your vault and press Enter (hidden): ' >/dev/tty
  IFS= read -rs P </dev/tty; printf '\n' >/dev/tty
  [[ -n "$P" ]] || { warn "empty - try again"; continue; }
  B64="$(printf '%s' "$P" | base64 -w0)"; unset P
  grep -v -E '^(SMTP_PASS|SMTP_FROM)=' "$ENVF" >"$ENVF.tmp.$$" || true; chmod 600 "$ENVF.tmp.$$"; chown majestica:majestica "$ENVF.tmp.$$"; mv -f "$ENVF.tmp.$$" "$ENVF"
  setkv SMTP_HOST "$SMTP_HOST_V"; setkv SMTP_PORT "$SMTP_PORT_V"; setkv SMTP_SECURE true; setkv SMTP_USER "$SMTP_USER_V"
  setkv MAIL_FROM "\"$MAIL_FROM_V\""; setkv SMTP_PASS_B64 "$B64"; unset B64
  say "checking the SMTP login (nothing is sent)"
  if out="$(check 2>&1)"; then ok "$out"; ok_login=1; break; else warn "$out"; fi
  [[ $try -lt 3 ]] && echo "    The password was not accepted. Copy it again from your vault (no spaces before/after)."
done
chown majestica:majestica "$ENVF"; chmod 600 "$ENVF"
if [[ $ok_login -ne 1 ]]; then
  warn "SMTP login failed 3 times - email stays OFF (MAIL_MODE unchanged). Check the mailbox password in Hostinger hPanel -> Emails, then run:  bash /root/vps/stage2d-app-v36-smtp.sh"
  exit 1
fi
setkv MAIL_MODE smtp; chown majestica:majestica "$ENVF"; chmod 600 "$ENVF"; ok "MAIL_MODE=smtp"

printf '    Send a test email? Type an email address (or just press Enter to skip): ' >/dev/tty
IFS= read -r TO </dev/tty || TO=""
if [[ -n "$TO" ]]; then
  if [[ "$TO" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[A-Za-z]{2,}$ ]]; then out="$(check "$TO" 2>&1)" && ok "$out" || warn "$out"; else warn "not an email address - skipped"; fi
fi

say "restart app"
systemctl restart majestica
for _ in $(seq 1 60); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3000/login && break; sleep 2; done
systemctl is-active --quiet majestica && ok "majestica active" || die "majestica not active: journalctl -u majestica -n 50"
grep -q '^MAIL_MODE=smtp$' "$ENVF" && grep -q '^SMTP_PASS_B64=.' "$ENVF" && ok ".env has MAIL_MODE=smtp + SMTP_* (values not shown), mode $(stat -c %a "$ENVF")"
code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -X POST -H 'content-type: application/json' -d '{}' http://127.0.0.1:3000/api/public/demo-signup)"
[[ $code == 401 ]] && ok "demo-signup endpoint ON (401 without the website secret)" || warn "demo-signup without secret -> $code (expected 401)"
code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST/free-demo)"; [[ $code == 200 ]] && ok "https://$APPHOST/free-demo 200" || warn "/free-demo -> $code"
echo "    Free demo signups now get a 6-digit email code and set their own password. Forgot password uses one email code."
