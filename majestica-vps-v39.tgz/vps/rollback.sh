#!/usr/bin/env bash
# ROLLBACK helpers.  site  -> at Hostinger set the A record of majesticadigital.com back to 2.57.91.91 (nothing else needed);
#                            optional: systemctl disable --now majestica-site; rm /etc/nginx/sites-enabled/majestica-site.conf; systemctl reload nginx
#                    app   -> bash rollback.sh app <backup-folder>   restores /opt/majestica code (DB schema changes are additive, data stays).
. "$(dirname "$0")/common.sh"
[[ "${1:-}" == app ]] || { sed -n '2,4p' "$0"; exit 0; }
D="${2:?backup folder, e.g. /var/backups/majestica-predeploy-2026-11-15-1030}"; [[ -f $D/opt-majestica.tar.gz ]] || die "no opt-majestica.tar.gz in $D"
systemctl stop majestica; mv /opt/majestica "/opt/majestica.failed-$(date +%H%M)"; tar -xzf "$D/opt-majestica.tar.gz" -C /opt
chown -R majestica:majestica /opt/majestica
runuser -u majestica -- env HOME=/home/majestica bash -c 'cd /opt/majestica && npm ci --include=dev --no-audit --no-fund --loglevel=error && set -a && . ./.env && set +a && npm run build'
systemctl start majestica && ok "previous app version restored"
