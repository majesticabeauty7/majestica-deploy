// v3.7c: USD prices for clients outside India (website INR/USD toggle), SMS only for Indian numbers, and the
// data policy (no data selling, owner offers only with consent, Data Transfer Fee after the free period,
// 6-month data retention, then permanent deletion). Targeted text edits, so admin edits elsewhere are kept.
// Safe to re-run: recorded in content.migrations.
//   node scripts/migrate-content-v37c.mjs <path/to/site.json> [--dry-run]
import fs from "node:fs";
const file = process.argv[2]; const dry = process.argv.includes("--dry-run");
if (!file) { console.error("usage: node migrate-content-v37c.mjs <site.json> [--dry-run]"); process.exit(2); }
const c = JSON.parse(fs.readFileSync(file, "utf8"));
const ID = "v3.7c-usd-data-policy";
c.migrations = Array.isArray(c.migrations) ? c.migrations : [];
if (c.migrations.includes(ID)) { console.log(`content already has ${ID} - nothing to do`); process.exit(0); }
const UPDATED = "17 November 2026";
const notes = [];
/** replace `from` (string) in obj[key]; if missing and `fallback` given, apply fallback(text) */
function rep(obj, key, from, to, label, fallback) {
  if (!obj || typeof obj[key] !== "string") { notes.push(`skip ${label}: no text`); return; }
  if (obj[key].includes(to)) { notes.push(`= ${label} (already there)`); return; }
  if (obj[key].includes(from)) { obj[key] = obj[key].replace(from, to); notes.push(`ok ${label}`); return; }
  if (fallback) { obj[key] = fallback(obj[key]); notes.push(`ok ${label} (appended)`); return; }
  notes.push(`MISS ${label}: anchor text not found (edited by admin?) - please add by hand`);
}
const appendEnd = (add) => (t) => `${t.trimEnd()}\n\n${add}`;
/** insert `add` before the line starting with `beforeHeading` (or at the end) */
const insertBefore = (beforeHeading, add) => (t) => { const i = t.indexOf(beforeHeading); return i < 0 ? appendEnd(add)(t) : `${t.slice(0, i)}${add}\n\n${t.slice(i)}`; };

/* ---------------- 1. plans: USD prices (salon software only) ---------------- */
const sw = (c.products || []).find((p) => p.slug === "salon-management-software");
if (sw) for (const p of sw.plans || []) {
  if (p.priceDisplayUsd) continue;
  if (p.id === "plan_salon_single" || /single/i.test(p.name)) {
    // NOTE: $25 is a placeholder (about the same as ₹1,799) - the owner set only the Multi Store USD price ($69). Editable in admin.
    Object.assign(p, { priceAmountUsd: 25, priceDisplayUsd: "$25", offerPriceDisplayUsd: "$12.50",
      offerPriceNoteUsd: "Launch offer: $12.50/month for 2 years, if you buy within 12 months",
      pricingNoteUsd: "For 1 salon. Billed in USD for salons outside India; no Indian GST." });
    notes.push("ok plan Single Store USD $25 (placeholder)");
  } else if (p.id === "plan_salon_monthly" || /multi/i.test(p.name)) {
    Object.assign(p, { priceAmountUsd: 69, priceDisplayUsd: "$69", offerPriceDisplayUsd: "$34.50",
      offerPriceNoteUsd: "Launch offer: $34.50/month for 2 years, if you buy within 12 months",
      pricingNoteUsd: "Includes up to 3 branches. Each extra branch (4th onward) $17/month — 50% off for 2 years: $8.50/month. Billed in USD for salons outside India; no Indian GST. New branches are activated after approval." });
    notes.push("ok plan Multi Store USD $69");
  }
}
c.marketing = c.marketing || {};
if (!c.marketing.pricesNoteUsd) c.marketing.pricesNoteUsd = "Prices in US Dollars for salons outside India. No Indian GST.";

/* ---------------- 2. Terms ---------------- */
const T = c.terms;
const USD_TERMS = `- **Clients outside India** (a mobile number with a country code other than +91) are billed in **US Dollars (USD)**: Single Store **$25 per month** and Multi Store **$69 per month**; with the launch offer **$12.50** and **$34.50 per month** for 2 years. Each extra branch (4th onward) is **$17 per month**, or **$8.50 per month** with the launch offer.`;
rep(T, "body", "- Offer terms are as shown on the product pages on the date your account was activated.",
  `${USD_TERMS}\n- Offer terms are as shown on the product pages on the date your account was activated.`, "terms 4.1 USD",
  insertBefore("### 4.2", USD_TERMS));
rep(T, "body", "All prices on our website are in Indian Rupees and are **exclusive of GST**.",
  "For clients in India, prices are in Indian Rupees and are **exclusive of GST**. For clients outside India, prices are in **US Dollars**; Indian GST is not charged where the service qualifies as an export of services under GST law, and any taxes in your own country are your responsibility.", "terms 4.2 currency");
rep(T, "body", "We may also accept bank transfer or UPI to the account shown on our invoice.",
  "Clients outside India pay in USD by international debit or credit card through Razorpay; your bank may charge currency conversion or foreign transaction fees. We may also accept bank transfer or UPI to the account shown on our invoice.", "terms 4.4 USD cards");
rep(T, "body", "- your data is kept safely for **90 days** after the account is suspended, so you can renew or ask for an export;\n- if the account is not renewed within those 90 days, we permanently delete the account and its data, after notice by email. Please export your data before that date if you do not plan to renew.",
  "- your data then remains available for export for **6 months**; after that it is permanently deleted within 60 days, as set out in section 4.9.",
  "terms 4.5 retention 6 months");
const RET = `### 4.9 Data retention, deletion and Data Transfer Fee
This applies to **all our services** — the salon software and Staff App, and websites or other projects we build or host for you.
- **During the free 6 + 6 months period** you can export your data free of charge at any time.
- **When a service ends or is not renewed** (including when the free period ends without a paid package), its data **remains available for export for 6 months** after the service ends. During those 6 months you can take any paid package to continue — all your data comes back — or ask for a copy of your data.
- **Data Transfer Fee:** after the free period has ended, a backup or full data export costs a one-time **Data Transfer Fee of ₹999 + GST** (clients outside India: **$12**). The fee is waived if you take any paid package.
- **Reminder emails:** during those 6 months we send the owner a reminder email every week (every 3 days in the last 2 weeks) with the last date to get your data. The reminders stop when you renew or receive your data export.
- **Automatic deletion:** after those 6 months the data is **automatically and permanently deleted within 60 days**, and we confirm the deletion by email. Our encrypted backup copies are overwritten within 14 days after that. Deleted data **cannot be recovered by anyone** — neither by you nor by us.
- Requests by your customers or staff to see or correct their own personal data are always free.
- We keep only what the law requires us to keep, such as our GST invoices.`;
rep(T, "body", "### 4.8 Refunds and cancellation", `${RET}\n\n### 4.8 Refunds and cancellation`, "terms 4.9 retention + fee", insertBefore("## 5.", RET));
// keep the numbering in order: move 4.9 after 4.8
if (typeof T?.body === "string" && T.body.includes("### 4.9 Data retention")) {
  const a = T.body.indexOf("### 4.9 Data retention"), b = T.body.indexOf("### 4.8 Refunds and cancellation");
  const e = T.body.indexOf("\n## 5.", b);
  if (a >= 0 && b > a && e > b) { const ret = T.body.slice(a, b); const s48 = T.body.slice(b, e); T.body = T.body.slice(0, a) + s48.trimEnd() + "\n\n" + ret.trimEnd() + "\n" + T.body.slice(e); }
}
rep(T, "body", "- **Export:** you can download your client list and reports from the software at any time. You can also email us for a full export of your data, which we provide within 15 days.\n- **Deletion:** when your account is closed, or at your written request, we delete your salon data within 90 days, except what we must keep by law (for example, our GST invoices). Copies in our encrypted backups are overwritten within 14 days after that.",
  `- **We never sell your data.** We do not sell, rent or trade your salon's data or your customers' or staff's personal data, and we do not use your customers' data for our own marketing — also not after your free period ends or if you do not renew. We act only as your Data Processor.
- **Anonymous statistics:** we may use combined, anonymous statistics that cannot identify any salon, customer or staff member (for example, total bookings on the platform) to improve our products.
- **Your contact details as the owner:** we use them for service messages (login codes, renewal reminders, invoices) and, only if you agree when you sign up, for offers and product news by email or WhatsApp. You can stop offers at any time.
- **Export:** during the free 6 + 6 months period and while you are on a paid package, you can export your data free of charge (email us for a full export, which we provide within 15 days). After the free period ends, the Data Transfer Fee in section 4.9 applies, unless you take a paid package.
- **Your customers' requests:** requests by your customers or staff to see or correct their own personal data are always free; you can view and correct their details in the software at any time.
- **Deletion:** data of a service that ends or is not renewed remains available for export for **6 months**; after that it is permanently deleted within 60 days (section 4.9). You can also ask us in writing to delete it sooner.`,
  "terms 7 data", insertBefore("## 8.", `- **We never sell your data**, and we do not use your customers' data for our own marketing. After your free 6 + 6 months period ends without a paid package, a full data export or transfer may carry a one-time **Data Transfer Fee of ₹999 + GST** (clients outside India: **$12**), waived if you take any paid package. Data of accounts that are not renewed remains available for export for **6 months** and is then permanently deleted within 60 days.`));
if (T) T.updated = UPDATED;

/* ---------------- 3. Privacy ---------------- */
const P = c.privacy;
rep(P, "body", "- to answer enquiries and give support;",
  "- to answer enquiries and give support;\n- to send salon owners offers and news about Majestica Digital by email or WhatsApp, only if they agreed when signing up (you can stop at any time);", "privacy 2 offers consent");
rep(P, "body", "Requests from your customers or staff about their data should go to your salon; we will help you respond.",
  "Requests from your customers or staff about their data should go to your salon; we will help you respond, free of charge. We never sell, rent or trade this data, and we never use it for our own purposes — also not after a free period ends or an account is not renewed. We may use only combined, anonymous statistics that cannot identify any salon or person, to improve our products.", "privacy 3 no selling");
rep(P, "body", "- Account and salon data: while your account is active, and for 90 days after it ends or is suspended for non-renewal or non-payment (so you can renew or export it); then it is deleted. Encrypted backup copies are overwritten within 14 days after that.",
  "- Account and salon data: while your account is active, and, after the free period or plan ends without renewal, it remains available for export for **6 months** (so you can take a package or get your data); after that it is permanently deleted within 60 days. Encrypted backup copies are overwritten within 14 days after deletion, and the data cannot then be recovered by anyone.", "privacy 6 retention");
rep(P, "body", "- email, SMS and WhatsApp delivery providers, to send messages you or your salon trigger.",
  "- email, SMS and WhatsApp delivery providers, to send messages you or your salon trigger (SMS is sent only to Indian +91 numbers; other countries get email).", "privacy 5 sms");
if (P) P.updated = UPDATED;

/* ---------------- 4. Refund ---------------- */
const R = c.refund;
rep(R, "body", "To continue after the free period, you select a package and pay for it; this policy then applies to that payment.",
  "To continue after the free period, you select a package and pay for it; this policy then applies to that payment. If you do not renew, your data remains available for export for 6 months and is then permanently deleted within 60 days (see our [Terms & Conditions](/terms), section 4.9).", "refund 1 retention");
rep(R, "body", "## 3. Website development",
  `- **Data Transfer Fee:** the one-time Data Transfer Fee (Terms section 4.9) is not refundable once your data has been delivered. If we cannot deliver it, we refund it in full.
- **USD payments:** clients outside India who paid in USD are refunded in USD to the original card. Currency conversion charges of your bank are not refunded.

## 3. Website development`, "refund 2 fee + USD");
if (R) R.updated = UPDATED;

/* ---------------- 5. FAQ ---------------- */
const fq = (re) => (c.faq || []).find((f) => re.test(f.q || ""));
const end = fq(/12 months of free use end/i);
if (end) rep(end, "a", "Your data is kept for 90 days so you can renew or ask for an export, and is then deleted.",
  "Your data remains available for 6 months so you can take a package and continue; after that it is permanently deleted within 60 days and cannot be recovered.", "faq free period end");
const msgs = fq(/SMS or WhatsApp/i);
if (msgs) rep(msgs, "a", "SMS and WhatsApp messages are coming soon.",
  "SMS and WhatsApp messages are coming soon. SMS goes only to Indian (+91) mobile numbers; if your number is outside India, you get everything by email.", "faq sms india only");
const prices = fq(/salon software prices/i);
if (prices) rep(prices, "a", "Every new branch is activated after we approve the request.",
  "Every new branch is activated after we approve the request. Outside India, prices are in US Dollars with the same offer: Multi Store $69 per month ($34.50 with the offer), Single Store $25 ($12.50), each extra branch $17 ($8.50), with no Indian GST. Use the ₹ INR / $ USD switch on the pricing cards.", "faq prices usd");
const pay = fq(/How do I pay/i);
if (pay) rep(pay, "a", "See our Refund & Cancellation Policy for refunds.",
  "Clients outside India pay in US Dollars by international debit or credit card through Razorpay, with no Indian GST. See our Refund & Cancellation Policy for refunds.", "faq pay usd");
const safe = fq(/data kept safe/i);
if (safe) rep(safe, "a", "and each salon's data is kept separate.",
  "and each salon's data is kept separate. We never sell your data or use your customers' details for our own marketing.", "faq no selling");

c.migrations.push(ID);
for (const n of notes) console.log("  " + n);
if (dry) { console.log("dry run - not saved"); process.exit(0); }
fs.writeFileSync(file, JSON.stringify(c, null, 2) + "\n");
console.log(`content migrated: ${ID}`);
