#!/usr/bin/env bash
# v3.7: remove ONE free-demo self-signup salon so the same email + mobile can sign up again (practice runs).
#   bash reset-demo-signup.sh --list                    -> newest self-signup demo salons (find the email / mobile)
#   bash reset-demo-signup.sh <email-or-mobile>         -> DRY RUN: prints what would be deleted
#   bash reset-demo-signup.sh <email-or-mobile> --yes   -> DB backup first, then deletes in ONE transaction
# Refuses (deletes nothing) unless the login is the OWNER of a salon made by the free-demo self-signup (WEBSITE_DEMO),
# not paid, not the example demo. Real salons, staff logins and platform admin accounts are never touched.
. "$(dirname "$0")/common.sh"
cd /opt/majestica; [[ -f prisma/reset-demo-signup.ts ]] || die "prisma/reset-demo-signup.ts missing (it ships with app v3.7 - upgrade first)"
ID="${1:-}"; [[ -n "$ID" ]] || die "usage: bash $0 --list | <email-or-mobile> [--yes]"
if [[ "$ID" != "--list" ]]; then [[ "$ID" =~ ^[A-Za-z0-9._%+@-]{6,120}$ || "$ID" =~ ^[0-9+\ -]{10,16}$ ]] || die "give the full email or the 10-digit mobile number"; fi
run() { runuser -u majestica -- env HOME=/home/majestica bash -c "cd /opt/majestica && set -a && . ./.env && set +a && npx --no-install tsx prisma/reset-demo-signup.ts $(printf '%q ' "$@")"; }
if [[ "$ID" == "--list" ]]; then run --list; exit 0; fi
if [[ "${2:-}" != "--yes" ]]; then run "$ID"; exit 0; fi
say "dry run first"
run "$ID" || die "refused - nothing deleted"
D="/root/backups/reset-demo-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$D"; chmod 700 "$D"
BK=/root/.majestica-backup-pass
if [[ -s $BK ]]; then F="$D/majestica-db.sql.gz.enc"   # same encryption as the nightly backup (AES-256, BACKUP_PASS)
  ( umask 077; set -o pipefail; runuser -u postgres -- pg_dump --no-owner --no-privileges majestica | gzip -9 | openssl enc -aes-256-cbc -pbkdf2 -salt -pass file:$BK -out "$F" ) || die "database backup failed - nothing deleted"
  RESTORE="openssl enc -d -aes-256-cbc -pbkdf2 -pass file:$BK -in $F | gunzip -c | runuser -u postgres -- psql -d majestica_restore"
else F="$D/majestica-db.sql.gz"
  ( umask 077; set -o pipefail; runuser -u postgres -- pg_dump --no-owner --no-privileges majestica | gzip -9 >"$F" ) || die "database backup failed - nothing deleted"
  RESTORE="gunzip -c $F | runuser -u postgres -- psql -d majestica_restore"; fi
[[ -s "$F" ]] || die "database backup is empty - nothing deleted"
ok "database backup $F (root-only$([[ $F == *.enc ]] && echo ', encrypted'))"
say "deleting"
run "$ID" --yes || die "delete failed (the transaction was rolled back - nothing deleted). Backup: $D"
ok "done. Restore if ever needed: $RESTORE"
