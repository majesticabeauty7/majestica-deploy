#!/usr/bin/env bash
# STAGE 0 - read-only checks. Changes nothing.
. "$(dirname "$0")/common.sh"
say "system"; . /etc/os-release; echo "    $PRETTY_NAME, $(nproc) CPU, $(free -h | awk '/Mem/{print $2}') RAM, swap $(free -h | awk '/Swap/{print $2}')"
echo "    disk free on /: $(df -h / | awk 'NR==2{print $4}')"; [[ $(df -Pk / | awk 'NR==2{print $4}') -gt 3000000 ]] && ok "disk >= 3 GB free" || warn "less than 3 GB free on /"
say "services"; for s in majestica nginx postgresql; do systemctl is-active --quiet "$s" && ok "$s active" || warn "$s NOT active"; done
command -v node >/dev/null && echo "    node $(node -v)" || warn "node missing (stage 2 installs it)"
say "app"; [[ -f /opt/majestica/package.json ]] && ok "/opt/majestica present" || warn "/opt/majestica missing"
curl -fsS -o /dev/null --max-time 5 http://127.0.0.1:3000/login && ok "app answers on :3000" || warn "app not answering on :3000"
for k in VAPID_PUBLIC_KEY FIELD_ENC_KEY SEED_DEMO; do grep -q "^$k=" /opt/majestica/.env 2>/dev/null && echo "    .env has $k" || echo "    .env has no $k (stage 2 adds it if needed)"; done
[[ -f /root/majestica-secrets.txt ]] && ok "secrets file present (not shown)" || warn "no /root/majestica-secrets.txt"
command -v majestica-backup >/dev/null && ok "majestica-backup installed" || warn "no majestica-backup (stage 1 falls back to pg_dump)"
echo "    current Permissions-Policy: $(curl -sI --max-time 5 -H "Host: $APPHOST" http://127.0.0.1/login | tr -d '\r' | sed -n 's/^Permissions-Policy: //Ip')"
say "port 3200"; ss -ltn | grep -q ':3200 ' && warn "something already listens on 3200" || ok "3200 free"
say "DNS"; for h in $APEX $WWW $APPHOST; do ip="$(resolve $h)"; [[ "$ip" == "$VPS_IP" ]] && ok "$h -> $ip" || echo "    $h -> ${ip:-?} (not the VPS yet)"; done
