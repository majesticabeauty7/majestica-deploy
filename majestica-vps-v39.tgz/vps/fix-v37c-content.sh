#!/usr/bin/env bash
# Re-apply ONLY the v3.7 / v3.7b / v3.7c website CONTENT migrations (idempotent).
# Does not reinstall site or app code, does not touch SMTP, users, or .env.
# Why: the v3.7c upgrade installed the new website code, but the content step
# (product merge, tagline, legal pages, USD prices) likely never ran because
# 127.0.0.1:3200 was not up yet and the installer stopped before the migrations.
#
#   bash /root/vps/fix-v37c-content.sh
#   bash /root/vps/fix-v37c-content.sh --local /path/to/site-root
#       (site-root must contain content/site.json; no root, no systemd, no :3200)
#
# Safe to re-run: each migrate script records itself in content.migrations.
# Admin edits in other fields are kept (targeted / in-place updates).
set -euo pipefail
umask 077

HERE="$(cd "$(dirname "$0")" && pwd)"
SITE_DIR="${SITE_DIR:-/opt/majestica-site}"
LIVE=""
LOCAL=0
WAIT_SECS="${WAIT_SECS:-180}"
APEX="${APEX:-majesticadigital.com}"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[1;32mOK\033[0m %s\n' "$*"; }
warn() { printf '    \033[1;33mWARN\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

usage() { sed -n '2,16p' "$0" | sed 's/^# \?//'; exit 2; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --local) LOCAL=1; SITE_DIR="${2:?path to site root (contains content/site.json)}"; shift 2;;
    -h|--help) usage;;
    *) die "unknown option $1 (try --help)";;
  esac
done

LIVE="$SITE_DIR/content/site.json"
[[ -f $LIVE ]] || die "no $LIVE — is the website installed?"
command -v node >/dev/null || die "node is required"
command -v curl >/dev/null || die "curl is required"

if [[ $LOCAL -eq 0 ]]; then
  [[ ${EUID:-$(id -u)} -eq 0 ]] || die "run as root (Hostinger hPanel -> VPS -> Browser terminal)"
fi

# Prefer migrate scripts shipped in the v3.7c site bundle; fall back to copies next to this script.
pick_migrate() {
  local name="$1"
  if [[ -f $SITE_DIR/deploy/$name ]]; then printf '%s' "$SITE_DIR/deploy/$name"
  elif [[ -f $HERE/$name ]]; then printf '%s' "$HERE/$name"
  else die "$name not found in $SITE_DIR/deploy or $HERE"
  fi
}
M37="$(pick_migrate migrate-content-v37.mjs)"
M37L="$(pick_migrate migrate-content-v37-legal.mjs)"
M37C="$(pick_migrate migrate-content-v37c.mjs)"

wait_site() {
  local secs="${1:-$WAIT_SECS}" i
  for i in $(seq 1 "$secs"); do
    if curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/; then
      ok "site answers on 127.0.0.1:3200 (after ${i}s)"
      return 0
    fi
    sleep 1
  done
  return 1
}

# File-level checks (source of truth; not affected by the 5-minute page cache)
check_file() {
  LIVE_JSON="$LIVE" node -e '
const fs = require("fs");
const file = process.env.LIVE_JSON;
JSON.parse(fs.readFileSync(file, "utf8"));
const c = JSON.parse(fs.readFileSync(file, "utf8"));
const fail = [];
const need = ["v3.7-faq-bulk-merge", "v3.7-legal", "v3.7c-usd-data-policy"];
const mig = Array.isArray(c.migrations) ? c.migrations : [];
for (const id of need) if (!mig.includes(id)) fail.push("missing migration " + id);
if ((c.site && c.site.tagline) !== "Smart salon software, built by salon owners.") fail.push("tagline");
const slugs = (c.products || []).map((p) => p.slug);
if (!slugs.includes("bulk-sms-email-marketing")) fail.push("merged product slug");
if (slugs.includes("bulk-sms-promotion") || slugs.includes("bulk-email-promotion")) fail.push("old SMS/email products still present");
const names = (c.products || []).map((p) => p.name);
if (!names.includes("Bulk SMS & Email Marketing")) fail.push("merged product name");
const order = ["salon-management-software", "website-development", "social-media-marketing", "bulk-sms-email-marketing"];
const published = slugs.filter((s) => order.includes(s));
if (published.join() !== order.join()) fail.push("product order " + published.join(", "));
const body = (c.terms && c.terms.body) || "";
if (!body.includes("Payment Terms")) fail.push("terms Payment Terms");
if (!body.includes("Data Transfer Fee")) fail.push("terms Data Transfer Fee");
if (!body.includes("999")) fail.push("terms 999");
if (!body.includes("$69")) fail.push("terms USD $69");
const sw = (c.products || []).find((p) => p.slug === "salon-management-software");
const multi = (sw && sw.plans || []).find((p) => p.id === "plan_salon_monthly" || /multi/i.test(p.name || ""));
if (!multi || multi.priceDisplayUsd !== "$69") fail.push("plan Multi Store USD $69");
const raw = JSON.stringify(c);
if (!raw.includes("₹1,249") && !raw.includes("1,249")) fail.push("extra branch ₹1,249");
if (raw.includes("₹1,499")) fail.push("old extra branch ₹1,499 still present");
if (fail.length) { console.error("FILE_FAIL " + fail.join(" | ")); process.exit(1); }
console.log("FILE_OK migrations=" + mig.join(",") + " products=" + slugs.join(","));
'
}

# HTTP checks; retried because Next.js may serve a stale page for a few seconds after restart
http_ok() {
  local path="$1" needle="$2"
  curl -fsS --max-time 15 "http://127.0.0.1:3200$path" | grep -q -- "$needle"
}

check_http() {
  local fails=() u code
  for u in / /products /salon-software /products/salon-management-software /products/bulk-sms-email-marketing /faq /terms /privacy /refund-policy /about /contact /request; do
    code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "http://127.0.0.1:3200$u" || true)"
    printf '    %-42s %s\n' "$u" "$code"
    [[ "$code" == 200 ]] || fails+=("$u -> $code")
  done
  for u in /products/bulk-sms-promotion /products/bulk-email-promotion; do
    printf '    %-42s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' --max-time 15 "http://127.0.0.1:3200$u" || true)"
  done
  http_ok / "Smart salon software, built by salon owners." || fails+=("home tagline")
  http_ok / "Bulk SMS & Email Marketing" || fails+=("home merged product")
  if curl -fsS --max-time 15 http://127.0.0.1:3200/ | grep -q "Bulk SMS Promotion"; then fails+=("home still has Bulk SMS Promotion"); fi
  if curl -fsS --max-time 15 http://127.0.0.1:3200/ | grep -q "Bulk Email Promotion"; then fails+=("home still has Bulk Email Promotion"); fi
  http_ok /faq "How do I log in?" || fails+=("faq login question")
  http_ok /terms "Payment Terms" || fails+=("terms Payment Terms")
  http_ok /terms "Data Transfer Fee" || fails+=("terms Data Transfer Fee")
  http_ok /terms "999" || fails+=("terms 999")
  http_ok /salon-software "\$69" || fails+=("salon-software USD \$69")
  http_ok /salon-software "1,249" || fails+=("salon-software ₹1,249")
  http_ok / "data-cur" || fails+=("currency switch")
  if [[ ${#fails[@]} -gt 0 ]]; then
    printf '    HTTP_FAIL %s\n' "${fails[*]}"
    return 1
  fi
  ok "HTTP checks passed on 127.0.0.1:3200"
}

say "v3.7c content fix (migrations only)"
echo "    site.json: $LIVE"
echo "    scripts: $M37"
echo "             $M37L"
echo "             $M37C"
node -e 'const c=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")); console.log("    migrations now:", (c.migrations||[]).join(", ")||"(none)"); console.log("    products now: ", (c.products||[]).map(p=>p.slug).join(", "));' "$LIVE"

if [[ $LOCAL -eq 0 ]]; then
  say "1/4 wait for the website on 127.0.0.1:3200 (will still migrate the file if it is slow)"
  if systemctl is-active --quiet majestica-site 2>/dev/null; then ok "majestica-site is active"
  else warn "majestica-site is not active — starting it"; systemctl start majestica-site || warn "could not start majestica-site"; fi
  wait_site "$WAIT_SECS" || warn "127.0.0.1:3200 not answering yet — applying the file update anyway (this is the step that was skipped last time)"
fi

say "2/4 backup website content"
TS="$(date +%F-%H%M%S)-$$"
if [[ $LOCAL -eq 1 ]]; then
  BK="$SITE_DIR/content-backup-before-v37c-fix-$TS.tgz"
  tar -czf "$BK" -C "$SITE_DIR" content
else
  install -d -m 700 /var/backups
  BK="/var/backups/majestica-site-content-before-v37c-fix-$TS.tgz"
  tar -czf "$BK" -C "$SITE_DIR" content
fi
ok "backup: $BK"
echo "    Rollback: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"

say "3/4 run content migrations (idempotent; live admin edits elsewhere are kept)"
for m in "$M37" "$M37L" "$M37C"; do
  echo "    -> $(basename "$m")"
  node "$m" "$LIVE" || die "content update $(basename "$m") failed — restore: tar -xzf $BK -C $SITE_DIR && systemctl restart majestica-site"
done
check_file && ok "site.json is valid and has the v3.7c content" || die "site.json failed the v3.7c content checks — restore: tar -xzf $BK -C $SITE_DIR && systemctl restart majestica-site"
if [[ $LOCAL -eq 0 ]]; then
  chown -R www-data:www-data "$SITE_DIR/content"
  chmod 644 "$LIVE"
  # Restart so Next.js drops the 5-minute content cache and rebuilds pages from the new file.
  systemctl restart majestica-site
fi

if [[ $LOCAL -eq 1 ]]; then
  say "4/4 local file check only (no HTTP)"
  ok "local test passed"
  echo "    Restore this test copy: tar -xzf $BK -C $SITE_DIR"
  say "done"
  exit 0
fi

say "4/4 wait, warm pages, verify"
wait_site "$WAIT_SECS" || { journalctl -u majestica-site -n 40 --no-pager || true; die "site did not start after the content update — file was written; restore if needed: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"; }
PAGES="/ /products /salon-software /products/salon-management-software /products/bulk-sms-email-marketing /faq /terms /privacy /refund-policy /about /contact /request"
for u in $PAGES; do curl -s -o /dev/null --max-time 15 "http://127.0.0.1:3200$u" || true; done
sleep 4

HTTP_OK=0
for i in 1 2 3 4 5 6 7 8 9 10; do
  if check_http; then HTTP_OK=1; break; fi
  warn "HTTP checks not green yet (try $i/10, cache may still be old) — waiting 5s"
  sleep 5
  for u in $PAGES; do curl -s -o /dev/null --max-time 15 "http://127.0.0.1:3200$u" || true; done
done
[[ $HTTP_OK -eq 1 ]] || die "file is updated but HTTP checks failed — wait a minute and curl again, or restore: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"

# Public hostname (may still be a few seconds behind if a proxy cached a page)
if [[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "https://$APEX/products/bulk-sms-email-marketing" || true)" == 200 ]]; then
  ok "https://$APEX/products/bulk-sms-email-marketing 200"
else
  warn "https://$APEX/products/bulk-sms-email-marketing not 200 yet (try again in a minute)"
fi
if curl -fsS --max-time 15 "https://$APEX/" | grep -q "Bulk SMS & Email Marketing"; then
  ok "https://$APEX shows Bulk SMS & Email Marketing"
else
  warn "public home page not updated yet (5-minute cache); 127.0.0.1:3200 already has the new content"
fi

echo "    Rollback website content: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"
say "done"
