#!/usr/bin/env bash
# ONE-COMMAND website-only update v3.7b (no app change):
#   FAQ page /faq, Bulk SMS & Email Marketing (one product, old URLs 301), new tagline, Facebook / Instagram icons
#   (hidden until URLs are filled in Site admin -> Brand & contact -> Social links), new Terms & Conditions with Payment Terms,
#   Privacy Policy, Refund & Cancellation Policy page, launch offer badge on every salon software price card.
#   bash upgrade-site-v37b.sh [--reboot]
# Live content (admin edits, requests, uploads) is KEPT and updated in place by two migration scripts; full backup first.
. "$(dirname "$0")/common.sh"
HERE="$(cd "$(dirname "$0")" && pwd)"
SITE_URL="__SITE_URL__"; SITE_SHA="__SITE_SHA__"; REBOOT=0
while [[ $# -gt 0 ]]; do case "$1" in --reboot) REBOOT=1; shift;; *) die "unknown option $1";; esac; done
[[ "$SITE_URL" != __* ]] || die "this script was not stamped with the site bundle link"
LIVE="$SITE_DIR/content/site.json"; TS="$(date +%F-%H%M%S)"

say "1/4 backup website content"
install -d -m 700 /var/backups
BK="/var/backups/majestica-site-content-before-v37b-$TS.tgz"
[[ -d $SITE_DIR/content ]] && tar -czf "$BK" -C "$SITE_DIR" content && ok "$BK" || warn "no content/ yet (first install)"

say "2/4 website code"
bash "$HERE/stage3-site-install.sh" "$SITE_URL" "$SITE_SHA"

say "3/4 update live content (FAQ, products, tagline, legal pages, offer badge)"
for m in migrate-content-v37.mjs migrate-content-v37-legal.mjs; do
  [[ -f $SITE_DIR/deploy/$m ]] || die "$m missing in the bundle"
  node "$SITE_DIR/deploy/$m" "$LIVE" || die "content update $m failed - restore: tar -xzf $BK -C $SITE_DIR && systemctl restart majestica-site"
done
node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' "$LIVE" || die "site.json not valid after update - restore: tar -xzf $BK -C $SITE_DIR"
chown -R www-data:www-data "$SITE_DIR/content"; chmod 644 "$LIVE"
systemctl restart majestica-site
for _ in $(seq 1 30); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/ && break; sleep 1; done
PAGES="/ /products /salon-software /products/salon-management-software /products/bulk-sms-email-marketing /faq /terms /privacy /refund-policy /about /contact"
for u in $PAGES; do curl -s -o /dev/null --max-time 10 http://127.0.0.1:3200$u; done; sleep 4   # pages rebuild from the live content

say "4/4 verify"
for u in $PAGES /products/bulk-sms-promotion /products/bulk-email-promotion /request /download-staff-app; do
  printf '    %-42s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' --max-time 10 http://127.0.0.1:3200$u)"; done
H="$(curl -fsS --max-time 10 http://127.0.0.1:3200/ || true)"
grep -q 'Smart salon software, built by salon owners.' <<<"$H" && ok "new tagline live" || warn "new tagline not on home page yet (refresh in a few minutes)"
grep -q 'href="/faq"' <<<"$H" && ok "FAQ in navigation" || warn "FAQ link not found"
grep -q 'href="/refund-policy"' <<<"$H" && ok "Refund & Cancellation in footer" || warn "refund link not found"
curl -fsS --max-time 10 http://127.0.0.1:3200/faq | grep -q '"FAQPage"' && ok "FAQ page with FAQPage data" || warn "FAQ page check failed"
curl -fsS --max-time 10 http://127.0.0.1:3200/terms | grep -q 'Payment Terms' && ok "Terms & Conditions with Payment Terms" || warn "terms not updated yet"
curl -fsS --max-time 10 http://127.0.0.1:3200/salon-software | grep -q '6 + 6 months FREE, then 50% off for 2 years' && ok "offer badge on price cards" || warn "offer badge not found"
[[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APEX/faq)" == 200 ]] && ok "https://$APEX/faq 200" || warn "https://$APEX/faq not 200"
[[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST/login)" == 200 ]] && ok "app untouched: https://$APPHOST/login 200" || warn "app /login not 200 (this update does not touch the app)"
echo "    Rollback content: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"
if [[ $REBOOT -eq 1 ]]; then say "rebooting in 10 seconds (Ctrl+C to cancel)"; sleep 10; systemctl reboot; fi
say "done"
