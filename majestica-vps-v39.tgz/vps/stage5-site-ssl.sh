#!/usr/bin/env bash
# STAGE 5 - Let's Encrypt for majesticadigital.com + www (only after stage 4 says DNS is OK), http->https redirect, HSTS.
. "$(dirname "$0")/common.sh"
bash "$(dirname "$0")/stage4-dns-check.sh" || die "DNS does not point at $VPS_IP yet"
certbot --nginx -d $APEX -d $WWW --non-interactive --agree-tos -m "$LE_EMAIL" --redirect || die "certbot failed (see /var/log/letsencrypt/letsencrypt.log)"
grep -q Strict-Transport-Security $SITE_NGINX || sed -i '/listen 443 ssl/a\    add_header Strict-Transport-Security "max-age=31536000" always;' $SITE_NGINX
nginx -t && systemctl reload nginx
for u in https://$APEX/ https://$WWW/ http://$APEX/ https://$APEX/salon-software https://$APEX/download-staff-app https://$APPHOST/login; do
  printf '    %-45s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' --max-time 10 $u)"; done
certbot renew --dry-run >/dev/null 2>&1 && ok "auto-renew dry run OK" || warn "certbot renew --dry-run failed"
