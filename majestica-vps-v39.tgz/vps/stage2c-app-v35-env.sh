#!/usr/bin/env bash
# STAGE 2c (v3.5) - run right AFTER stage2-app-upgrade.sh. Self-service free demo settings for the app:
#   - DEMO_SIGNUP_SECRET + APP_PUBLIC_URL come INSIDE the encrypted bundle (deploy/release-env.add, merged by bootstrap).
#     This script only checks them; if one is missing it appends it (a missing secret is generated here, never shown).
#   - prisma db push (additive: new DemoSignup table + nullable/defaulted columns), restart, endpoint check.
. "$(dirname "$0")/common.sh"
APP_DIR=/opt/majestica; ENVF=$APP_DIR/.env; TS="$(date +%F-%H%M)"
[[ -f $ENVF ]] || die "no $ENVF - is the app installed?"
ls -d /var/backups/majestica-predeploy-* >/dev/null 2>&1 || die "run stage1-backup.sh first"
say "app .env (values are never printed)"
install -d -m 700 /var/backups; cp -a $ENVF /var/backups/majestica-app-env-before-v35-$TS; chmod 600 /var/backups/majestica-app-env-before-v35-$TS
grep -q '^APP_PUBLIC_URL=.' $ENVF && ok "APP_PUBLIC_URL present" || { echo "APP_PUBLIC_URL=https://$APPHOST" >>$ENVF; ok "APP_PUBLIC_URL added"; }
s="$(sed -n 's/^DEMO_SIGNUP_SECRET=//p' $ENVF | head -n1 | tr -d '"')"
if [[ ${#s} -ge 32 ]]; then ok "DEMO_SIGNUP_SECRET present (${#s} chars)"
else sed -i '/^DEMO_SIGNUP_SECRET=/d' $ENVF; printf 'DEMO_SIGNUP_SECRET=%s\n' "$(openssl rand -hex 32)" >>$ENVF; warn "DEMO_SIGNUP_SECRET was missing - generated a new one on the server (stage3d copies it to the website)"; fi
unset s
chown majestica:majestica $ENVF; chmod 600 $ENVF
[[ -f $APP_DIR/deploy/release-env.add ]] && { rm -f $APP_DIR/deploy/release-env.add; ok "removed leftover deploy/release-env.add"; }
say "database schema (prisma db push - additive, nothing is deleted)"
( cd $APP_DIR && runuser -u majestica -- env HOME=/home/majestica bash -c 'set -a; . ./.env; set +a; npx prisma db push --skip-generate' ) \
  || die "prisma db push failed (no data deleted). App backup: ls -d /var/backups/majestica-predeploy-*  ->  bash rollback.sh app <dir>"
n="$(runuser -u postgres -- psql -d majestica -tAc 'SELECT count(*) FROM "DemoSignup"' 2>/dev/null || echo x)"
[[ "$n" =~ ^[0-9]+$ ]] && ok "DemoSignup table present ($n rows)" || warn "DemoSignup table not found"
say "restart app"
systemctl restart majestica
for _ in $(seq 1 60); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3000/login && break; sleep 2; done
systemctl is-active --quiet majestica && ok "majestica active" || die "majestica not active: journalctl -u majestica -n 50"
code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -X POST -H 'content-type: application/json' -d '{}' http://127.0.0.1:3000/api/public/demo-signup)"
[[ $code == 401 ]] && ok "demo-signup endpoint ON, refuses calls without the secret (401)" || warn "demo-signup without secret -> $code (expected 401; 503 = secret not loaded)"
for p in /login /platform /staff-app; do printf '    https://%s%-12s %s\n' "$APPHOST" "$p" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST$p)"; done
journalctl -u majestica --since "-2 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
