#!/usr/bin/env bash
# STAGE 3 - install / update the marketing site on 127.0.0.1:3200 (systemd "majestica-site", user www-data) + nginx HTTP vhost
# for majesticadigital.com + www. Safe BEFORE the DNS change: nothing public changes until the A record points here.
#   bash stage3-site-install.sh <SITE_TARBALL_URL> <SHA256>
# Re-runs keep content/ (admin edits, requests), public/uploads/ and /etc/majestica-site.env.
. "$(dirname "$0")/common.sh"
URL="${1:?usage: stage3-site-install.sh <SITE_TARBALL_URL> <SHA256>}"; SHA="${2:?sha256}"
command -v node >/dev/null && node -e 'process.exit(+process.versions.node.split(".")[0]>=20?0:1)' || die "Node >= 20 required (stage 2 bootstrap installs it)"
W="$(mktemp -d /var/tmp/mj-site.XXXXXX)"; trap 'rm -rf "$W"' EXIT
say "download"; curl -fL --retry 4 -sS -o "$W/site.tgz" "$URL" || die "download failed"
[[ "$(sha256sum "$W/site.tgz" | cut -d' ' -f1)" == "$SHA" ]] || die "checksum mismatch"; ok "checksum"
tar -xzf "$W/site.tgz" -C "$W"; [[ -f "$W/majestica-site/server.js" ]] || die "not a site bundle"
say "install to $SITE_DIR"
FIRST=0; [[ -d "$SITE_DIR/content" ]] || FIRST=1
if [[ -d $SITE_DIR ]]; then tar --exclude=node_modules -czf "/var/backups/majestica-site-before-$(date +%F-%H%M).tgz" -C /opt majestica-site; fi
install -d "$SITE_DIR"
# replace code, keep live data
find "$SITE_DIR" -mindepth 1 -maxdepth 1 ! -name content ! -name public -exec rm -rf {} +
[[ -d $SITE_DIR/public ]] && find "$SITE_DIR/public" -mindepth 1 -maxdepth 1 ! -name uploads -exec rm -rf {} +
( cd "$W/majestica-site" && tar --exclude=./seed-content --exclude=./public/uploads -cf - . ) | tar -C "$SITE_DIR" -xf -
install -d "$SITE_DIR/public/uploads" "$SITE_DIR/content/backups"
cp -an "$W/majestica-site/public/uploads/." "$SITE_DIR/public/uploads/" 2>/dev/null || true          # add new images, never overwrite
cp -an "$W/majestica-site/seed-content/." "$SITE_DIR/content/"                                        # first install only
[[ $FIRST -eq 1 ]] && ok "first install: content seeded" || ok "kept existing content/ (admin edits + requests)"
cp -a "$W/majestica-site/seed-content" "$SITE_DIR/seed-content"   # reference copy of the content shipped with this build
chown -R root:root "$SITE_DIR"; chown -R www-data:www-data "$SITE_DIR/content" "$SITE_DIR/public/uploads" "$SITE_DIR/.next"
say "environment $SITE_ENV"
if [[ ! -s $SITE_ENV ]] || ! grep -q '^ADMIN_PASSWORD_HASH=.' $SITE_ENV; then
  echo "    Choose the WEBSITE admin password (for majesticadigital.com/admin; not the salon app password)."
  read -rs -p "    admin password: " P1 </dev/tty; echo; read -rs -p "    again: " P2 </dev/tty; echo
  [[ -n "$P1" && "$P1" == "$P2" && ${#P1} -ge 10 ]] || die "passwords empty, different or shorter than 10 characters"
  HP=node_modules/bcryptjs; [[ -d $SITE_DIR/$HP ]] || HP=deploy/node_modules/bcryptjs
  HASH="$(cd "$SITE_DIR" && MJPW="$P1" node -e "process.stdout.write(require('./$HP').hashSync(process.env.MJPW,12))")"; unset P1 P2
  ( umask 077; cat >$SITE_ENV <<ENV
NODE_ENV=production
PORT=3200
HOSTNAME=127.0.0.1
NEXT_PUBLIC_SITE_URL=https://majesticadigital.com
ADMIN_PASSWORD_HASH='${HASH}'
SESSION_SECRET=$(openssl rand -hex 32)
ENV
  ); chown root:root $SITE_ENV; chmod 600 $SITE_ENV; ok "created (hash + random session secret, not shown)"
else ok "kept existing"; grep -q '^HOSTNAME=' $SITE_ENV || echo 'HOSTNAME=127.0.0.1' >>$SITE_ENV; fi
say "systemd majestica-site"
sed -e "s#/opt/majestica-site#$SITE_DIR#g" "$SITE_DIR/deploy/majestica-site.service" >$SITE_UNIT
systemctl daemon-reload; systemctl enable majestica-site >/dev/null 2>&1; systemctl restart majestica-site
for _ in $(seq 1 30); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/ && break; sleep 1; done
curl -fsS -o /dev/null http://127.0.0.1:3200/ && ok "site answers on 127.0.0.1:3200" || { journalctl -u majestica-site -n 30 --no-pager; die "site did not start"; }
say "nginx vhost $APEX + $WWW"
if [[ -f $SITE_NGINX ]] && grep -q 'managed by Certbot' $SITE_NGINX; then ok "vhost already has SSL (certbot) - left as is"
else cat >$SITE_NGINX <<'NG'
# Majestica Digital marketing site (managed by stage3-site-install.sh). certbot --nginx adds 443 + redirect in stage 5.
server {
    listen 80;
    listen [::]:80;
    server_name majesticadigital.com www.majesticadigital.com;
    client_max_body_size 10m;
    gzip on; gzip_proxied any; gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    location / {
        proxy_pass http://127.0.0.1:3200;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NG
fi
ln -sf $SITE_NGINX $SITE_NGINX_EN; nginx -t 2>&1 | tail -n1; systemctl reload nginx
code="$(curl -s -o /dev/null -w '%{http_code}' -H "Host: $APEX" http://127.0.0.1/)"; [[ $code == 200 ]] && ok "nginx -> site (Host: $APEX) 200" || warn "nginx Host test returned $code"
code="$(curl -s -o /dev/null -w '%{http_code}' -H "Host: $APPHOST" https://127.0.0.1/login -k --resolve $APPHOST:443:127.0.0.1)"; echo "    app still reachable: https://$APPHOST/login -> $code"
