#!/usr/bin/env bash
# ONE-COMMAND combined upgrade v3.9 (app). NEVER reboots. Safe under nohup (no prompts):
#   nohup bash /root/vps/upgrade-v39.sh --keep-pass --skip-site > /root/upgrade-v39.log 2>&1 &
#   then: tail -f /root/upgrade-v39.log
#  App v3.9:  mobile-first shell (phone / tablet / desktop / TV), English-only wording, desktop still not
#             installable (phones and tablets can still install; the Android APK is unchanged). Same hosts
#             as live: app.majesticadigital.com and majesticadigital.com. Does not change domain routing
#             and does not touch /var/www/naksha-art or the marketing-site nginx vhost.
#  Website:   unchanged when run with --skip-site (recommended for this release). Site and /naksha-art/
#             are still health-checked.
#  Steps: 1 backup  2 app  3 database check  4 website (optional)  5 verify
#  Options: --skip-site  --keep-pass  --ecdh <PUB> <CT>
. "$(dirname "$0")/common.sh"
umask 077
HERE="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_URL="https://raw.githubusercontent.com/majesticabeauty7/majestica-deploy/main/install-v39.sh"; INSTALLER_SHA="59699a30b7133ca688aab3a24bc6956edd3ac404e48927a8a5fb17ed63f2d09d"
SITE_URL="__SITE_URL__"; SITE_SHA="__SITE_SHA__"
EK="${EK:-$HERE/ek.pem}"; KEEP=/root/.majestica-bundle-pass; ENVF=/opt/majestica/.env
ECDH_PUB=""; ECDH_CT=""; SKIP_SITE=0; KEEP_PASS=0
while [[ $# -gt 0 ]]; do case "$1" in
  --ecdh) ECDH_PUB="${2:?}"; ECDH_CT="${3:?}"; shift 3;;
  --skip-site) SKIP_SITE=1; shift;; --keep-pass) KEEP_PASS=1; shift;;
  --reboot) die "v3.9 never reboots (not needed)";;
  *) die "unknown option $1";; esac; done
[[ "$INSTALLER_URL" != __* ]] || die "this upgrade script was not stamped with the installer link"
if [[ $SKIP_SITE -eq 0 ]]; then
  [[ "$SITE_URL" != __* ]] || die "this upgrade script was not stamped with the site link (or pass --skip-site for an app-only upgrade)"
fi
[[ $EUID -eq 0 ]] || die "run as root"
setenv() { if grep -q "^$1=" "$ENVF"; then sed -i "s|^$1=.*|$1=$2|" "$ENVF"; else printf '%s=%s\n' "$1" "$2" >>"$ENVF"; fi; }
wait_http() { # wait_http URL SECONDS
  for _ in $(seq 1 "$2"); do curl -fsS -o /dev/null --max-time 3 "$1" && return 0; sleep 1; done; return 1; }
# nohup-safe: decide about the passphrase BEFORE touching anything (bootstrap would otherwise ask on a terminal that is not there)
if [[ ! -s $KEEP && -z "$ECDH_PUB" ]] && ! [[ -t 0 ]]; then
  die "no stored passphrase ($KEEP) and no --ecdh, and no terminal to ask on. Run once in a terminal with --keep-pass, or pass --ecdh <PUB> <CT>"
fi
if [[ -s $KEEP || -n "$ECDH_PUB" ]]; then exec </dev/null; fi   # non-interactive run: nothing below may wait for keyboard input

say "1/5 backup (database + app + website + nginx)"
bash "$HERE/stage1-backup.sh" </dev/null || die "backup failed - nothing was changed"
BKAPP="$(ls -1dt /var/backups/majestica-predeploy-* 2>/dev/null | head -n1 || true)"
[[ -n "$BKAPP" && -f "$BKAPP/opt-majestica.tar.gz" ]] || die "backup folder not found after stage1"
ok "pre-upgrade backup: $BKAPP"
echo "    ROLLBACK (if this upgrade fails, or any time after):  bash $HERE/rollback.sh app $BKAPP"
echo "    (DB schema changes are additive; salon data stays. Then: systemctl status majestica)"

say "2/5 app v3.9"
PF=""; TMPF=""
cleanup() { [[ -n "$TMPF" && -f "$TMPF" ]] && { shred -u "$TMPF" 2>/dev/null || rm -f "$TMPF"; }; rm -f /root/majestica-install-v39.sh; }
trap cleanup EXIT
if [[ -s $KEEP ]]; then PF=$KEEP; ok "bundle passphrase: $KEEP (kept from an earlier upgrade)"
elif [[ -n "$ECDH_PUB" ]]; then
  [[ -s $EK ]] || die "no $EK on this server"
  W="$(mktemp -d)"; TMPF="$W/bp"
  { printf -- '-----BEGIN PUBLIC KEY-----\n'; printf '%s' "$ECDH_PUB" | fold -w 64; printf '\n-----END PUBLIC KEY-----\n'; } >"$W/peer.pem"
  S="$(openssl pkeyutl -derive -inkey "$EK" -peerkey "$W/peer.pem" 2>/dev/null | od -An -tx1 | tr -d ' \n')"
  [[ ${#S} -eq 64 ]] || die "ECDH failed"
  printf '%s' "$ECDH_CT" | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:$S" -out "$TMPF" 2>/dev/null || die "could not unlock the passphrase"
  unset S; PF=$TMPF; ok "bundle passphrase unlocked with the server key (never shown)"
else warn "no stored passphrase: bootstrap will ask for it (hidden)"; fi
curl -fsSL --retry 3 "$INSTALLER_URL" -o /root/majestica-install-v39.sh || die "cannot download the installer (link expired?)"
[[ "$(sha256sum /root/majestica-install-v39.sh | cut -d' ' -f1)" == "$INSTALLER_SHA" ]] || die "installer checksum mismatch"
ok "installer checksum OK"
if [[ -n "$PF" ]]; then BUNDLE_PASS_FILE="$PF" bash /root/majestica-install-v39.sh </dev/null; else bash /root/majestica-install-v39.sh; fi
systemctl is-active --quiet majestica || die "majestica not active after the upgrade: journalctl -u majestica -n 50  (rollback: bash $HERE/rollback.sh app $BKAPP)"
if [[ -f /opt/majestica/src/lib/breakpoint.ts && -f /opt/majestica/src/lib/installGuard.ts ]] && grep -q 'fab-list-pad' /opt/majestica/src/app/globals.css 2>/dev/null; then
  ok "app v3.9 code installed"
else
  die "v3.9 files not found in /opt/majestica  (rollback: bash $HERE/rollback.sh app $BKAPP)"
fi
if [[ $KEEP_PASS -eq 1 && -n "$TMPF" && -s "$TMPF" ]]; then install -m 600 -o root -g root "$TMPF" $KEEP; ok "passphrase kept root-only in $KEEP"; fi
cleanup; TMPF=""
wait_http http://127.0.0.1:3000/login 90 && ok "app answers on :3000" || die "app did not answer on :3000 (journalctl -u majestica -n 50)  (rollback: bash $HERE/rollback.sh app $BKAPP)"

say "3/5 database (additive changes only; v3.9 has no new schema vs v3.8)"
q() { runuser -u postgres -- psql -d majestica -tAc "$1" 2>/dev/null || echo x; }
[[ "$(q 'SELECT 1')" == 1 ]] && ok "database accepts queries" || die "database did not accept queries"
# leftover checks from v3.8 stay valid (idempotent); a miss would mean db:upgrade did not run
[[ "$(q 'SELECT count(*) FROM information_schema.columns WHERE table_name=$$Tenant$$ AND column_name=$$closedAt$$')" == 1 ]] && ok "Tenant.closedAt column" || warn "Tenant.closedAt missing (db:upgrade)"
[[ "$(q 'SELECT to_regclass($$"AccountClosureRequest"$$) IS NOT NULL')" == t ]] && ok "AccountClosureRequest table" || warn "AccountClosureRequest table missing"

if [[ $SKIP_SITE -eq 0 ]]; then
  say "4/5 website (optional; not part of the v3.9 app-only release)"
  bash "$HERE/stage3-site-install.sh" "$SITE_URL" "$SITE_SHA" </dev/null
  echo "    waiting for the website on :3200 (up to 180 s)"
  wait_http http://127.0.0.1:3200/ 180 || die "website did not come up on :3200 (journalctl -u majestica-site -n 50)"
  ok "website answers on :3200"
else say "4/5 website skipped (app-only; marketing site and /naksha-art/ are left untouched)"; fi

say "5/5 verify"
for p in /login /staff-app /free-demo /forgot-password /signup /platform /dashboard /appointments /clients /billing /settings; do
  printf '    https://%s%-17s %s\n' "$APPHOST" "$p" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST$p)"
done
LOGIN_C="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST/login)"
[[ "$LOGIN_C" == 200 ]] && ok "https://$APPHOST/login 200" || die "https://$APPHOST/login $LOGIN_C  (rollback: bash $HERE/rollback.sh app $BKAPP)"
SITE_C="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 https://$APEX/)"
[[ "$SITE_C" == 200 ]] && ok "https://$APEX/ 200" || warn "https://$APEX/ $SITE_C (marketing site; this upgrade did not change it when --skip-site)"
NAK_C="$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 https://$APEX/naksha-art/)"
[[ "$NAK_C" == 200 ]] && ok "https://$APEX/naksha-art/ 200" || warn "https://$APEX/naksha-art/ $NAK_C (must stay 200; this upgrade must not touch /var/www/naksha-art)"
DUA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"
MUA="Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36"
md="$(curl -fsS --max-time 10 -A "$DUA" http://127.0.0.1:3000/manifest.webmanifest | grep -o '"display": *"[a-z-]*"' || true)"
mm="$(curl -fsS --max-time 10 -A "$MUA" http://127.0.0.1:3000/manifest.webmanifest | grep -o '"display": *"[a-z-]*"' || true)"
[[ "$md" == *browser* ]] && ok "desktop: not installable (manifest $md)" || warn "desktop manifest: '$md' (expected browser)"
[[ "$mm" == *standalone* ]] && ok "phone: installable (manifest $mm)" || warn "phone manifest: '$mm' (expected standalone)"
curl -fsS --max-time 10 -A "$DUA" http://127.0.0.1:3000/login | grep -q 'rel="manifest" href' && warn "desktop login page still links the manifest" || ok "desktop login page has no manifest link"
if [[ $SKIP_SITE -eq 0 ]]; then
  wait_http http://127.0.0.1:3200/ 60 || warn "website not answering on :3200"
  [[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1:3200/)" == 200 ]] && ok "website :3200 / 200" || warn "website :3200 not 200"
fi
journalctl -u majestica --since "-10 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
echo "    ROLLBACK:  bash $HERE/rollback.sh app $BKAPP"
echo "    No reboot was done or needed. Domain routing was not changed."
say "done"
