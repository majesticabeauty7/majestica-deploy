#!/usr/bin/env bash
# STAGE 6 - remove the EXAMPLE demo salon (demo@majestica.example / Demo@1234). ONLY when the owner says so.
#   bash stage6-remove-demo.sh          -> dry run: shows what would be deleted
#   bash stage6-remove-demo.sh --yes    -> takes a fresh DB backup, deletes demo tenants + demo logins, sets SEED_DEMO=false
. "$(dirname "$0")/common.sh"
cd /opt/majestica; [[ -f prisma/remove-demo.ts ]] || die "prisma/remove-demo.ts missing (it ships in the new app bundle - run stage 2 first)"
if grep -q '"db:remove-demo"' package.json; then CMD="npm run --silent db:remove-demo --"; else CMD="npx tsx prisma/remove-demo.ts"; fi
run() { runuser -u majestica -- env HOME=/home/majestica bash -c "cd /opt/majestica && set -a && . ./.env && set +a && $CMD $1"; }
if [[ "${1:-}" != "--yes" ]]; then run ""; exit 0; fi
command -v majestica-backup >/dev/null && majestica-backup && ok "fresh encrypted backup taken"
run --yes
sed -i 's/^SEED_DEMO=.*/SEED_DEMO=false/' .env; grep -q '^SEED_DEMO=' .env || echo SEED_DEMO=false >>.env
systemctl restart majestica && ok "demo removed, SEED_DEMO=false, app restarted"
echo "    Next: create the real Majestica Beauty account at https://$APPHOST/signup"
