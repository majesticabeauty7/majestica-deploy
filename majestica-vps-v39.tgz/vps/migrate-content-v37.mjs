// v3.7 site content update (run ONCE per content file; safe to re-run: it records itself in content.migrations).
//   node scripts/migrate-content-v37.mjs <path/to/site.json> [--dry-run]
// 1) Bulk SMS Promotion + Bulk Email Promotion -> ONE product "Bulk SMS & Email Marketing" (slug bulk-sms-email-marketing),
//    built from the CURRENT two products (their features, plans and FAQs are combined, admin edits are kept).
// 2) FAQ rewritten for the current flow (email code signup, salon code login, staff code, forgot password / login code, GST).
// 3) Old wording fixed: "login details are sent to your email and mobile", "bulk SMS ... bulk email promotion", the tagline.
// 4) SEO entry for the new /faq page.
import fs from "node:fs";
const file = process.argv[2]; const dry = process.argv.includes("--dry-run");
if (!file) { console.error("usage: node migrate-content-v37.mjs <site.json> [--dry-run]"); process.exit(2); }
const c = JSON.parse(fs.readFileSync(file, "utf8"));
const ID = "v3.7-faq-bulk-merge";
c.migrations = Array.isArray(c.migrations) ? c.migrations : [];
if (c.migrations.includes(ID)) { console.log(`content already has ${ID} - nothing to do`); process.exit(0); }
const log = (s) => console.log("  " + s);
const NEW_SLUG = "bulk-sms-email-marketing";

/* 1 products */
const sms = c.products.find((p) => p.slug === "bulk-sms-promotion" || p.id === "prod_bulk_sms");
const email = c.products.find((p) => p.slug === "bulk-email-promotion" || p.id === "prod_bulk_email");
if (!c.products.some((p) => p.slug === NEW_SLUG) && (sms || email)) {
  const base = JSON.parse(JSON.stringify(email || sms));
  const seen = new Set(); const feats = [];
  for (const [src, pre] of [[sms, "sms"], [email, "email"]]) for (const f of src?.features ?? []) {
    const k = f.title.trim().toLowerCase(); if (seen.has(k)) continue; seen.add(k);
    feats.push({ ...f, id: feats.some((x) => x.id === f.id) ? `${pre}-${f.id}` : f.id });
  }
  const merged = {
    ...base,
    id: "prod_bulk_sms_email", slug: NEW_SLUG, status: "published", category: "Marketing",
    name: "Bulk SMS & Email Marketing", cardTitle: "Bulk SMS & Email Marketing",
    sortOrder: Math.min(sms?.sortOrder ?? 40, email?.sortOrder ?? 40),
    tagline: "Send offers, reminders and newsletters to all your clients by SMS and email — with delivery, open and click reports.",
    shortDescription: "Bulk SMS and email campaigns for promotions, reminders, greetings and newsletters, with reports for every campaign.",
    longDescription: "Reach every client by text SMS and by email from one place. Send offers, festival greetings, appointment reminders, newsletters and announcements to your whole client list or a selected group. SMS uses a DLT-registered sender ID; emails use ready-made designs and can be sent from your business address. Every campaign comes with delivery, open and click reports.",
    cardImage: email?.cardImage || sms?.cardImage || "", heroImage: email?.heroImage || sms?.heroImage || "",
    images: [...(email?.images ?? []), ...(sms?.images ?? [])],
    icon: "email",
    features: feats,
    keyFeatureIds: undefined,
    plans: [...(sms?.plans ?? []), ...(email?.plans ?? [])],
    process: [...(sms?.process ?? []), ...(email?.process ?? [])].slice(0, 6),
    faq: [...(sms?.faq ?? []), ...(email?.faq ?? [])],
    seo: { title: "Bulk SMS & Email Marketing | Majestica Digital", description: "Bulk SMS and email marketing for salons and businesses: offers, greetings, reminders and newsletters, with DLT sender ID support, ready-made email designs and delivery, open and click reports." },
    featuresTitle: base.featuresTitle || "SMS and email features",
  };
  delete merged.keyFeatureIds;
  const at = Math.min(...[sms, email].filter(Boolean).map((p) => c.products.indexOf(p)));
  c.products = c.products.filter((p) => p !== sms && p !== email);
  c.products.splice(at, 0, merged);
  log(`products: merged "${sms?.name ?? "-"}" + "${email?.name ?? "-"}" -> "${merged.name}" (${feats.length} features, card image ${merged.cardImage})`);
} else log("products: nothing to merge");
// order: Salon Software, Website Development, Social Media Marketing, Bulk SMS & Email Marketing
const ORDER = ["salon-management-software", "website-development", "social-media-marketing", NEW_SLUG];
c.products.forEach((p) => { const i = ORDER.indexOf(p.slug); if (i >= 0) p.sortOrder = (i + 1) * 10; });
c.products.sort((a, b) => (a.sortOrder ?? 999) - (b.sortOrder ?? 999));
log(`order: ${c.products.map((p) => p.slug).join(", ")}`);

/* 2 FAQ */
const APP = (c.site?.appUrl || "https://app.majesticadigital.com").replace(/\/+$/, "");
c.faq = [
  { q: "What does Majestica Digital offer?", a: "Our main product is all-in-one salon software with a free Staff App. We also offer website development (Basic, Advanced, Premium and e-commerce), social media marketing, and bulk SMS & email marketing." },
  { q: "How do I get a free demo of the salon software?", a: "Click “Get a free demo” and fill in your name, salon name, mobile number, email and city. We send a 6-digit code to your email. Enter the code, set your own password, and your demo salon is ready. We never send your password by email or SMS." },
  { q: "How does the launch offer work?", a: "Both Single Store and Multi Store get a 6+6 month free demo — 12 months in total. If you buy your package within those 12 months, you get 50% off for 2 years: Single Store ₹899.50 + GST/month instead of ₹1,799 + GST, and Multi Store ₹2,499 + GST/month instead of ₹4,999 + GST." },
  { q: "How do I log in?", a: `Go to ${APP.replace(/^https?:\/\//, "")} and log in with your email, your mobile number or your salon code (for example BHSS8393), plus your password. Your salon code is sent to your email when your account is created.` },
  { q: "How do my staff log in?", a: "Each staff member gets a staff code, for example BHSS8393-001, and a PIN or password from the salon owner or manager. They log in on the Staff App with the staff code and PIN. The login code is also sent to the staff member’s email when their login is created." },
  { q: "I forgot my password or PIN. What should I do?", a: "On the login page, tap “Forgot password”. Enter your email, mobile number or code, and we send a code to the email on your account. Enter the code and set a new password or PIN. Staff can also ask their salon manager to reset it." },
  { q: "I forgot my salon code or staff code. What should I do?", a: "On the login page, tap “Forgot login code?” and enter your email or mobile number. If it is linked to an account, we send your salon code or staff code to the email on that account." },
  { q: "Will I get messages on SMS or WhatsApp?", a: "Right now, codes and login details are sent by email. SMS and WhatsApp messages are coming soon." },
  { q: "Does the Staff App cost extra?", a: "No. The Staff App is free with the salon software. On Android, staff can download the APK directly — no Play Store needed. On iPhone, it can be added to the Home Screen from Safari. Download page: /download-staff-app." },
  { q: "What are the salon software prices?", a: "Single Store is ₹1,799 + GST per month for 1 salon. Multi Store is ₹4,999 + GST per month for up to 3 branches, and each extra branch is ₹1,499 + GST per month. All prices are + GST. Every new branch is activated after we approve the request." },
  { q: "How do I pay?", a: "There is no online payment on the website yet. Your free demo needs no payment. When you are ready to buy, we will share the payment details with you. Online payment is coming soon." },
  { q: "Does the software work on my phone?", a: "Yes. It runs in the browser on a computer, tablet or phone, and it can be installed on your home screen like an app." },
  { q: "How is salon data kept safe?", a: "Salon data is stored encrypted, and an encrypted backup is taken every day. Each salon’s data is kept separate." },
  { q: "How do website packages work?", a: "Choose Basic (₹9,999 + GST), Advanced (₹24,999 + GST), Premium (₹49,999 + GST), or e-commerce starting at ₹2,49,999 + GST. Use Buy Now to send an enquiry with the package selected. We confirm the scope, timeline and next steps with you before work begins." },
  { q: "What is Bulk SMS & Email Marketing?", a: "One service to send offers, festival greetings, reminders and newsletters to your clients by SMS and by email, with delivery, open and click reports. Promotional SMS in India needs a DLT-registered sender ID; we help you set it up. Pricing depends on volume — send an enquiry for a quote." },
];
log(`faq: ${c.faq.length} questions (current flow)`);

/* 3 wording */
const SWAP = [
  ["your demo login details are sent to your email and mobile number", "we send a 6-digit code to your email, then you set your own password"],
  ["Your free demo login details are sent to your email and mobile number.", "We send a 6-digit code to your email; enter it and set your own password."],
  ["bulk SMS promotion and bulk email promotion", "bulk SMS & email marketing"],
  ["bulk SMS and bulk email promotion", "bulk SMS & email marketing"],
  ["bulk SMS or bulk email promotion", "bulk SMS & email marketing"],
  ["Salon management software with a free Staff App — plus websites, built by a salon business.", "Smart salon software, built by salon owners."],
];
let swaps = 0;
const walk = (v) => {
  if (typeof v === "string") { let s = v; for (const [a, b] of SWAP) if (s.includes(a)) { s = s.split(a).join(b); swaps++; } return s; }
  if (Array.isArray(v)) return v.map(walk);
  if (v && typeof v === "object") { for (const k of Object.keys(v)) if (k !== "faq" || v !== c) v[k] = walk(v[k]); return v; }
  return v;
};
for (const k of Object.keys(c)) if (k !== "products" && k !== "faq") c[k] = walk(c[k]);
c.products = c.products.map((p) => p.slug === NEW_SLUG ? p : walk(p));
log(`wording: ${swaps} replacement(s)`);
// links to the old product pages inside content -> new page
const raw0 = JSON.stringify(c);
const raw1 = raw0.replace(/\/products\/bulk-(sms|email)-promotion(?![\w-])/g, `/products/${NEW_SLUG}`).replace(/product=bulk-(sms|email)-promotion(?![\w-])/g, `product=${NEW_SLUG}`);
const out = JSON.parse(raw1); if (raw1 !== raw0) log("links: old product links -> new page");

/* 4 seo */
out.seo = out.seo || {};
out.seo.faq = { title: "FAQ | Majestica Digital Salon Software", description: "Answers about the Majestica Digital salon software: free demo, login with email, mobile or salon code, staff codes, forgot password or login code, prices + GST, the free Staff App, and our other services." };
/* 5 social links (empty = icon hidden; fill in Site admin -> Site -> Social links) */
out.site.social = { facebook: out.site.social?.facebook ?? "", instagram: out.site.social?.instagram ?? "" };
out.migrations = [...out.migrations, ID];

if (dry) { console.log("DRY RUN - file not changed"); process.exit(0); }
const tmp = `${file}.tmp-v37`; fs.writeFileSync(tmp, JSON.stringify(out, null, 2) + "\n"); fs.renameSync(tmp, file);
console.log(`updated ${file}`);
