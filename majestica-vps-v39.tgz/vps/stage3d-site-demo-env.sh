#!/usr/bin/env bash
# STAGE 3d (v3.5) - website -> app link for the self-service free demo. Run after stage2c (any time; idempotent).
#   Copies DEMO_SIGNUP_SECRET from the app .env into /etc/majestica-site.env (never printed), adds DEMO_SIGNUP_URL
#   (local, no TLS hop), restarts majestica-site and proves the app accepts the website's secret (empty test form -> 400, nothing created).
. "$(dirname "$0")/common.sh"
APPENV=/opt/majestica/.env; TS="$(date +%F-%H%M)"; URL="http://127.0.0.1:3000/api/public/demo-signup"
sec="$(sed -n 's/^DEMO_SIGNUP_SECRET=//p' $APPENV 2>/dev/null | head -n1 | tr -d '"')"
[[ ${#sec} -ge 32 ]] || die "the app has no DEMO_SIGNUP_SECRET yet - run stage2c-app-v35-env.sh first"
[[ -f $SITE_ENV ]] || die "no $SITE_ENV - is the website installed (stage3)?"
say "website env $SITE_ENV (values are never printed)"
install -d -m 700 /var/backups; cp -a $SITE_ENV /var/backups/majestica-site-env-before-v35-$TS; chmod 600 /var/backups/majestica-site-env-before-v35-$TS
grep -q '^DEMO_SIGNUP_URL=.' $SITE_ENV && ok "DEMO_SIGNUP_URL present (kept)" || { echo "DEMO_SIGNUP_URL=$URL" >>$SITE_ENV; ok "DEMO_SIGNUP_URL added"; }
cur="$(sed -n 's/^DEMO_SIGNUP_SECRET=//p' $SITE_ENV | head -n1 | tr -d '"')"
if [[ -z "$cur" ]]; then printf 'DEMO_SIGNUP_SECRET=%s\n' "$sec" >>$SITE_ENV; ok "DEMO_SIGNUP_SECRET added (same as the app)"
elif [[ "$cur" != "$sec" ]]; then sed -i '/^DEMO_SIGNUP_SECRET=/d' $SITE_ENV; printf 'DEMO_SIGNUP_SECRET=%s\n' "$sec" >>$SITE_ENV; warn "DEMO_SIGNUP_SECRET differed from the app - replaced with the app's"
else ok "DEMO_SIGNUP_SECRET already matches the app"; fi
chown root:root $SITE_ENV; chmod 600 $SITE_ENV
say "secret check (app <- website secret)"
hdr="$(mktemp)"; chmod 600 "$hdr"; printf 'x-majestica-demo-secret: %s\n' "$sec" >"$hdr"; unset sec cur
code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -X POST -H @"$hdr" -H 'content-type: application/json' -d '{}' $URL)"; rm -f "$hdr"
[[ $code == 400 ]] && ok "app accepts the website's secret (empty test form -> 400, nothing created)" || warn "secret test returned $code (401 = mismatch, 503 = app secret not loaded)"
say "restart majestica-site"
systemctl restart majestica-site
for _ in $(seq 1 30); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/ && break; sleep 1; done
systemctl is-active --quiet majestica-site && ok "majestica-site active" || die "majestica-site not active: journalctl -u majestica-site -n 50"
if grep -rqs --include='*.js' -l 'x-majestica-demo-secret' "$SITE_DIR/.next/server" 2>/dev/null; then ok "the running website has the free-demo signup code"
else warn "the running website does NOT have the free-demo code yet: deploy the new English site bundle (stage3 keeps $SITE_ENV, so these settings stay)"; fi
printf '    https://%s/request  %s\n' "$APEX" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APEX/request)"
