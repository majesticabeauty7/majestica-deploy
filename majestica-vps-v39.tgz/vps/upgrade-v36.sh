#!/usr/bin/env bash
# ONE-COMMAND v3.6 upgrade (email OTP free demo + forgot password by email):
#   1 backup  2 app v3.6 (bootstrap)  3 email (asks for the no-reply mailbox password, hidden)  4 website (free demo -> email code)
# The BUNDLE PASSPHRASE is never typed. It comes from, in this order:
#   a) /root/.majestica-bundle-pass                     (kept on the server by an earlier upgrade with --keep-pass)
#   b) --ecdh <BOX_PUB_B64> <CIPHERTEXT_B64>             (ECDH P-256 with the server key /root/vps/ek.pem: only public values travel)
#   c) otherwise bootstrap asks for it (hidden)          (last resort)
# Other modes:  --new-key   create /root/vps/ek.pem (if missing) and print its PUBLIC key for a photo, then exit
#               --skip-site / --skip-smtp / --keep-pass  (keep-pass: store the passphrase root-only for future upgrades)
. "$(dirname "$0")/common.sh"
umask 077
HERE="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_URL="__INSTALLER_URL__"; INSTALLER_SHA="__INSTALLER_SHA__"
SITE_URL="__SITE_URL__"; SITE_SHA="__SITE_SHA__"
EK="${EK:-$HERE/ek.pem}"; KEEP=/root/.majestica-bundle-pass
ECDH_PUB=""; ECDH_CT=""; SKIP_SITE=0; SKIP_SMTP=0; KEEP_PASS=0
while [[ $# -gt 0 ]]; do case "$1" in
  --ecdh) ECDH_PUB="${2:?}"; ECDH_CT="${3:?}"; shift 3;;
  --new-key) [[ -s $EK ]] || openssl ecparam -name prime256v1 -genkey -noout -out "$EK"; chmod 600 "$EK"
             say "server public key (send a photo of these lines; the private key stays in $EK)"; openssl ec -in "$EK" -pubout 2>/dev/null; exit 0;;
  --skip-site) SKIP_SITE=1; shift;; --skip-smtp) SKIP_SMTP=1; shift;; --keep-pass) KEEP_PASS=1; shift;;
  *) die "unknown option $1";; esac; done
[[ "$INSTALLER_URL" != __* ]] || die "this upgrade script was not stamped with the release links"

say "1/4 backup"
bash "$HERE/stage1-backup.sh"

say "2/4 app v3.6"
PF=""; TMPF=""
cleanup() { [[ -n "$TMPF" && -f "$TMPF" ]] && { shred -u "$TMPF" 2>/dev/null || rm -f "$TMPF"; }; rm -f /root/majestica-install-v36.sh; }
trap cleanup EXIT
if [[ -s $KEEP ]]; then PF=$KEEP; ok "bundle passphrase: $KEEP (kept from an earlier upgrade)"
elif [[ -n "$ECDH_PUB" ]]; then
  [[ -s $EK ]] || die "no $EK on this server - run: bash $HERE/upgrade-v36.sh --new-key   and send a photo of the public key"
  W="$(mktemp -d)"; TMPF="$W/bp"
  { printf -- '-----BEGIN PUBLIC KEY-----\n'; printf '%s' "$ECDH_PUB" | fold -w 64; printf '\n-----END PUBLIC KEY-----\n'; } >"$W/peer.pem"
  openssl pkey -pubin -in "$W/peer.pem" -noout 2>/dev/null || die "the --ecdh public key is damaged (copy the whole command again)"
  S="$(openssl pkeyutl -derive -inkey "$EK" -peerkey "$W/peer.pem" 2>/dev/null | od -An -tx1 | tr -d ' \n')"
  [[ ${#S} -eq 64 ]] || die "ECDH failed (is $EK the key whose public half was sent?)"
  printf '%s' "$ECDH_CT" | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:$S" -out "$TMPF" 2>/dev/null || die "could not unlock the passphrase (wrong server key or damaged command)"
  unset S; PF=$TMPF; ok "bundle passphrase unlocked with the server key (never shown)"
else warn "no stored passphrase and no --ecdh value: bootstrap will ask for it (hidden)"; fi
curl -fsSL --retry 3 "$INSTALLER_URL" -o /root/majestica-install-v36.sh || die "cannot download the installer (link expired?)"
[[ "$(sha256sum /root/majestica-install-v36.sh | cut -d' ' -f1)" == "$INSTALLER_SHA" ]] || die "installer checksum mismatch"
ok "installer checksum OK"
if [[ -n "$PF" ]]; then BUNDLE_PASS_FILE="$PF" bash /root/majestica-install-v36.sh; else bash /root/majestica-install-v36.sh; fi
systemctl is-active --quiet majestica || die "majestica not active after the upgrade: journalctl -u majestica -n 50  (rollback: bash $HERE/rollback.sh app <backup folder shown in step 1>)"
grep -q 'free-demo' /opt/majestica/src/app/api/public/free-demo/verify/route.ts 2>/dev/null && ok "app v3.6 code installed" || warn "v3.6 files not found in /opt/majestica"
[[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST/login)" == 200 ]] && ok "https://$APPHOST/login 200" || warn "/login not 200"
n="$(runuser -u postgres -- psql -d majestica -tAc 'SELECT count(*) FROM information_schema.columns WHERE table_name=$$DemoSignup$$ AND column_name IN ($$tokenHash$$,$$otpVerifiedAt$$,$$setupTokenHash$$,$$completedAt$$)' 2>/dev/null || echo x)"
[[ "$n" == 4 ]] && ok "database: v3.6 columns present (additive)" || warn "database v3.6 columns: $n/4"
if [[ $KEEP_PASS -eq 1 && -n "$TMPF" && -s "$TMPF" ]]; then install -m 600 -o root -g root "$TMPF" $KEEP; ok "passphrase kept root-only in $KEEP (future upgrades need no passphrase)"; fi
cleanup; TMPF=""

if [[ $SKIP_SMTP -eq 0 ]]; then say "3/4 email (no-reply@majesticadigital.com)"; bash "$HERE/stage2d-app-v36-smtp.sh" || warn "email not switched on yet - re-run later: bash $HERE/stage2d-app-v36-smtp.sh"; else say "3/4 email skipped"; fi

if [[ $SKIP_SITE -eq 0 && "$SITE_URL" != __* ]]; then
  say "4/4 website (free demo form -> email code page)"
  bash "$HERE/stage3-site-install.sh" "$SITE_URL" "$SITE_SHA"
  grep -rqs --include='*.js' 'OTP_SENT' "$SITE_DIR/.next/server" && ok "website has the v3.6 free demo code" || warn "website v3.6 code not found"
else say "4/4 website skipped"; fi

say "done"
for p in /login /free-demo /forgot-password /platform; do printf '    https://%s%-17s %s\n' "$APPHOST" "$p" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST$p)"; done
printf '    https://%s/request           %s\n' "$APEX" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APEX/request)"
journalctl -u majestica --since "-5 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
