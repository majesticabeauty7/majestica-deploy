#!/usr/bin/env bash
# STAGE 4 - after you change the A record at Hostinger: wait until majesticadigital.com + www resolve to the VPS.
. "$(dirname "$0")/common.sh"
for i in $(seq 1 ${TRIES:-1}); do
  a="$(resolve $APEX)"; w="$(resolve $WWW)"; echo "    $APEX -> ${a:-?}   $WWW -> ${w:-?}   (want $VPS_IP)"
  [[ "$a" == "$VPS_IP" && "$w" == "$VPS_IP" ]] && { ok "DNS points at the VPS - run stage5-site-ssl.sh"; exit 0; }
  [[ $i -lt ${TRIES:-1} ]] && sleep 60
done
warn "not yet - wait and re-run (TRIES=30 bash stage4-dns-check.sh waits up to 30 min)"; exit 1
