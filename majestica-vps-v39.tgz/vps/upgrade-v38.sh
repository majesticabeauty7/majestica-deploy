#!/usr/bin/env bash
# ONE-COMMAND combined upgrade v3.8 (app + website). NEVER reboots. Safe under nohup (no prompts):
#   nohup bash upgrade-v38.sh [options] > /root/upgrade-v38.log 2>&1 &      then: tail -f /root/upgrade-v38.log
#  App v3.8:  "Account closure request" (Settings, Super Admin only; no self-delete, no OTP) -> platform console list
#             (new / contacted / deactivated / cancelled + notes) -> staff call the client -> Deactivate (confirm). Emails on
#             receipt + on deactivation. Deactivated salons cannot log in; data per the Terms (6 months, then deleted;
#             deletion only when RETENTION_DELETE=on, otherwise a dry run). Service enquiries from the website are stored
#             + emailed (LEAD_NOTIFY_EMAIL, default majesticabeauty7@gmail.com). Not installable on desktop / PC (phones and
#             tablets can still install; the Android APK is unchanged).
#  Website:   Majestica Digital as a digital solutions company with 4 equal services, separate enquiry form per service,
#             "Who can use it", readable (solid / frosted) menus and dropdowns, account-closure wording in Terms / FAQ.
#  Steps: 1 backup  2 app  3 database check  4 website + wait for :3200 + content migrations  5 verify
#  Options: --skip-site  --keep-pass  --ecdh <PUB> <CT>  --lead-email <address>
. "$(dirname "$0")/common.sh"
umask 077
HERE="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_URL="__INSTALLER_URL__"; INSTALLER_SHA="__INSTALLER_SHA__"
SITE_URL="__SITE_URL__"; SITE_SHA="__SITE_SHA__"
EK="${EK:-$HERE/ek.pem}"; KEEP=/root/.majestica-bundle-pass; ENVF=/opt/majestica/.env
ECDH_PUB=""; ECDH_CT=""; SKIP_SITE=0; KEEP_PASS=0; LEAD_EMAIL=""
while [[ $# -gt 0 ]]; do case "$1" in
  --ecdh) ECDH_PUB="${2:?}"; ECDH_CT="${3:?}"; shift 3;;
  --skip-site) SKIP_SITE=1; shift;; --keep-pass) KEEP_PASS=1; shift;;
  --lead-email) LEAD_EMAIL="${2:?}"; shift 2;;
  --reboot) die "v3.8 never reboots (not needed)";;
  *) die "unknown option $1";; esac; done
[[ "$INSTALLER_URL" != __* && "$SITE_URL" != __* ]] || die "this upgrade script was not stamped with the release links"
[[ $EUID -eq 0 ]] || die "run as root"
setenv() { if grep -q "^$1=" "$ENVF"; then sed -i "s|^$1=.*|$1=$2|" "$ENVF"; else printf '%s=%s\n' "$1" "$2" >>"$ENVF"; fi; }
wait_http() { # wait_http URL SECONDS
  for _ in $(seq 1 "$2"); do curl -fsS -o /dev/null --max-time 3 "$1" && return 0; sleep 1; done; return 1; }
# nohup-safe: decide about the passphrase BEFORE touching anything (bootstrap would otherwise ask on a terminal that is not there)
if [[ ! -s $KEEP && -z "$ECDH_PUB" ]] && ! [[ -t 0 ]]; then
  die "no stored passphrase ($KEEP) and no --ecdh, and no terminal to ask on. Run once in a terminal with --keep-pass, or pass --ecdh <PUB> <CT>"
fi
if [[ -s $KEEP || -n "$ECDH_PUB" ]]; then exec </dev/null; fi   # non-interactive run: nothing below may wait for keyboard input

say "1/5 backup (database + app + website)"
bash "$HERE/stage1-backup.sh" </dev/null || die "backup failed - nothing was changed"
LIVE="$SITE_DIR/content/site.json"; TS="$(date +%F-%H%M%S)"; BK="/var/backups/majestica-site-content-before-v38-$TS.tgz"
install -d -m 700 /var/backups; [[ -d $SITE_DIR/content ]] && tar -czf "$BK" -C "$SITE_DIR" content && ok "website content: $BK"

say "2/5 app v3.8"
PF=""; TMPF=""
cleanup() { [[ -n "$TMPF" && -f "$TMPF" ]] && { shred -u "$TMPF" 2>/dev/null || rm -f "$TMPF"; }; rm -f /root/majestica-install-v38.sh; }
trap cleanup EXIT
if [[ -s $KEEP ]]; then PF=$KEEP; ok "bundle passphrase: $KEEP (kept from an earlier upgrade)"
elif [[ -n "$ECDH_PUB" ]]; then
  [[ -s $EK ]] || die "no $EK on this server"
  W="$(mktemp -d)"; TMPF="$W/bp"
  { printf -- '-----BEGIN PUBLIC KEY-----\n'; printf '%s' "$ECDH_PUB" | fold -w 64; printf '\n-----END PUBLIC KEY-----\n'; } >"$W/peer.pem"
  S="$(openssl pkeyutl -derive -inkey "$EK" -peerkey "$W/peer.pem" 2>/dev/null | od -An -tx1 | tr -d ' \n')"
  [[ ${#S} -eq 64 ]] || die "ECDH failed"
  printf '%s' "$ECDH_CT" | openssl enc -d -aes-256-cbc -pbkdf2 -a -A -pass "pass:$S" -out "$TMPF" 2>/dev/null || die "could not unlock the passphrase"
  unset S; PF=$TMPF; ok "bundle passphrase unlocked with the server key (never shown)"
else warn "no stored passphrase: bootstrap will ask for it (hidden)"; fi
curl -fsSL --retry 3 "$INSTALLER_URL" -o /root/majestica-install-v38.sh || die "cannot download the installer (link expired?)"
[[ "$(sha256sum /root/majestica-install-v38.sh | cut -d' ' -f1)" == "$INSTALLER_SHA" ]] || die "installer checksum mismatch"
ok "installer checksum OK"
if [[ -n "$PF" ]]; then BUNDLE_PASS_FILE="$PF" bash /root/majestica-install-v38.sh </dev/null; else bash /root/majestica-install-v38.sh; fi
systemctl is-active --quiet majestica || die "majestica not active after the upgrade: journalctl -u majestica -n 50  (rollback: bash $HERE/rollback.sh app <backup folder from step 1>)"
[[ -f /opt/majestica/src/server/services/accountClosure.ts && -f /opt/majestica/src/lib/installGuard.ts ]] && ok "app v3.8 code installed" || warn "v3.8 files not found in /opt/majestica"
if [[ $KEEP_PASS -eq 1 && -n "$TMPF" && -s "$TMPF" ]]; then install -m 600 -o root -g root "$TMPF" $KEEP; ok "passphrase kept root-only in $KEEP"; fi
cleanup; TMPF=""
[[ -n "$LEAD_EMAIL" ]] && { setenv LEAD_NOTIFY_EMAIL "$LEAD_EMAIL"; chmod 600 "$ENVF"; ok "website enquiries + closure requests are emailed to $LEAD_EMAIL"; systemctl restart majestica; }
wait_http http://127.0.0.1:3000/login 90 && ok "app answers on :3000" || die "app did not answer on :3000 (journalctl -u majestica -n 50)"

say "3/5 database (additive changes only)"
q() { runuser -u postgres -- psql -d majestica -tAc "$1" 2>/dev/null || echo x; }
[[ "$(q 'SELECT count(*) FROM information_schema.columns WHERE table_name=$$Tenant$$ AND column_name=$$closedAt$$')" == 1 ]] && ok "Tenant.closedAt column" || warn "Tenant.closedAt missing (db:upgrade)"
[[ "$(q 'SELECT to_regclass($$"AccountClosureRequest"$$) IS NOT NULL')" == t ]] && ok "AccountClosureRequest table" || warn "AccountClosureRequest table missing"
[[ "$(q 'SELECT to_regclass($$"ServiceLead"$$) IS NOT NULL')" == t ]] && ok "ServiceLead table" || warn "ServiceLead table missing"
echo "    closed salons now: $(q 'SELECT count(*) FROM "Tenant" WHERE "closedAt" IS NOT NULL')   (expected 0 on the first v3.8 install)"

if [[ $SKIP_SITE -eq 0 ]]; then
  say "4/5 website + content (live admin edits are kept; content is updated in place)"
  bash "$HERE/stage3-site-install.sh" "$SITE_URL" "$SITE_SHA" </dev/null
  echo "    waiting for the website on :3200 (up to 180 s) before changing content"
  wait_http http://127.0.0.1:3200/ 180 || die "website did not come up on :3200 - content NOT changed (journalctl -u majestica-site -n 50)"
  ok "website answers on :3200"
  for m in migrate-content-v37.mjs migrate-content-v37-legal.mjs migrate-content-v37c.mjs migrate-content-v38.mjs; do
    [[ -f $SITE_DIR/deploy/$m ]] || die "$m missing in the bundle"
    node "$SITE_DIR/deploy/$m" "$LIVE" || die "content update $m failed - restore: tar -xzf $BK -C $SITE_DIR && systemctl restart majestica-site"
  done   # each migration is recorded in content.migrations and does nothing the second time
  node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' "$LIVE" || die "site.json not valid - restore: tar -xzf $BK -C $SITE_DIR"
  chown -R www-data:www-data "$SITE_DIR/content"; chmod 644 "$LIVE"
  systemctl restart majestica-site
  wait_http http://127.0.0.1:3200/ 180 || die "website did not come back after the content update"
  PAGES="/ /products /salon-software /products/salon-management-software /products/website-development /products/social-media-marketing /products/bulk-sms-email-marketing /request /faq /terms /privacy /refund-policy /about /contact"
  for u in $PAGES; do curl -s -o /dev/null --max-time 10 http://127.0.0.1:3200$u; done
else say "4/5 website skipped"; fi

say "5/5 verify"
for p in /login /staff-app /free-demo /forgot-password /signup /platform; do printf '    https://%s%-17s %s\n' "$APPHOST" "$p" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APPHOST$p)"; done
DUA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"
MUA="Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36"
md="$(curl -fsS --max-time 10 -A "$DUA" http://127.0.0.1:3000/manifest.webmanifest | grep -o '"display": *"[a-z-]*"' || true)"
mm="$(curl -fsS --max-time 10 -A "$MUA" http://127.0.0.1:3000/manifest.webmanifest | grep -o '"display": *"[a-z-]*"' || true)"
[[ "$md" == *browser* ]] && ok "desktop: not installable (manifest $md)" || warn "desktop manifest: '$md' (expected browser)"
[[ "$mm" == *standalone* ]] && ok "phone: installable (manifest $mm)" || warn "phone manifest: '$mm' (expected standalone)"
curl -fsS --max-time 10 -A "$DUA" http://127.0.0.1:3000/login | grep -q 'rel="manifest" href' && warn "desktop login page still links the manifest" || ok "desktop login page has no manifest link"
c="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1:3000/api/account-closure)"; [[ "$c" == 401 || "$c" == 403 ]] && ok "closure API needs a login ($c)" || warn "closure API answered $c"
if [[ $SKIP_SITE -eq 0 ]]; then
  for u in $PAGES; do printf '    %-42s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://127.0.0.1:3200$u)"; done
  # pages refresh from site.json within 5 minutes (stale-while-revalidate); poll instead of failing on the first try
  got=0; for _ in $(seq 1 40); do curl -fsS --max-time 10 http://127.0.0.1:3200/ | grep -qi 'digital solutions company' && { got=1; break; }; sleep 10; done
  [[ $got -eq 1 ]] && ok "home page: digital solutions company" || warn "home page not refreshed yet (check again in a few minutes)"
  H="$(curl -fsS --max-time 10 http://127.0.0.1:3200/ || true)"
  grep -q 'id="services"' <<<"$H" && ok "4 services section on home" || warn "services section not found"
  grep -qi 'Who can use' <<<"$H" && ok "Who can use it" || warn "Who can use it not found"
  grep -q 'Existing customers can log in' <<<"$H" && warn "'Existing customers can log in' text still present" || ok "'Existing customers' sentence removed"
  for s in website-development social-media-marketing bulk-sms-email-marketing; do printf '    /request?product=%-28s %s\n' "$s" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1:3200/request?product=$s")"; done
  curl -fsS --max-time 10 http://127.0.0.1:3200/terms | grep -qi 'our team will contact you' && ok "Terms: account closure by request" || warn "terms not refreshed yet (check again in a few minutes)"
  [[ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://$APEX/)" == 200 ]] && ok "https://$APEX/ 200" || warn "https://$APEX/ not 200"
  echo "    Rollback website content: tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"
fi
journalctl -u majestica --since "-10 min" --no-pager | grep -iE "error|unhandled" | tail -n 5 || true
echo "    Closure requests: platform console (https://$APPHOST/platform) -> Account closure requests. No reboot was done or needed."
say "done"
