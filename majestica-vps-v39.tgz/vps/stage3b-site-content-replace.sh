#!/usr/bin/env bash
# STAGE 3b - replace the LIVE website content (content/site.json) with the content shipped in the bundle just installed by stage 3.
# Why: stage3-site-install.sh keeps the existing content/ on re-runs, so new text/products in a bundle would not show.
# Run AFTER stage3-site-install.sh:   bash stage3b-site-content-replace.sh
# Keeps: content/leads.json (requests / enquiries), content/backups/, public/uploads/, /etc/majestica-site.env.
# Safety: full backup of content/ first; refuses (unless FORCE=1) when the live site.json was edited in the admin panel since the last install.
. "$(dirname "$0")/common.sh"
NEW="$SITE_DIR/seed-content/site.json"; LIVE="$SITE_DIR/content/site.json"; TS="$(date +%F-%H%M%S)"
[[ -f $NEW ]] || die "$NEW not found - run stage3-site-install.sh with the new bundle first"
node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' "$NEW" || die "new site.json is not valid JSON"
grep -q '"social-media-marketing"' "$NEW" || die "$NEW is not the new English content (no social-media-marketing product) - wrong bundle?"
[[ -f $LIVE ]] || { install -d -o www-data -g www-data "$SITE_DIR/content"; }
if [[ -f $LIVE ]] && cmp -s "$NEW" "$LIVE"; then ok "live content is already the new content - nothing to do"; exit 0; fi

say "check for admin edits on the live site"
PREV="$(ls -1t /var/backups/majestica-site-before-*.tgz 2>/dev/null | head -n1 || true)"; EDITED=unknown
if [[ -n $PREV && -f $LIVE ]]; then
  OLDSEED="$(mktemp)"; tar -xzOf "$PREV" majestica-site/seed-content/site.json >"$OLDSEED" 2>/dev/null || true
  if [[ -s $OLDSEED ]]; then cmp -s "$OLDSEED" "$LIVE" && EDITED=no || EDITED=yes; fi
  if [[ $EDITED == yes ]]; then
    echo "    The live site.json differs from the content shipped with the previous install (admin panel edits). Changed sections:"
    node -e 'const f=require("fs");const a=JSON.parse(f.readFileSync(process.argv[1]));const b=JSON.parse(f.readFileSync(process.argv[2]));for(const k of new Set([...Object.keys(a),...Object.keys(b)]))if(JSON.stringify(a[k])!==JSON.stringify(b[k]))console.log("      - "+k)' "$OLDSEED" "$LIVE" || true
  fi
  rm -f "$OLDSEED"
fi
ok "admin edits since last install: $EDITED"
if [[ $EDITED == yes && "${FORCE:-0}" != 1 ]]; then
  die "not replacing. Those edits would be overwritten (a backup is kept). To replace anyway: FORCE=1 bash stage3b-site-content-replace.sh"
fi

say "backup current content/"
install -d -m 700 /var/backups
BK="/var/backups/majestica-site-content-before-english-$TS.tgz"
tar -czf "$BK" -C "$SITE_DIR" content; ok "$BK"
[[ -f $LIVE ]] && { install -d "$SITE_DIR/content/backups"; cp -a "$LIVE" "$SITE_DIR/content/backups/site-$TS-before-english.json"; ok "also kept as content/backups/site-$TS-before-english.json"; }
LEADS_SUM="$( [[ -f $SITE_DIR/content/leads.json ]] && sha256sum "$SITE_DIR/content/leads.json" | cut -d' ' -f1 || echo none)"

say "install new site.json (leads.json, backups/ and uploads untouched)"
cp "$NEW" "$LIVE.tmp-$TS" && mv -f "$LIVE.tmp-$TS" "$LIVE"
chown -R www-data:www-data "$SITE_DIR/content"; chmod 644 "$LIVE"
NOW_LEADS="$( [[ -f $SITE_DIR/content/leads.json ]] && sha256sum "$SITE_DIR/content/leads.json" | cut -d' ' -f1 || echo none)"
[[ $LEADS_SUM == "$NOW_LEADS" ]] && ok "leads.json unchanged ($(node -e 'try{console.log(JSON.parse(require("fs").readFileSync(process.argv[1])).leads.length)}catch{console.log(0)}' "$SITE_DIR/content/leads.json" 2>/dev/null) requests kept)" || warn "leads.json changed?!"

say "restart majestica-site (clears the content cache)"
systemctl restart majestica-site
for _ in $(seq 1 30); do curl -fsS -o /dev/null --max-time 3 http://127.0.0.1:3200/ && break; sleep 1; done
for u in / /products /salon-software /products/social-media-marketing /products/bulk-sms-promotion /products/bulk-email-promotion /request /download-staff-app; do
  printf '    %-40s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3200$u)"; done
curl -fsS http://127.0.0.1:3200/products | grep -q 'Bulk Email Promotion' && ok "new products live" || warn "new products not found on /products"
HOME_HTML="$(curl -fsS http://127.0.0.1:3200/ || true)"
if [[ -z $HOME_HTML ]]; then warn "home page did not answer"; elif grep -qiE 'Free demo lo|chahiye|mahine' <<<"$HOME_HTML"; then warn "Hinglish text still on home page"; else ok "home page is English"; fi
echo
echo "    Rollback content:  tar -xzf $BK -C $SITE_DIR && chown -R www-data:www-data $SITE_DIR/content && systemctl restart majestica-site"
