# shared helpers for the Majestica VPS stage scripts (sourced)
set -Eeuo pipefail
VPS_IP="${VPS_IP:-195.35.7.138}"
SITE_DIR="${SITE_DIR:-/opt/majestica-site}"; SITE_ENV=/etc/majestica-site.env; SITE_UNIT=/etc/systemd/system/majestica-site.service
SITE_NGINX=/etc/nginx/sites-available/majestica-site.conf; SITE_NGINX_EN=/etc/nginx/sites-enabled/majestica-site.conf
APEX=majesticadigital.com; WWW=www.majesticadigital.com; APPHOST=app.majesticadigital.com
LE_EMAIL="${LE_EMAIL:-majesticabeauty7@gmail.com}"
say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[1;32mOK\033[0m %s\n' "$*"; }
warn() { printf '    \033[1;33mWARN\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die "run as root (Hostinger hPanel -> VPS -> Browser terminal)"
resolve() { local ip; ip="$(dig +short A "$1" @1.1.1.1 2>/dev/null | grep -E '^[0-9.]+$' | tail -n1)"; [[ -n "$ip" ]] || ip="$(getent ahostsv4 "$1" | awk 'NR==1{print $1}')"; printf '%s' "$ip"; }
