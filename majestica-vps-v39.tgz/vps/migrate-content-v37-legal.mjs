// v3.7b legal pages: new Terms & Conditions (with Payment Terms), Privacy Policy aligned with it, new Refund & Cancellation Policy,
// and the FAQ "data safety" answer corrected to what is actually encrypted. Replaces privacy / terms text (old text is kept
// in content.legalArchive). Safe to re-run: recorded in content.migrations.
//   node scripts/migrate-content-v37-legal.mjs <path/to/site.json> [--dry-run]
import fs from "node:fs";
const file = process.argv[2]; const dry = process.argv.includes("--dry-run");
if (!file) { console.error("usage: node migrate-content-v37-legal.mjs <site.json> [--dry-run]"); process.exit(2); }
const c = JSON.parse(fs.readFileSync(file, "utf8"));
const ID = "v3.7-legal";
c.migrations = Array.isArray(c.migrations) ? c.migrations : [];
if (c.migrations.includes(ID)) { console.log(`content already has ${ID} - nothing to do`); process.exit(0); }
const UPDATED = "17 November 2026";
const EMAIL = c.site?.email || "majesticabeauty7@gmail.com";
const PHONE = c.site?.phoneDisplay || "+91 94091 37410";

const GRIEVANCE = `## Grievance Officer
In line with the Information Technology Act, 2000, the rules made under it, the Digital Personal Data Protection Act, 2023 and the Consumer Protection (E-Commerce) Rules, 2020, our Grievance Officer is:
- **Name:** Grievance Officer, Majestica Digital
- **Email:** [${EMAIL}](mailto:${EMAIL})
- **Phone / WhatsApp:** ${PHONE}
- **Hours:** Monday to Saturday, 10:00 am to 7:00 pm IST

We acknowledge every complaint within 24 hours and resolve it within 15 days of receiving it. Please include your name, salon or business name, registered email or mobile number, and the details of your complaint.`;

const terms = `These Terms & Conditions ("Terms") apply to the Majestica Digital website (majesticadigital.com), the Majestica Digital salon software and Staff App (app.majesticadigital.com), and our website development and marketing services (together, the "Services"). Majestica Digital is a product of Majestica Beauty, India ("we", "us", "our"). "You" means the person or business that uses the Services.

By creating an account, starting a free demo, placing an order or using the Services, you agree to these Terms, our [Privacy Policy](/privacy) and our [Refund & Cancellation Policy](/refund-policy). This document is an electronic record under the Information Technology Act, 2000 and does not need a physical or digital signature.

## 1. Who can use the Services
You must be at least 18 years old and able to enter into a contract under Indian law. If you accept these Terms for a salon or business, you confirm that you are authorised to do so for that business.

## 2. Your account
- Give true and complete details when you sign up, and keep them up to date.
- Keep your password, PIN, salon code and staff codes confidential. You are responsible for all activity under your account and your staff logins.
- The salon owner decides which staff get access and what they can see. Remove access for staff who leave.
- Tell us at once at [${EMAIL}](mailto:${EMAIL}) if you think your account has been misused.

## 3. Free demo
No payment details are needed to start a free demo. We may end a demo that is misused or created with false details. The free-use period and launch offer are explained in section 4.1.

## 4. Payment Terms
### 4.1 Launch offer: 6 + 6 months free use
- New salon software accounts get **6 + 6 months (12 months in total) of free use**, counted from the date your account is activated. Nothing is charged during this period.
- When the free period ends, you must **select a package (plan) and renew** — pay through Razorpay, plus GST — to keep using the software.
- This offer applies to **all salon software packages, including Single Store and Multi Store**.
- If you select and pay for a package within those 12 months, you get **50% off for the next 2 years** (years 2 and 3): Single Store **₹899.50 + GST per month** instead of ₹1,799 + GST, and Multi Store **₹2,499.50 + GST per month** instead of ₹4,999 + GST. If you have more than 3 branches, each extra branch (from the 4th branch onward) is ₹1,249 + GST per month, and the 50% off for 2 years applies to extra branches too: **₹624.50 + GST per month** per extra branch. After the 2 discounted years, the regular price applies.
- Offer terms are as shown on the product pages on the date your account was activated.
- We send renewal reminders by email before the free period ends. If you do not renew, the steps in section 4.5 apply.

### 4.2 Prices and taxes
All prices on our website are in Indian Rupees and are **exclusive of GST**. GST and any other applicable taxes are added at checkout or on the invoice. The total amount payable is shown to you before you pay. There are no hidden charges.

### 4.3 Subscription billing
The salon software is a subscription. It is billed **in advance**, monthly or yearly as per the plan you choose, from the date your paid plan starts. Extra branches, add-ons and SMS / email credits are billed as shown on our website or quote.

### 4.4 How you pay
Online payments are processed by **Razorpay**, an RBI-authorised payment aggregator, using UPI, cards, net banking or wallets. We may also accept bank transfer or UPI to the account shown on our invoice. We do not see or store your full card or bank details; Razorpay processes them under its own terms and security standards.

### 4.5 Renewal, reminders and non-renewal
Your subscription renews for the same period at the end of each billing cycle unless you cancel before the renewal date. Where you have set up auto-pay (for example a UPI AutoPay or card mandate through Razorpay), the renewal amount is charged automatically as per RBI rules on recurring payments. We send a reminder by email (and SMS / WhatsApp once available) before each renewal and before your free period ends, and you can cancel auto-pay at any time.

If your free period or paid plan ends without renewal, or a payment fails or is not received by the due date:
- you get a **grace period of 7 days**, with reminders, during which the software keeps working;
- after the grace period, the account becomes **read-only or suspended** until you renew: you can no longer create bills or appointments;
- your data is kept safely for **90 days** after the account is suspended, so you can renew or ask for an export;
- if the account is not renewed within those 90 days, we permanently delete the account and its data, after notice by email. Please export your data before that date if you do not plan to renew.

### 4.6 Price changes
We may change our prices. We will tell you at least **30 days** before a new price applies to your subscription. The new price applies from your next billing cycle after the notice period. Launch offer pricing already given to you is honoured for its stated period.

### 4.7 Invoices
We issue a GST invoice for every payment to the email on your account. Please give your correct GSTIN and business details before payment if you want to claim input tax credit; we cannot change an invoice after it is filed, except as allowed by GST law.

### 4.8 Refunds and cancellation
Refunds and cancellations follow our [Refund & Cancellation Policy](/refund-policy), which is part of these Terms. In short: you can cancel at any time and the cancellation takes effect at the end of the current billing cycle; amounts for a billing period that has already started are not refunded; for website development, the advance is non-refundable once work starts.

## 5. Website development and marketing services
A website or marketing project starts only after we confirm the scope, price and timeline with you in writing (a quote, proposal or email). Website projects are paid in milestones — usually an advance before work starts, a part payment on design approval and the balance before the site goes live — as stated in your quote. Work beyond the agreed scope is quoted separately. After full payment, you own the final website design and content made for you, except third-party items (themes, plugins, fonts, stock images) that stay under their own licences. Domain, hosting and third-party fees are payable as quoted. Bulk SMS needs a DLT-registered sender ID and approved templates as required by TRAI; you are responsible for having your customers' consent to receive promotional messages.

## 6. Acceptable use
You must not use the Services to:
- break any law, including the Information Technology Act, 2000 and its rules, or the TRAI rules on commercial messages;
- upload or send content that is unlawful, obscene, defamatory, hateful, harmful to children, misleading, or that infringes someone else's rights, or any other content listed in Rule 3(1)(b) of the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021;
- send spam or messages to people who have not agreed to receive them;
- try to access another salon's data, test or break our security, or overload our systems;
- copy, resell, reverse-engineer or build a competing product from the software;
- upload viruses or harmful code.

We may remove content that breaks these rules, and suspend or close accounts involved, as required by law. Where the law requires, we will preserve information and share it with government agencies.

## 7. Your data
- **You own your salon's data**, including your customers' details, bills, appointments, stock and staff records. We use it only to provide the Services to you, as explained in our [Privacy Policy](/privacy).
- For your customers' and staff's personal data, you decide why and how it is collected (you are the Data Fiduciary under the Digital Personal Data Protection Act, 2023) and we process it on your behalf. You confirm that you have a lawful basis and any consent needed to enter that data and to message those people.
- **Export:** you can download your client list and reports from the software at any time. You can also email us for a full export of your data, which we provide within 15 days.
- **Deletion:** when your account is closed, or at your written request, we delete your salon data within 90 days, except what we must keep by law (for example, our GST invoices). Copies in our encrypted backups are overwritten within 14 days after that.

## 8. Availability and support
We work to keep the Services available and secure, but we do not promise that they will always be available, uninterrupted or error-free. We may carry out planned maintenance, and will try to do it at quiet hours. Features may change as we improve the product; we will not remove a core feature of a paid plan during a paid period without notice.

## 9. Intellectual property
The software, Staff App, website, brand names and logos belong to Majestica Digital / Majestica Beauty. Your subscription gives you a limited, non-exclusive, non-transferable right to use the software for your own business during your paid or demo period.

## 10. Limitation of liability
To the fullest extent allowed by law: (a) we are not liable for any indirect, incidental, special or consequential loss, including loss of profit, revenue, business or goodwill; and (b) our total liability for any claim related to the Services is limited to the amount you paid us for the Services in the 3 months before the event that gave rise to the claim. Nothing in these Terms limits any liability that cannot be limited under Indian law, or your rights as a consumer under the Consumer Protection Act, 2019.

## 11. Indemnity
You agree to compensate us for any loss, claim or penalty caused by your breach of these Terms, your misuse of the Services, the content or messages you send, or your breach of any law or of anyone's rights (including your customers' data rights).

## 12. Suspension and termination
You may stop using the Services and cancel your subscription at any time, as set out in the [Refund & Cancellation Policy](/refund-policy). We may suspend or close your account, with notice where practical, if you do not pay, if you break these Terms or the law, or if we are required to by a court or government authority. Sections 7, 9, 10, 11 and 14 continue after termination.

## 13. Changes to these Terms
We may update these Terms. We will post the new version on this page with a new "last updated" date and, for important changes, tell you by email at least 15 days before they apply. If you keep using the Services after that, you accept the new Terms.

## 14. Governing law and disputes
These Terms are governed by the laws of India. Please contact our Grievance Officer first so we can try to resolve any issue. Subject to that, the courts in Gujarat, India have exclusive jurisdiction over any dispute arising from these Terms or the Services.

${GRIEVANCE}

## Contact
Majestica Digital (a product of Majestica Beauty), Gujarat, India. Email [${EMAIL}](mailto:${EMAIL}) or call / WhatsApp ${PHONE}.`;

const privacy = `This Privacy Policy explains how Majestica Digital, a product of Majestica Beauty, India ("we", "us"), collects, uses, protects and shares personal data when you use our website (majesticadigital.com), our salon software and Staff App (app.majesticadigital.com) and our services. It is published under the Information Technology Act, 2000, the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011, and the Digital Personal Data Protection Act, 2023 ("DPDP Act"). Please also read our [Terms & Conditions](/terms).

## 1. Data we collect
- **Website forms:** name, salon or business name, city, mobile number, email, number of branches or staff, and your message.
- **Your account:** name, email, mobile number, salon details and GSTIN; your password and PIN (stored only as a one-way hash, never in readable form).
- **Payments:** amount, date, plan and the payment reference from Razorpay. We do not receive or store your full card, UPI PIN or bank login details.
- **Data you enter in the salon software:** your customers' names, phone numbers, emails, addresses, visit and bill history, appointments and notes; your staff's details, attendance (including geo-location and selfie at punch-in, if you turn that on) and ID documents; stock and other business records.
- **Technical data:** IP address, browser and device type, pages visited and log-in times, used for security and to keep the Services working.

## 2. Why we use it
- to create and run your account and free demo, and to verify your email with a one-time code;
- to provide the salon software, Staff App, websites and marketing services you ask for;
- to send service messages such as login codes, password reset codes, renewal reminders and invoices;
- to answer enquiries and give support;
- to keep the Services secure, prevent fraud and misuse, and meet our legal duties (for example, tax records).

We use your data only for these purposes, based on your consent or as needed to provide the Services you asked for, or as the law allows. We do not sell personal data, and we do not use your customers' data for our own marketing.

## 3. Your salon's customer and staff data
The data you enter about your customers and staff belongs to you. For that data you are the Data Fiduciary under the DPDP Act and we are your Data Processor: we process it only on your instructions, to provide the software to you. You are responsible for informing your customers and staff and having their consent where required. Requests from your customers or staff about their data should go to your salon; we will help you respond.

## 4. How we protect data
We follow reasonable security practices as required by the IT (Reasonable Security Practices) Rules, 2011, including:
- all connections to our website and software use HTTPS (TLS encryption in transit);
- passwords and PINs are stored only as bcrypt hashes, and one-time codes are stored as hashes and expire within minutes;
- customer phone numbers, alternate phone numbers, emails, addresses and notes, staff ID proof numbers and documents, and attendance selfies are encrypted in the database with AES-256-GCM;
- each salon's data is kept separate and is visible only to that salon's authorised users, with role-based access for staff;
- the database is backed up every night; backups are encrypted (AES-256) and kept for 14 days;
- login rate limits, two-step verification options and audit logs of important actions.

No method of storage or transmission is 100% secure, but we work to protect your data and will improve these measures over time. If a personal data breach happens, we will inform affected users and the Data Protection Board of India as required by the DPDP Act.

## 5. Sharing
We share personal data only with service providers that help us run the Services, under confidentiality and security obligations, and only as much as they need:
- our hosting provider (servers in which the software and website run);
- Razorpay, for payments;
- email, SMS and WhatsApp delivery providers, to send messages you or your salon trigger.

We may also disclose data when required by law, a court order or a lawful request from a government agency, or to protect our users and the Services.

## 6. How long we keep data
- Website enquiries: up to 2 years after our last contact, unless you become a customer.
- Account and salon data: while your account is active, and for 90 days after it ends or is suspended for non-renewal or non-payment (so you can renew or export it); then it is deleted. Encrypted backup copies are overwritten within 14 days after that.
- Invoices and payment records: as long as required by tax and accounting laws (generally 8 years).

## 7. Your rights
Under the DPDP Act you can:
- ask what personal data we hold about you and how we use it;
- ask us to correct, complete or update it;
- ask us to erase it when it is no longer needed (subject to legal retention);
- withdraw consent at any time (this does not affect what was done before, and some Services may stop working without it);
- nominate another person to exercise your rights in case of death or incapacity;
- raise a grievance with our Grievance Officer, and, if not satisfied, with the Data Protection Board of India.

To use these rights, email [${EMAIL}](mailto:${EMAIL}) from your registered email.

## 8. Cookies
Our website uses only cookies needed for it to work (for example, keeping you signed in to the admin or the software). We do not use advertising cookies.

## 9. Children
The Services are meant for businesses and adults. We do not knowingly collect data from children under 18 through our website. Salons must have a parent's or guardian's consent before entering a child customer's data.

## 10. Changes
We may update this policy and will post the new version here with a new "last updated" date. For important changes we will also tell account holders by email.

${GRIEVANCE}`;

const refund = `This Refund & Cancellation Policy applies to payments made to Majestica Digital, a product of Majestica Beauty, India, for the salon software, websites and marketing services. It is part of our [Terms & Conditions](/terms). All prices are exclusive of GST.

## 1. Free demo and 6 + 6 months free use
The free demo and the 6 + 6 months (12 months) free-use period need no payment, so there is nothing to refund. You can stop using them at any time. To continue after the free period, you select a package and pay for it; this policy then applies to that payment.

## 2. Salon software subscription
- **Cancellation:** you can cancel at any time by emailing [${EMAIL}](mailto:${EMAIL}) from your registered email or by WhatsApp to ${PHONE}. Cancellation takes effect at the **end of your current billing cycle** (monthly or yearly). You keep full access until then, and you will not be charged again.
- **Auto-pay:** cancelling also stops any auto-pay mandate with us. You can also cancel the mandate in your UPI app or with your card issuer.
- **Refunds:** subscription fees for a billing period that has already started are **not refundable**, including for partly used months or years, and for unused branches or features.
- **Launch offer:** the launch offer discount applies only while your subscription stays active as per the offer terms on our website.

## 3. Website development
- **Before work starts:** if you cancel before we start work on your project, we refund your advance in full.
- **After work starts:** the **advance is non-refundable** once work has started (for example, once we begin design or set up your domain or hosting).
- **Milestones:** each milestone payment is for work done up to that stage and is not refundable once that stage has been delivered. If you cancel mid-project, you pay for the milestones completed so far and we hand over the work done.
- **Third-party costs:** domain, hosting, paid themes, plugins and similar items bought for you are non-refundable.

## 4. Social media marketing, bulk SMS and email
Monthly marketing plans are billed in advance and can be cancelled with effect from the end of the current month; the current month is not refunded. SMS and email credits that have been used are not refundable. Unused prepaid credits are not refundable or transferable, except as stated in your quote.

## 5. Payments made by mistake
If you are charged twice for the same invoice, charged after a valid cancellation, or charged an amount different from what was shown to you, tell us within 30 days. After checking, we refund the extra amount in full.

## 6. How refunds are paid
Approved refunds are paid to the **original payment method** through Razorpay (or to your bank account if you paid by bank transfer) within **7 working days** of approval. Your bank or card issuer may take a few more days to show it. Any GST charged is adjusted as per GST law (for example, by a credit note).

## 7. Service problems
If the software is unavailable for a long time because of a fault on our side, contact us. We may, at our discretion, extend your subscription for a fair period.

## 8. Contact
For cancellations, refunds or complaints, email [${EMAIL}](mailto:${EMAIL}) or call / WhatsApp ${PHONE}. Complaints are acknowledged within 24 hours and resolved within 15 days by our Grievance Officer, Majestica Digital.`;

c.legalArchive = [...(c.legalArchive || []), { at: new Date().toISOString(), privacy: c.privacy, terms: c.terms }];
c.terms = { title: "Terms & Conditions", updated: UPDATED, body: terms };
c.privacy = { title: "Privacy Policy", updated: UPDATED, body: privacy };
c.refund = { title: "Refund & Cancellation Policy", updated: UPDATED, body: refund };
c.seo = c.seo || {};
c.seo.terms = { title: "Terms & Conditions | Majestica Digital", description: "Terms & Conditions for the Majestica Digital salon software, Staff App, websites and marketing services, including payment, renewal, refund and grievance terms." };
c.seo.privacy = { title: "Privacy Policy | Majestica Digital", description: "How Majestica Digital collects, uses, protects and shares personal data, under the IT Act 2000, the SPDI Rules 2011 and the DPDP Act 2023." };
c.seo.refund = { title: "Refund & Cancellation Policy | Majestica Digital", description: "Cancellation and refund terms for the Majestica Digital salon software subscription, website development and marketing services." };
// FAQ answer about data safety: only what is true today
for (const f of c.faq || []) if (/data (kept )?safe|data safe|secure/i.test(f.q) && /encrypt/i.test(f.a))
  f.a = "All connections use HTTPS. Passwords and PINs are stored only as secure hashes. Your customers' phone numbers, emails, addresses and notes, and staff ID documents, are encrypted in the database (AES-256). The database is backed up every night in encrypted form, and each salon's data is kept separate.";
// product texts: say exactly which data is encrypted
const SWAP = [
  ["Your salon’s data is stored encrypted and kept separate from other salons. An encrypted backup is taken every day.", "Customer phone numbers, emails, addresses and notes are encrypted (AES-256), and each salon’s data is kept separate. An encrypted backup is taken every night."],
  ["Encrypted data and daily encrypted backups", "Encrypted customer details and daily encrypted backups"],
];
const swapAll = (v) => typeof v === "string" ? SWAP.reduce((s, [x, y]) => s.split(x).join(y), v) : Array.isArray(v) ? v.map(swapAll) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, swapAll(x)])) : v;
c.products = swapAll(c.products);
for (const p of c.products) for (const f of p.features || []) f.points = (f.points || []).map((x) => x === "Encrypted data" ? "Encrypted customer details" : x);
// Offer price: 50% of ₹4,999 is ₹2,499.50 (Single Store already used the exact ₹899.50). Badge on every salon software plan.
const fix2499 = (v) => typeof v === "string" ? v.replace(/₹2,499(?![.,\d])/g, "₹2,499.50") : Array.isArray(v) ? v.map(fix2499) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, fix2499(x)])) : v;
for (const k of Object.keys(c)) if (!["legalArchive", "migrations"].includes(k)) c[k] = fix2499(c[k]);
let soft = (c.products || []).find((p) => p.slug === "salon-management-software");
for (const pl of soft?.plans || []) {
  if (pl.offerPriceAmount === 2499) pl.offerPriceAmount = 2499.5;
  if (pl.offerPriceDisplay) pl.offerBadge = pl.offerBadge || "6 + 6 months FREE, then 50% off for 2 years";
}
if (soft?.offer) soft.offer.title = "6 + 6 months FREE, then 50% off for 2 years — on every package, including Single Store";
if (c.marketing?.heroOfferText) c.marketing.heroOfferText = "Single Store ₹1,799 + GST/month, Multi Store ₹4,999 + GST/month. Every package gets 6 + 6 months FREE, then 50% off for 2 years: ₹899.50 and ₹2,499.50 + GST/month.";
// Extra branches (4th onward): ₹1,249 + GST/month (was ₹1,499); the 50% offer applies to them too (₹624.50).
const fixBranch = (v) => typeof v === "string" ? v.replace(/₹1,499(?![.,\d])/g, "₹1,249") : Array.isArray(v) ? v.map(fixBranch) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, fixBranch(x)])) : v;
for (const k of Object.keys(c)) if (!["legalArchive", "migrations"].includes(k)) c[k] = fixBranch(c[k]);
soft = (c.products || []).find((p) => p.slug === "salon-management-software");
for (const pl of soft?.plans || []) if (/additional branch|extra branch/i.test(pl.pricingNote || ""))
  pl.pricingNote = "Includes up to 3 branches. Each extra branch (4th onward) ₹1,249 + tax/month — 50% off for 2 years: ₹624.50 + tax/month. New branches are activated after approval.";
if (soft?.offer?.text) soft.offer.text = soft.offer.text.replace(/each extra branch is ₹1,249 \+ tax per month, activated after approval\./, "each extra branch (4th onward) is ₹1,249 + tax per month, and the 50% offer applies to it too (₹624.50 + tax/month). New branches are activated after approval.");
// FAQ: free-use period and what happens after it
const FREE_Q = "What happens when my 12 months of free use end?";
const FREE_A = "Before the free period ends, we send you renewal reminders by email. To continue, select a package (Single Store or Multi Store) and pay through Razorpay, plus GST. If you do not renew, you get a 7-day grace period; after that the account becomes read-only or suspended. Your data is kept for 90 days so you can renew or ask for an export, and is then deleted.";
for (const f of c.faq || []) if (/launch offer work/i.test(f.q))
  f.a = "Every salon software package — Single Store and Multi Store — gets 6 + 6 months free use: 12 months in total, counted from the day your account is activated, with nothing to pay. Then you get 50% off for 2 years if you select your package within those 12 months: Single Store ₹899.50 + GST/month instead of ₹1,799 + GST, and Multi Store ₹2,499.50 + GST/month instead of ₹4,999 + GST (more than 3 branches: each extra branch from the 4th is ₹1,249 + GST/month, ₹624.50 + GST/month with the 50% offer). After the 2 discounted years, the regular price applies.";
if (!(c.faq || []).some((f) => f.q === FREE_Q)) { const i = (c.faq || []).findIndex((f) => /launch offer work/i.test(f.q)); c.faq.splice(i >= 0 ? i + 1 : c.faq.length, 0, { q: FREE_Q, a: FREE_A }); }
for (const f of c.faq || []) if (/^How do I pay\?/i.test(f.q))
  f.a = "Your free demo and the 12-month free-use period need no payment. When you select a package, you pay online through Razorpay (UPI, cards, net banking) — prices are + GST and you get a GST invoice. Until online payment is switched on for your account, we share the payment details with you directly. See our Refund & Cancellation Policy for refunds.";
for (const f of c.faq || []) if (/salon software prices/i.test(f.q))
  f.a = "Single Store is ₹1,799 + GST per month for 1 salon. Multi Store is ₹4,999 + GST per month for up to 3 branches. If you have more than 3 branches, each extra branch (4th onward) is ₹1,249 + GST per month. Every package, and every extra branch, gets 6 + 6 months free and then 50% off for 2 years: ₹899.50, ₹2,499.50 and ₹624.50 + GST per month. Every new branch is activated after we approve the request.";
c.migrations = [...c.migrations, ID];
console.log(`  legal: terms ${terms.length} chars, privacy ${privacy.length}, refund ${refund.length}; old text archived`);
if (dry) { console.log("DRY RUN - file not changed"); process.exit(0); }
const tmp = `${file}.tmp-v37l`; fs.writeFileSync(tmp, JSON.stringify(c, null, 2) + "\n"); fs.renameSync(tmp, file);
console.log(`updated ${file}`);
