#!/usr/bin/env bash
# STAGE 1 - backups before touching anything: encrypted DB dump + app tree + .env/secrets + nginx config. Kept in /var/backups.
. "$(dirname "$0")/common.sh"
TS="$(date +%F-%H%M)"; D=/var/backups/majestica-predeploy-$TS; install -d -m 700 "$D"
say "database"
if command -v majestica-backup >/dev/null; then majestica-backup && ls -1t /var/backups/majestica/*.enc | head -n1 | xargs -I{} cp {} "$D/" && ok "encrypted dump copied to $D"
else ( umask 077; runuser -u postgres -- pg_dump --no-owner --no-privileges majestica | gzip -9 >"$D/majestica-db.sql.gz" ) && ok "plain dump $D/majestica-db.sql.gz (root-only)"; fi
say "app files (no node_modules/.next)"
tar --exclude=node_modules --exclude=.next -czf "$D/opt-majestica.tar.gz" -C /opt majestica && ok "$(du -h "$D/opt-majestica.tar.gz" | cut -f1) opt-majestica.tar.gz"
cp -a /root/majestica-secrets.txt "$D/" 2>/dev/null || true
tar -czf "$D/nginx.tar.gz" -C /etc nginx; [[ -d $SITE_DIR ]] && tar --exclude=node_modules -czf "$D/opt-majestica-site.tar.gz" -C /opt majestica-site || true
cp -a /usr/local/sbin/majestica-bootstrap "$D/" 2>/dev/null || true
chmod -R go-rwx "$D"; ok "backup folder: $D"
echo "    Also copy /root/majestica-secrets.txt OFF the server once (FIELD_ENC_KEY): without it encrypted client data is unreadable."
