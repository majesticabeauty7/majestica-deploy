#!/usr/bin/env bash
# v3.7c: add the standard user slots (1 Admin, 2 Managers, 2 Receptionists, 1 Accountant) to EXISTING salons, on request only.
# New salons get them automatically at signup. Slots are empty placeholders (no login); existing users / roles are not changed.
#   bash add-user-slots.sh --tenant <salon-slug-or-id> [--tenant ...]   -> DRY RUN
#   bash add-user-slots.sh --all                                       -> DRY RUN for every home salon
#   ... add --yes to apply (a database backup is taken first)
. "$(dirname "$0")/common.sh"
cd /opt/majestica; [[ -f prisma/add-user-slots.ts ]] || die "prisma/add-user-slots.ts missing (it ships with app v3.7c - upgrade first)"
[[ $# -gt 0 ]] || die "usage: bash $0 --tenant <slug-or-id> | --all [--yes]"
for a in "$@"; do [[ "$a" =~ ^[A-Za-z0-9_-]{1,80}$|^--(tenant|all|yes)$ ]] || die "bad argument: $a"; done
run() { runuser -u majestica -- env HOME=/home/majestica bash -c "cd /opt/majestica && set -a && . ./.env && set +a && npx --no-install tsx prisma/add-user-slots.ts $(printf '%q ' "$@")"; }
YES=0; ARGS=(); for a in "$@"; do [[ $a == --yes ]] && YES=1 || ARGS+=("$a"); done
run "${ARGS[@]}" || die "dry run failed - nothing changed"
[[ $YES -eq 1 ]] || exit 0
D="/root/backups/add-user-slots-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$D"; chmod 700 "$D"; F="$D/majestica-db.sql.gz"
( umask 077; set -o pipefail; runuser -u postgres -- pg_dump --no-owner --no-privileges majestica | gzip -9 >"$F" ) || die "database backup failed - nothing changed"
[[ -s "$F" ]] || die "database backup is empty - nothing changed"
ok "database backup $F (root-only)"
run "${ARGS[@]}" --yes || die "failed. Backup: $F"
