#!/usr/bin/env bash
# STAGE 7 (v3.5) - nginx passes the REAL visitor IP to the app and the website: X-Real-IP and X-Forwarded-For = $remote_addr
# (a client-sent X-Forwarded-For can no longer fake its IP; the demo-signup rate limits rely on it).
# Edits only proxy_set_header lines, keeps a .bak copy of every changed file, nginx -t before reload, restores on failure.
. "$(dirname "$0")/common.sh"
TS="$(date +%F-%H%M%S)"; SNIP=/etc/nginx/snippets/majestica-proxy.conf
files=()
for f in "$SNIP" "$SITE_NGINX" $(grep -rlE 'proxy_pass[[:space:]]+http://127\.0\.0\.1:(3000|3200)' /etc/nginx/sites-available /etc/nginx/snippets /etc/nginx/conf.d 2>/dev/null); do
  [[ -f "$f" && ! -L "$f" ]] || continue; [[ " ${files[*]} " == *" $f "* ]] || files+=("$f"); done
[[ ${#files[@]} -gt 0 ]] || die "no nginx proxy files found"
say "nginx files: ${files[*]}"
changed=()
for f in "${files[@]}"; do
  grep -q 'proxy_pass' "$f" || { ok "$f: no proxy_pass (skipped)"; continue; }
  cp -a "$f" "$f.bak-realip-$TS"; before="$(sha256sum "$f")"
  sed -i -E 's#proxy_set_header([[:space:]]+)X-Forwarded-For([[:space:]]+)\$proxy_add_x_forwarded_for;#proxy_set_header X-Forwarded-For $remote_addr;#' "$f"
  sed -i -E 's#proxy_set_header([[:space:]]+)X-Real-IP([[:space:]]+)\$[a-z_]+;#proxy_set_header X-Real-IP $remote_addr;#' "$f"
  grep -q 'X-Real-IP \$remote_addr' "$f" || sed -i -E 's#^([[:space:]]*)proxy_pass[[:space:]]+(http://127\.0\.0\.1:[0-9]+);#&\n\1proxy_set_header X-Real-IP $remote_addr;#' "$f"
  grep -q 'X-Forwarded-For \$remote_addr' "$f" || sed -i -E 's#^([[:space:]]*)proxy_pass[[:space:]]+(http://127\.0\.0\.1:[0-9]+);#&\n\1proxy_set_header X-Forwarded-For $remote_addr;#' "$f"
  if [[ "$(sha256sum "$f")" == "$before" ]]; then rm -f "$f.bak-realip-$TS"; ok "$f already correct"; else changed+=("$f"); ok "$f updated (backup $f.bak-realip-$TS)"; fi
  grep -nE 'proxy_set_header (X-Real-IP|X-Forwarded-For)' "$f" | sed 's/^/      /' || true
done
if nginx -t 2>/tmp/nginx-t.log; then systemctl reload nginx; ok "nginx -t OK, reloaded"
else cat /tmp/nginx-t.log; for f in "${changed[@]}"; do cp -a "$f.bak-realip-$TS" "$f"; done; nginx -t && systemctl reload nginx; die "nginx -t failed - previous files restored, nothing changed"; fi
for u in https://$APEX/ https://$APPHOST/login; do printf '    %-40s %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 $u)"; done
