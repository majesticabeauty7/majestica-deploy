// v3.8: Majestica Digital = a DIGITAL SOLUTIONS COMPANY with 4 equal products / services (Salon & Spa Management Software,
// Website Development, Social Media Marketing, Bulk SMS & Email Marketing). Company hero / meta / About / footer,
// "Who can use it" for the salon & spa software, account CLOSURE REQUEST wording (Terms / Refund / FAQ: "request closure;
// our team will contact you"), desktop = browser only (install on phone / tablet), removal of the "Existing customers can
// log in…" sentence. Fields are replaced only while they still hold an older default text (or are empty), so admin edits
// are kept; long legal texts get targeted edits. Safe to re-run: recorded in content.migrations.
//   node scripts/migrate-content-v38.mjs <path/to/site.json> [--dry-run]
import fs from "node:fs";
const file = process.argv[2]; const dry = process.argv.includes("--dry-run");
if (!file) { console.error("usage: node migrate-content-v38.mjs <site.json> [--dry-run]"); process.exit(2); }
const c = JSON.parse(fs.readFileSync(file, "utf8"));
const ID = "v3.8-digital-solutions-company";
c.migrations = Array.isArray(c.migrations) ? c.migrations : [];
if (c.migrations.includes(ID)) { console.log(`content already has ${ID} - nothing to do`); process.exit(0); }
const UPDATED = "18 November 2026";
const notes = [];
/** set obj[key] = to when the current value is empty or one of the known older texts (matched loosely) */
function setIf(obj, key, to, olds, label) {
  if (!obj) { notes.push(`skip ${label}`); return; }
  const cur = obj[key];
  const norm = (x) => String(x ?? "").replace(/\s+/g, " ").trim().toLowerCase();
  if (norm(cur) === norm(to)) { notes.push(`= ${label}`); return; }
  if (!cur || olds.some((o) => (o instanceof RegExp ? o.test(String(cur)) : norm(cur) === norm(o)))) { obj[key] = to; notes.push(`ok ${label}`); return; }
  notes.push(`KEEP ${label}: edited by admin ("${String(cur).slice(0, 50)}…") - change by hand if wanted`);
}
function rep(obj, key, from, to, label, fallback) {
  if (!obj || typeof obj[key] !== "string") { notes.push(`skip ${label}: no text`); return; }
  if (obj[key].includes(to)) { notes.push(`= ${label}`); return; }
  if (from && obj[key].includes(from)) { obj[key] = obj[key].replace(from, to); notes.push(`ok ${label}`); return; }
  if (fallback) { obj[key] = fallback(obj[key]); notes.push(`ok ${label} (added)`); return; }
  notes.push(`MISS ${label}: anchor text not found - please add by hand`);
}
const OLD_SALON = /salon (management |client management )?software|salon software|staff app/i;

/* 1. company identity */
const S = c.site || (c.site = {});
setIf(S, "tagline", "A digital solutions company for salons and growing businesses.", ["Smart salon software, built by salon owners.", /salon software/i], "site tagline");
setIf(S, "description", "Majestica Digital is a digital solutions company for salons and growing businesses: Salon & Spa Management Software (with a free Staff App), Website Development, Social Media Marketing, and Bulk SMS & Email Marketing. A Majestica Beauty company.", [/^Majestica Digital is all-in-one salon management software/i], "site description");
setIf(S, "footerNote", "© 2026 Majestica Digital · A digital solutions company by Majestica Beauty", ["© 2026 Majestica Digital by Majestica Beauty"], "footer note");
setIf(S, "startFreeLabel", "Get started", ["Get a free demo"], "header button label");

/* 2. home hero */
const H = c.hero || (c.hero = {});
setIf(H, "eyebrow", "Majestica Digital · Digital solutions company", ["Majestica Digital Salon Software"], "hero eyebrow");
setIf(H, "title", "Digital solutions that help your business grow.", [/^Run your whole salon/i], "hero title");
setIf(H, "subtitle", "Majestica Digital is a digital solutions company for salons and growing businesses. One team for four services: Salon & Spa Management Software, Website Development, Social Media Marketing, and Bulk SMS & Email Marketing.", [/^GST billing, bills on WhatsApp/i], "hero subtitle");
if (H.primaryCta && (/free demo/i.test(H.primaryCta.label || "") || !H.primaryCta.label)) { H.primaryCta = { label: "Explore our services", href: "/#services" }; notes.push("ok hero primary button"); } else notes.push("= / KEEP hero primary button");
if (!H.secondaryCta || !H.secondaryCta.label) { H.secondaryCta = { label: "Free salon software demo", href: "/request?product=salon-management-software" }; notes.push("ok hero second button"); }
if (H.whatsappCta) {
  setIf(H.whatsappCta, "label", "Talk to us on WhatsApp", ["Request a demo on WhatsApp"], "hero WhatsApp label");
  setIf(H.whatsappCta, "message", "Hello Majestica Digital, I would like to know more about your services.", ["Hello, I would like a free demo of the Majestica Digital salon software."], "hero WhatsApp message");
}

/* 3. SEO */
const seo = c.seo || (c.seo = {});
const setSeo = (k, title, description, oldRe) => { seo[k] = seo[k] || {}; setIf(seo[k], "title", title, [oldRe], `seo ${k} title`); setIf(seo[k], "description", description, [oldRe], `seo ${k} description`); };
setSeo("home", "Majestica Digital | Digital Solutions Company — Salon & Spa Software, Websites, Social Media, Bulk SMS & Email", "Majestica Digital is a digital solutions company for salons and growing businesses: Salon & Spa Management Software with a free Staff App, website development, social media marketing, and bulk SMS & email marketing.", OLD_SALON);
setSeo("products", "Products & Services | Majestica Digital", "Four services from Majestica Digital, a digital solutions company: Salon & Spa Management Software, Website Development, Social Media Marketing, and Bulk SMS & Email Marketing.", /^Products \| Majestica Digital$|^Majestica Digital products/i);
setSeo("about", "About Majestica Digital | A Digital Solutions Company", "Majestica Digital is a digital solutions company by Majestica Beauty: salon & spa software, websites, social media marketing, and bulk SMS & email marketing for salons and growing businesses.", /^About \| Majestica Digital$|^Majestica Digital is built by Majestica Beauty/i);
setSeo("request", "Get Started | Majestica Digital", "Choose a service and fill in its short form: free demo of the Salon & Spa Management Software, or an enquiry for a website, social media marketing, or bulk SMS & email marketing.", /Get a Free Demo \| Majestica Digital|^Get a free demo of Majestica Digital salon software/i);
setSeo("faq", "FAQ | Majestica Digital", "Answers about Majestica Digital: our four services, the salon & spa software free demo, login, prices + GST, the free Staff App, account closure, websites and marketing.", /^FAQ \| Majestica Digital Salon Software$|^Answers about the Majestica Digital salon software/i);

/* 4. About (also removes the "Existing customers can log in…" sentence) */
const A = c.about || (c.about = { sections: [] });
setIf(A, "title", "Majestica Digital — a digital solutions company for salons and growing businesses.", [/^Built by a salon, for salons/i], "about title");
setIf(A, "lede", "Majestica Digital is a digital solutions company by Majestica Beauty. We build software, websites and marketing that help businesses get more clients and run more smoothly — four services, one team.", [/^Majestica Digital is a product of Majestica Beauty/i], "about lede");
const sec = (h) => (A.sections || []).find((s) => (s.heading || "").toLowerCase() === h.toLowerCase());
const who = sec("Who we are");
if (who) setIf(who, "body", "Majestica Digital started inside a working salon business, Majestica Beauty. Today it is a digital solutions company: we make software, design websites and run marketing for salons, spas and other growing businesses. Because we run a business ourselves, we build tools that are simple, practical and honest about what they do.", [/^Majestica Beauty is a salon business\. Majestica Digital is the software and web studio/i], "about who we are");
const what = sec("What we offer");
if (what) setIf(what, "body", "Four equal products and services: Salon & Spa Management Software (appointments, billing, clients, staff, packages and inventory, with a free Staff App); Website Development, from a five-page site to a full online store; Social Media Marketing; and Bulk SMS & Email Marketing. Use one, or let them work together.", [/^Our main product is all-in-one salon client management software/i], "about what we offer");
const how = sec("How to get started");
if (how) {
  setIf(how, "body", "Choose a service on the Get started page and fill in its short form. For the salon & spa software you get a free demo: we send a 6-digit code to your email, then you choose your own password. For websites, social media and bulk SMS & email, we reply with a clear quote.", [/^There is no online checkout on this website yet/i], "about how to get started");
}
for (const s of A.sections || []) if (typeof s.body === "string" && /Existing customers can log in/i.test(s.body)) { s.body = s.body.replace(/\s*Existing customers can log in[^.]*\.(\s*New customers can start[^.]*\.)?/gi, "").trim(); notes.push("ok removed 'Existing customers can log in…' sentence"); }
for (const k of ["lede", "title"]) if (typeof A[k] === "string" && /Existing customers can log in/i.test(A[k])) A[k] = A[k].replace(/\s*Existing customers can log in[^.]*\.(\s*New customers can start[^.]*\.)?/gi, "").trim();

/* 5. contact */
if (c.contact) setIf(c.contact, "intro", "Questions about any of our services — salon & spa software, websites, social media or bulk SMS & email? Email us, write on WhatsApp, or use the Get started page: each service has its own short form.", [/^Questions about the software, a website, or a future product/i], "contact intro");

/* 6. marketing blocks */
const M = c.marketing || (c.marketing = {});
if (!M.servicesTitle) { M.servicesTitle = "Our products & services"; notes.push("ok services title"); }
if (!M.servicesSubtitle) { M.servicesSubtitle = "Four services, one team. Use one, or let them work together."; notes.push("ok services subtitle"); }
setIf(M, "featuresTitle", "Salon & Spa Management Software — features", ["Salon software features"], "features title");
setIf(M, "softwarePricingTitle", "Salon & Spa Management Software pricing", ["Salon software pricing"], "pricing title");
setIf(M, "closingTitle", "Tell us what your business needs", ["Get a free demo and start today"], "closing title");
setIf(M, "closingText", "Pick a service to open its form, or message us on WhatsApp. The salon & spa software comes with a free 6 + 6 months demo and a free Staff App.", [/^Fill in the request form, or send/i], "closing text");
setIf(M, "whatsappCtaLabel", "Talk to us on WhatsApp", ["Request a demo on WhatsApp"], "WhatsApp label");
setIf(M, "websitesSubtitle", "Professional, mobile-friendly websites for salons and growing businesses — from Basic to e-commerce.", [/^Alongside our salon software/i], "websites subtitle");
if (M.demoBanner) setIf(M.demoBanner, "text", "Free 6 + 6 months demo of our Salon & Spa Management Software", ["Get a free demo of the salon software"], "demo banner");

/* 7. products */
const P = (slug) => (c.products || []).find((p) => p.slug === slug);
const sw = P("salon-management-software");
if (sw) {
  setIf(sw, "name", "Salon & Spa Management Software", ["Salon Client Management Software"], "software name");
  setIf(sw, "cardTitle", "Majestica Digital Salon & Spa Management Software", ["Majestica Digital Salon Client Management Software"], "software card title");
  setIf(sw, "category", "Software", ["Software"], "software category");
  for (const k of ["longDescription", "description", "shortDescription"]) { // company positioning: the software is a product, not the company
    const old = "Majestica Digital is salon software built by a salon.";
    if (typeof sw[k] === "string" && sw[k].startsWith(old)) { sw[k] = "Our Salon & Spa Management Software is built by a salon team." + sw[k].slice(old.length); notes.push(`ok software ${k} opening`); }
  }
  if (sw.seo) setIf(sw.seo, "title", "Salon & Spa Management Software | Staff App Free | Majestica Digital", ["Salon Client Management Software | Staff App Free | Majestica Digital"], "software seo title");
  if (!sw.whoCanUse) {
    sw.whoCanUse = {
      title: "Who can use it",
      intro: "Built in a working salon, made for any business that runs on appointments, services and staff.",
      items: [
        { name: "Salons", text: "including beauty parlours, unisex salons and barber shops" },
        { name: "Spas" }, { name: "Nail studios" }, { name: "Makeup & bridal studios" },
        { name: "Skin, hair & aesthetic clinics" }, { name: "Wellness & massage centres" }, { name: "Tattoo studios" },
        { name: "Pet grooming" }, { name: "Other appointment-based businesses" },
      ],
      note: "What it does for all of them: appointments, billing with GST and bills on WhatsApp, client records, staff, attendance and commission, packages and memberships, and inventory. It is business software, not a medical-records system: clinics use it for appointments, billing and staff, not for patient prescriptions or treatment notes.",
    };
    notes.push("ok software: who can use it");
  }
}
for (const slug of ["social-media-marketing", "bulk-sms-email-marketing"]) { const p = P(slug); if (p) setIf(p, "ctaLabel", "Get a quote", ["Get a free demo"], `${slug} button`); }

/* 8. FAQ */
const F = c.faq || (c.faq = []);
const fq = (re) => F.find((f) => re.test(f.q || ""));
const offer = fq(/What does Majestica Digital offer/i);
if (offer) setIf(offer, "a", "Majestica Digital is a digital solutions company with four products and services: Salon & Spa Management Software (with a free Staff App), Website Development (Basic, Advanced, Premium and e-commerce), Social Media Marketing, and Bulk SMS & Email Marketing.", [/^Our main product is all-in-one salon software/i], "faq what we offer");
const phone = fq(/work on my phone/i);
if (phone) setIf(phone, "a", "Yes. It runs in the browser on a computer, tablet or phone. On a phone or tablet you can also add it to your home screen like an app (and staff can use the Android Staff App). On a computer you simply use it in the browser — there is nothing to install.", [/^Yes\. It runs in the browser on a computer, tablet or phone, and it can be installed on your home screen like an app\.?$/i], "faq phone / no install on computer");
if (!fq(/Who can use the salon/i)) {
  const i = Math.max(0, F.findIndex((f) => /free demo of the salon software/i.test(f.q || "")) + 1);
  F.splice(i, 0, { q: "Who can use the salon & spa software?", a: "Salons (including beauty parlours, unisex salons and barber shops), spas, nail studios, makeup & bridal studios, skin, hair & aesthetic clinics, wellness & massage centres, tattoo studios, pet grooming, and other appointment-based businesses. It covers appointments, billing with GST, client records, staff, attendance and commission, packages and memberships, and inventory. It is not a medical-records system." });
  notes.push("ok faq who can use it");
}
if (!fq(/close my account/i)) {
  F.push({ q: "How do I close my account?", a: "The salon owner (Super Admin) sends an Account closure request from Settings → Account closure in the app, with the reason. Nothing is closed straight away: our team will contact you, help with your data, and then deactivate the account. You can cancel the request until then. After deactivation your data stays available for 6 months and is then permanently deleted within 60 days, as in our Terms & Conditions. A full data export is free during the 6 + 6 months free period or on a package; after the free period it needs the Data Transfer Fee (₹999 + GST)." });
  notes.push("ok faq close my account");
}

/* 9. Terms + Refund: closure is a request; our team contacts you */
const CLOSE = "To close your account, the salon owner (Super Admin) sends an **Account closure request** from Settings → Account closure in the app (or writes to us by email or WhatsApp). Our team will contact you, note your feedback and then deactivate the account; until then you can cancel the request. After deactivation nobody can log in, and your data is kept and deleted as set out in section 4.9 (available for 6 months, then permanently deleted within 60 days).";
const T = c.terms;
rep(T, "body", "You may stop using the Services and cancel your subscription at any time, as set out in the [Refund & Cancellation Policy](/refund-policy).",
  `You may stop using the Services and cancel your subscription at any time, as set out in the [Refund & Cancellation Policy](/refund-policy). ${CLOSE}`, "terms 12 closure request",
  (t) => { const i = t.indexOf("## 13."); const add = `${CLOSE}\n\n`; return i < 0 ? `${t.trimEnd()}\n\n${add}` : t.slice(0, i) + add + t.slice(i); });
if (T && typeof T.body === "string") rep(T, "body", "Majestica Digital salon software", "Majestica Digital Salon & Spa Management Software", "terms product name (first mention)", (t) => t);
if (T) T.updated = UPDATED;
const R = c.refund;
rep(R, "body", "or by WhatsApp to +91 94091 37410. Cancellation takes effect",
  "or by WhatsApp to +91 94091 37410. To close the account itself, the salon owner sends an Account closure request from Settings → Account closure in the app; our team will contact you before the account is deactivated. Cancellation takes effect", "refund closure request");
if (R) R.updated = UPDATED;

c.migrations.push(ID);
for (const n of notes) console.log("  " + n);
if (dry) { console.log("dry run - not saved"); process.exit(0); }
const tmp = file + ".tmp-v38"; fs.writeFileSync(tmp, JSON.stringify(c, null, 2) + "\n"); fs.renameSync(tmp, file);
console.log(`content migrated: ${ID}`);
